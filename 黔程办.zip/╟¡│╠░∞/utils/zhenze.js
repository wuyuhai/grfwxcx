// 判断是否为手机号
function isPoneAvailable(pone) {
	var myreg = /^[1][3,4,5,7,8][0-9]{9}$/;
	if(!myreg.test(pone)) {
		return false;
	} else {
		return true;
	}
}
// 判断是否为电话号码
function isTelAvailable(tel) {
  var myreg = /^1([358][0-9]|4[579]|66|7[0135678]|9[89])[0-9]{8}$/;
	if(!myreg.test(tel)) {
		return false;
	} else {
		return true;
	}
}
//判断身份证是否满足
function isShenfenAvailable(shenfen){
	var regIdNo = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;  
	if(!regIdNo.test(shenfen)){   
	    return false;  
	}else{
		return true;
	}
}

//判断姓名正则
function isNameAvailable(name){
	var regName =/^[\u4e00-\u9fa5]{2,20}$/;  
	if(!regName.test(name)){   
	    return false;  
	}else{
		return true;
	}
}

//判断是否是图片资源
function isImage(file){
  var extStart = file.lastIndexOf(".");
  var ext = file.substring(extStart, file.length).toUpperCase();
  if (ext !=".BMP"&&ext !=".PNG"&&ext !=".GIF"&&ext !=".JPG"&&ext !=".JPEG"){
    return false
  }else{
    return true
  }
}

//判断是否邮箱
function fChkMail(szMail) {
  // var szReg = /^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$  /;
  var szReg = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
  if (!szReg.test(szMail)){
    return false
  }else{
    return true
  }
}

//请求失败回调函数
function resultjsonFun(a, b, c, d, urls) {
  var data = {
    "param": a,
    "errorMsg": b,
    "url": c,
    "type": d
  }
  wx.request({
    url: urls,
    data: data,
    method: 'post',
    dataType: 'json',
    success: function (data) {
      console.log(data);
    }
  })
}

module.exports={
    check:{
    	isPoneAvailable:isPoneAvailable,
    	isTelAvailable:isTelAvailable,
    	isShenfenAvailable:isShenfenAvailable,
    	isNameAvailable:isNameAvailable,
      isImage,
      fChkMail,
      resultjsonFun,
    }
}