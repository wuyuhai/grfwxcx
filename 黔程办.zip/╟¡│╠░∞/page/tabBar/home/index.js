// pages/home/index.js
var check = require('../../../utils/zhenze.js');
Page({
  data: {
    user_name: '',
    menu: [{
        url: "/page/home/pages/home/shixian/my_shixiang", 
        name: "我的事项", 
        src: "/img/home/wdbj.png"
      },
      {
        url: "/page/home/pages/home/my_banjian",
        name: "我的办件",
        src: "/img/home/bjj2.png" 
      },
      {
        url: "/page/home/pages/home/my_yuyue",
        name: "我的预约",
        src: "/img/home/wdyy.png"
      },
      {
        url: "/page/home/pages/home/pinjia/my_pinjia",
        name: "我的评价",
        src: "/img/home/wdpj.png"
      },
      {
        url: "/page/home/pages/home/addr/addrs",
        name: "我的地址",
        src: "/img/home/wddz.png"
      },
      {
        url: "/page/home/pages/home/my_srcs",
        name: "我的材料",
        src: "/img/home/youjian/yidabao.png"
      },
      // {
      //   url: "/page/home/pages/home/shoucang",
      //   name: "我的收藏",
      //   src: "/img/home/shoucang.png"
      // },
      // {
      //   url: "/page/home/pages/home/set_login",
      //   name: "设置",
      //   src: "/img/home/sz.png"
      // },
      {
        url: "/page/home/pages/home/cache",
        name: "清除缓存",
        src: "/img/home/clear.png"
      }
    ],
    phone: '',
    showmode: {
      show: false,
      phone: '',
    },
    assecced_token: "",
    hadyzname:'',
  },

  clear_storage: function() {
    wx.clearStorageSync();
  },
  to_login: function() {
    wx.navigateTo({
      url: '/page/home/pages/home/login/login_select',
    })
    this.setData({
      showmode: {
        show: false,
        phone: wx.getStorageSync("phone")
      }
    });
  },
  getPhoneNumber: function(e) { //点击获取手机号码按钮
    var that = this;
    wx.login({
      success: data => {
        console.log(data)
        console.log(e.detail.iv)
        console.log(e.detail.encryptedData)
        var ency = e.detail.encryptedData;
        var iv = e.detail.iv;
        if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
          // 用户取消了获取手机号
        } else { //同意授权
          wx.request({
            method: "POST",
            // url: 'https://face.fotoit.cn:84/UrbanService/user/decodeUserInfo',  //这个解密地址能用
            url: getApp().globalData.url + 'user/decodeUserInfo',
            data: {
              code: data.code,
              encryptedData: e.detail.encryptedData,
              iv: iv,
            },
            header: {
              'content-type': getApp().globalData.contentType,
            },
            success: (res) => {
              console.log(res);
              if (res.data.code == 200) { //code好像只有线上的可以，发布之后如果获取手机号成功会返回200，，跳转选择登陆
                if (res.data.data.phoneNumber) {
                  getApp().savewxinfo(res.data.data.phoneNumber);
                  var phone = res.data.data.phoneNumber.toString();
                  wx.setStorageSync("phone", phone);
                  that.setData({
                    showmode: {
                      show: false,
                      phone: phone,
                    }
                  })
                  wx.navigateTo({
                    url: '/page/home/pages/home/login/login_select',
                  })
                  // wx.showToast({
                  //   title: "解密成功" + phone,
                  //   icon: 'none'
                  // });
                } else {
                  wx.showToast({
                    title: "解密失败",
                    icon: 'none'
                  });
                  that.setData({
                    showmode: {
                      show: false,
                      phone: '',
                    }
                  })
                }
              }
            },
            fail: function(res) {
              console.log("解密失败~~~~~~~~~~~~~");
              console.log(res);
              wx.showToast({
                title: '解密手机号失败',
                icon: 'none'
              });
            }
          });
        }
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  onShow: function() {
    this.setData({
      assecced_token: wx.getStorageSync("token"),
      user_name: wx.getStorageSync("user_name"),
      phone: wx.getStorageSync("phone"),
      showmode: {
        show: false,
        phone: wx.getStorageSync("phone"),
      },
      hadyzname: wx.getStorageSync("hadyzname")
    });
  },

  navigatortos: function(e) {
    console.log(e)
    if (wx.getStorageSync("token") == "") {
      this.setData({
        showmode: {
          show: true,
          phone: wx.getStorageSync("phone")
        }
      })
      // wx.showModal({
      //   title: '登录',
      //   content: '该查询只支持登录用户查询，前往登录?',
      //   success: function (res) {
      //     if (res.confirm) {
      //       wx.navigateTo({
      //         url: '/page/home/pages/home/login/login_select',
      //       })
      //     } else if (res.cancel) {

      //     }
      //   }
      // })
    } else {
      wx.navigateTo({
        url: e.currentTarget.dataset.src,
      })
    }
  },

  cencel_login: function () {
    this.setData({
      showmode: {
        show: false
      }
    })
  },

  goshiname:function(){
    wx.navigateTo({
      url: '/page/home/pages/home/login/face?oop=true',
    })
  },

  /**
    * 用户点击右上角分享
    */
  onShareAppMessage: function () {

  }
})