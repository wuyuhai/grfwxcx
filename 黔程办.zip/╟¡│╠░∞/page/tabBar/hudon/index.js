var zhenze = require('../../../utils/zhenze.js').check;
// pages/hudon/index.js 
Page({  
 
  /**
   * 页面的初始数据
   */ 
  data: {
    toView: "咨询",   
    shi_list: [],
    shi_index: 0, //市索引 
    qu_list: [], //{"PARENTID":"520000","AREAID":"520100","AREANAME":"贵阳市","LAYER":"2"}
    qu_index: 0, //区索引
    bm_list: [], //部门办事列表     
    bm_index: 0, //部门索引
    item_list: [], //事项列表     
    item_index: 0, //事项索引 
    foot_height: 35,
    my_msg: [],
    key: "",
    box_height: "80%", //输入法谈起40%，

    top_show: true,
    
    user_name: "",
    user_phone: "",

    showmode: {
      show: false,
      phone: '',
    },

    qiquxuanze: {
      city: "请选择城市",
      id: 0
    },

    bm_name: {
      name: "请选择要办理的部门"
    },
    sx_name: {
      name: "请选择要办理的事项"
    },

    viewkin1: 1,
    viewkin2: 1,

    zxmostitem: "",
    zxcontant: "",
    tscontant: "",
    tsmostitem: "",

    textshow:true,
  },
  call_phone: function() { //打电话
    wx.makePhoneCall({
      phoneNumber: '0851-86986888'
    })
  },

  clickanswer: function(e) {
    //console.log(e.currentTarget.dataset.key)
    var that = this;
    if (e.currentTarget.dataset.kind != 3) {
      this.postanswer(e.currentTarget.dataset.key, e.currentTarget.dataset.kind, e.currentTarget.dataset.par)
    }
  },

  postanswer: function(key, kind, par) {
    var that = this;
    var param = {
      YtAction: 'yt_znask.web.NewsAser',
      URL: 'http://58.16.65.112:84/#',
      AREACODE: '52',
      value: key,
    }
    if (kind == 1) {
      param.value = key;
      param.opt = '1';
      param.huahua = '0';
    } else if (kind == 2) {
      param.opt = '3';
      param.huahua = '4';
      param.value = key + par;
    }
    var data = {
      url: 'http://58.16.65.112:84/ytbase/system/?YtAction=yt_znask.web.NewsAser',
      param: JSON.stringify(param)
    }
    console.log(data)
    wx.showLoading({
      title: '博士正在思考中',
    })
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: data,
      method: 'post',
      dataType: 'json',
      success: function(data) {
        setTimeout(function() {
          wx.hideLoading()
        }, 500)
        console.log(data);
        if (data.statusCode == 200) {
          var msg_lst = that.data.my_msg;
          var msg = data.data.data.data;
          var answers = []
          if (msg != "") {
            if (msg.indexOf("</a></li><li><font color=red><a href=javascript:onebind(") != -1) {
              msg = msg.split("</a></li><li><font color=red><a href=javascript:onebind(");
              for (var i = 0; i < msg.length; i++) {
                if (i == 0) {
                  if (msg.indexOf("亲，对不起咯!我大脑里没有找到你咨询的具体的事项，但我梳理一下有关相似的办理事项！") != -1) {
                    console.log(2)
                    answers.push({
                      txt: msg[i].split("<ul class='Areatow'><li><font color=red><a href=javascript:onebind")[0],
                      kind: 1,
                      par: key
                    });
                    answers.push({
                      txt: msg[i].split("<ul class='Areatow'><li><font color=red><a href=javascript:onebind")[1].split("')>")[1],
                      kind: 1,
                      par: key
                    });
                  } else if (msg[i].indexOf("请点击具体事项名称告诉我") != -1) {
                    answers.push({
                      txt: msg[i].split("<ul class='Areatow'><li><font color=red><a href=javascript:onebind")[0],
                      kind: 1,
                      par: key
                    });
                    answers.push({
                      txt: msg[i].split("<ul class='Areatow'><li><font color=red><a href=javascript:onebind")[1].split("')>")[1],
                      kind: 1,
                      par: key
                    });
                  } else {
                    answers.push({
                      txt: msg[i].split("<img src='/images/by.gif'/><img src='/images/zy.gif'/> !如果没有找到准确的")[0],
                      kind: 1,
                      par: key
                    });
                  }
                } else if (i == msg.length - 1) {
                  answers.push({
                    txt: msg[i].split("</a></li>")[0].split("')>")[1],
                    kind: 1,
                    par: key
                  })
                } else {
                  answers.push({
                    txt: msg[i].split("')>")[1],
                    kind: 1,
                    par: key
                  })
                }
              }
            } else if (msg.indexOf("</a></li><li><a href=javascript:onebind(") != -1) {
              msg = msg.split("</a></li><li><a href=javascript:onebind(");
              for (var i = 0; i < msg.length; i++) {
                if (i == 0) {
                  answers.push({
                    txt: msg[i].split("<ul class='Areatow quxian'><li><a href=javascript:onebind")[0],
                    kind: 2,
                    par: key
                  });
                  answers.push({
                    txt: msg[i].split("<ul class='Areatow quxian'><li><a href=javascript:onebind")[1].split("')>")[1],
                    kind: 2,
                    par: key
                  });
                } else if (i == msg.length - 1) {
                  answers.push({
                    txt: msg[i].split("</a></li>")[0].split("')>")[1],
                    kind: 2,
                    par: key
                  })
                } else {
                  answers.push({
                    txt: msg[i].split("')>")[1],
                    kind: 2,
                    par: key
                  })
                }
              }
            } else if (msg.indexOf("点击我再试一试") != -1) {
              answers.push({
                txt: '亲 下面就是具体的办理事项的网址，如果不准确，请点击我再试一次',
                kind: 4,
                par: key
              })
              answers.push({
                txt: 'http' + msg.split("<a href='http")[1].split("'  target='_blank'><font color=red>点击查看")[0],
                kind: 3,
                par: key
              })
            } else if (msg.indexOf("亲,在该咨询区域下没有该事项的办理") != -1) {
              answers.push({
                txt: '亲，在该区域下没有关于 “' + key + '” 该事项的相关问题',
                kind: 4,
                par: key
              })
            } else {
              answers.push({
                txt: '你好，我的大脑里面没有相关的问题',
                kind: 4,
                par: key
              })
            }
          } else {
            console.log(11)
            answers.push({
              txt: '你好，我的大脑里面没有相关的问题',
              kind: 4,
              par: key
            })
          }

          msg_lst.push({
            nm: 1,
            mas: answers
          });
          that.setData({
            key: "",
            my_msg: msg_lst,
            scroll_into_view: "_" + msg_lst[msg_lst.length - 1]
          })
          that.pageScrollToBottom();
        } else {
          wx.showToast({
            title: '政务系统繁忙',
            icon: 'none'
          })
        }
      },
    })
  },

  add_msg: function() { //发信息
    var that = this;
    if (this.data.key) {
      var msg_lst = that.data.my_msg;
      msg_lst.push({
        nm: 2,
        mas: this.data.key
      })
      var key = this.data.key;
      that.setData({
        my_msg: msg_lst,
        key:'',
        foot_height:35,
      })
      this.postanswer(key, 1);
    } else {
      wx.showToast({
        title: '输入内容不能为空！',
        icon: 'none'
      });
    }
  },
  setKey: function(e) { //同步数据
    var that = this;
    wx.createSelectorQuery().select('#textareainput').boundingClientRect(function(rect) {
      that.setData({
        foot_height: rect.height + 5,
      })
    }).exec()
    this.setData({
      key: e.detail.value
    })
  },
  changeView: function(e) { // 个人 组织 部门 切换视图
    if (this.data.toView != e.currentTarget.id) {
      this.setData({
        toView: e.currentTarget.id,
        qiquxuanze: {
          city: "请选择城市",
          id: 0
        },
        bm_name: {
          name: "请选择要办理的部门"
        },
        sx_name: {
          name: "请选择要办理的事项"
        },
      })
    }
  },
  pickerSHI: function(e) { //选择市后修改数据
    getApp().pickerSHI(e);
    this.getDept()

  },
  pickerQU: function(e) { //选择区后修改数据

    getApp().pickerQU(e);

    this.getDept()
  },
  pickerDept: function(e) { //选择部门
    this.setData({
      bm_index: e.detail.value
    })
    this.getItem()
  },
  pickerItem: function(e) {
    this.setData({
      item_index: e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) { 
    this.setData({
      my_msg: wx.getStorageSync("msg_lst") ? wx.getStorageSync("msg_lst") : [],
    })
    this.pageScrollToBottom();
  },

  // 保持聊天框在底部
  pageScrollToBottom: function() {
    wx.createSelectorQuery().select('#j_page').boundingClientRect(function(rect) {
      wx.pageScrollTo({
        scrollTop: rect.bottom
      })
    }).exec()
  },

  onReady: function() {

  },


  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    that.setData({
      user_name: wx.getStorageSync("user_name") ? wx.getStorageSync("user_name") : '',
      user_phone: wx.getStorageSync("phone") ? wx.getStorageSync("phone") : '',
    })
    if (wx.getStorageSync("token") == "") {
      this.setData({
        showmode: {
          show: true,
          phone: wx.getStorageSync("phone")
        }
      })
    }
    if (getApp().globalData.zixuitme) {
      var zixuitme = JSON.parse(getApp().globalData.zixuitme);
      console.log(zixuitme)
      this.setData({
        toView: "建议",
        qiquxuanze:{
          city: wx.getStorageSync('qu_list')[wx.getStorageSync('qu_index')].AREANAME,
          id: wx.getStorageSync('qu_list')[wx.getStorageSync('qu_index')].AREAID,
        },
      })
      this.getDept();
    }else{
      if (this.data.qiquxuanze.city == "请选择城市"){
        this.setData({
          // toView: "咨询",
          qiquxuanze: {
            city: "请选择城市",
            id: 0
          },

          bm_name: {
            name: "请选择要办理的部门"
          },
          sx_name: {
            name: "请选择要办理的事项"
          },
        }) 
      }else{
        this.setData({
          bm_name: {
            name: "请选择要办理的部门"
          },
          sx_name: {
            name: "请选择要办理的事项"
          },
        })
      }     
    }
  },

  onHide:function(){
    getApp().globalData.zixuitme = "";
  },

  top_close: function() {
    console.log(1)
    this.setData({
      top_show: false,
    })
  },

  //网上咨询提交
  zixunformSubmit: function(e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    if (!zhenze.isNameAvailable(e.detail.value.name)) {
      wx.showToast({
        title: '姓名必须为中文简体，且不少于2个字',
        icon: 'none'
      })
      return
    }
    if (e.detail.value.emails != "" && !zhenze.fChkMail(e.detail.value.emails)) {
      wx.showToast({
        title: '请填写正确的邮箱没有可以不填',
        icon: 'none'
      })
      return
    }
    if (!zhenze.isTelAvailable(e.detail.value.telphone)) {
      wx.showToast({
        title: '请输入正确的手机号码',
        icon: 'none'
      })
      return
    }
    if (this.data.bm_name.name == "请选择要办理的部门" || this.data.bm_name.name == "") {
      wx.showToast({
        title: '请选择要办理的部门',
        icon: 'none'
      })
      return
    }
    if (this.data.sx_name.name == "请选择要办理的事项" || this.data.sx_name.name == "") {
      wx.showToast({
        title: '请选择要办理的事项',
        icon: 'none'
      })
      return
    }
    if (e.detail.value.zxmostitem == "") {
      wx.showToast({
        title: '请输入咨询的主题',
        icon: 'none'
      })
      return
    }
    if (e.detail.value.zxcontant == ""&&this.data.textshow) {
      wx.showToast({
        title: '请输入咨询的内容',
        icon: 'none'
      })
      return
    }
    var data = {
      CONTENT: e.detail.value.zxcontant,
      DB_CREATE_ID: wx.getStorageSync("user_id"),
      DEPARTMENTID: this.data.bm_name.deptid,
      MAINTITLE: e.detail.value.zxmostitem,
      MOVEPHONE: e.detail.value.telphone,
      NAME: e.detail.value.name,
      SXID: this.data.sx_name.id,
      SXMC: this.data.sx_name.name,
      TELEPHONE: e.detail.value.telphone,
    } 
    this.requesttszx('consult/submit', data, 1)
  },

  //网上投诉
  tousuformSubmit: function(e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    if (!zhenze.isNameAvailable(e.detail.value.name)) {
      wx.showToast({
        title: '姓名必须为中文简体，且不少于2个字',
        icon: 'none'
      })
      return
    }
    if (e.detail.value.emails != "" && !zhenze.fChkMail(e.detail.value.emails)) {
      wx.showToast({
        title: '请填写正确的邮箱没有可以不填',
        icon: 'none'
      })
      return
    }
    if (!zhenze.isTelAvailable(e.detail.value.telphone)) {
      wx.showToast({
        title: '请输入正确的手机号码',
        icon: 'none'
      })
      return
    }
    if (this.data.bm_name.name == "请选择要办理的部门" || this.data.bm_name.name == "") {
      wx.showToast({
        title: '请选择要办理的部门',
        icon: 'none'
      })
      return
    }
    if (this.data.sx_name.name == "请选择要办理的事项" || this.data.sx_name.name == "") {
      wx.showToast({
        title: '请选择要办理的事项',
        icon: 'none'
      })
      return
    }
    if (e.detail.value.tsmostitem == "") {
      wx.showToast({
        title: '请输入投诉的主题',
        icon: 'none'
      })
      return
    }
    if (e.detail.value.tscontant == "" && this.data.textshow) {
      wx.showToast({
        title: '请输入投诉的内容',
        icon: 'none'
      })
      return
    }
    var data = {
      CONTENT: e.detail.value.tscontant,
      DB_CREATE_ID: wx.getStorageSync("user_id"),
      DEPARTMENTID: this.data.bm_name.deptid,
      MAINTITLE: e.detail.value.tsmostitem,
      MOVEPHONE: e.detail.value.telphone,
      NAME: e.detail.value.name,
      TELEPHONE: e.detail.value.telphone,
      SXID: this.data.sx_name.id,
      SXMC: this.data.sx_name.name,
    }
    this.requesttszx('complaint/submit', data, 2)
  },

  requesttszx: function(url, data, kind) {
    var that = this;
    wx.request({
      url: getApp().globalData.url + url,
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: data,
      method: 'post',
      dataType: 'json',
      success: function(data) {
        console.log(data)
        if (data.data.code == 200) {
          var msg = ""
          if (kind == 1) {
            msg = "已经提交到相关部门处理，感谢你的咨询，2s后跳回首页";
            that.setData({
              zxmostitem: "",
              zxcontant: "",
            })
          } else {
            msg = "已经提交到相关部门处理，感谢你珍贵的意见和问题，2s后跳回首页";
            that.setData({
              tscontant:"",
              tsmostitem:"",
            })
          }
          wx.showToast({
            title: msg,
            icon: 'none',
          })

          var timer = setTimeout(function(){
            clearTimeout(timer)
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          },2000)     
        } else {
          wx.showToast({
            title: '政务系统繁忙',
            icon: 'none',
          })
        }
      }
    })
  },

  //点击复制地址
  dianjifuzhi: function(e) {
    wx.setClipboardData({
      data: e.currentTarget.dataset.url,
      success: function(res) {
        wx.getClipboardData({
          success: function(res) {
            console.log(res.data) // data
          }
        })
      }
    })
  },

  //获取用户手机号码
  getPhoneNumber: function(e) { //点击获取手机号码按钮
    var that = this;
    wx.login({
      success: data => {
        console.log(e.detail.iv)
        console.log(e.detail.encryptedData)
        var ency = e.detail.encryptedData;
        var iv = e.detail.iv;
        if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
          // 用户取消了获取手机号
        } else { //同意授权
          wx.request({
            method: "POST",
            // url: 'https://face.fotoit.cn:84/UrbanService/user/decodeUserInfo',  //这个解密地址能用
            url: getApp().globalData.url + 'user/decodeUserInfo',
            data: {
              code: data.code,
              encryptedData: e.detail.encryptedData,
              iv: iv,
            },
            header: {
              'content-type': getApp().globalData.contentType,
            },
            success: (res) => {
              console.log(res);
              if (res.data.code == 200) { //code好像只有线上的可以，发布之后如果获取手机号成功会返回200，，跳转选择登陆
                if (res.data.data.phoneNumber) {
                  getApp().savewxinfo(res.data.data.phoneNumber);
                  var phone = res.data.data.phoneNumber.toString();
                  wx.setStorageSync("phone", phone);
                  that.setData({
                    showmode: {
                      show: false,
                      phone: phone,
                    }
                  })
                  wx.navigateTo({
                    url: '/page/home/pages/home/login/login_select',
                  })
                  // wx.showToast({
                  //   title: "解密成功" + phone,
                  //   icon: 'none'
                  // });
                } else {
                  wx.showToast({
                    title: "解密失败",
                    icon: 'none'
                  });
                  that.setData({
                    showmode: {
                      show: false,
                      phone: '',
                    }
                  })
                }
              }
            },
            fail: function(res) {
              console.log("解密失败~~~~~~~~~~~~~");
              console.log(res);
              wx.showToast({
                title: '解密手机号失败',
                icon: 'none'
              });
            }
          });
        }
      }
    })
  },

  cencel_login: function() {
    this.setData({
      showmode: {
        show: false
      }
    })
    wx.switchTab({
      url: '/page/tabBar/index/index',
    })
  },
  to_login: function() {
    wx.navigateTo({
      url: '/page/home/pages/home/login/login_select',
    })
    this.setData({
      showmode: {
        show: false,
        phone: wx.getStorageSync("phone")
      }
    });
  },

  godiqu: function () {
    wx.navigateTo({
      url: '../../index/pages/index/selectcity/city',
    })
  },

  //选择部门
  selectbm: function (e) {
    console.log(e)
    var bm_name = {
      cityid: e.currentTarget.dataset.cityid,
      deptid: e.currentTarget.dataset.deptid,
      num: e.currentTarget.dataset.num,
      shortname: e.currentTarget.dataset.shortname,
      name: e.currentTarget.dataset.name,
    }
    this.setData({
      bm_name: bm_name,
      bmshow: false,
      textshow:true,
    })
  },

  selectsx: function (e) {
    console.log(e)
    var sx_name = {
      name: e.currentTarget.dataset.name,
      deptid: e.currentTarget.dataset.deptid,
      id: e.currentTarget.dataset.id,
      largeitemid: e.currentTarget.dataset.largeitemid,
      smallitemid: e.currentTarget.dataset.smallitemid,
      xzxk: e.currentTarget.dataset.xzxk,
    }
    this.setData({
      sx_name: sx_name,
      sxshow: false,
      textshow: true,
    })
  },

  showhide: function () {
    this.setData({
      sxshow: false,
      bmshow: false,
      textshow: true,
    })
  },

  getDept: function () { //获取部门
    var that = this;
    that.setData({
      textshow: false,
    })
    if (that.data.qiquxuanze.id == 0) {
      console.log(11)
      wx.showToast({
        title: '请先选择城市',
        icon: 'none',
      })
      return
    }

    wx.request({
      url: getApp().globalData.url + 'region/getDepts',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        pageNum: 1,
        pageSize: 10000,
        regionId: that.data.qiquxuanze.id
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        if (data.data.code == 200) {
          console.log(data)
          var timer = setTimeout(function () {
            clearTimeout(timer)
            if (getApp().globalData.zixuitme) {
              for (var i = 0; i < data.data.data.length;i++){
                if (JSON.parse(getApp().globalData.zixuitme).deptid == data.data.data[i].DEPTID){
                  that.setData({
                    bm_name: {
                      cityid: data.data.data[i].AREAID,
                      deptid: data.data.data[i].DEPTID,
                      num: data.data.data[i].CNUM,
                      shortname: data.data.data[i].SHORTNAME,
                      name: data.data.data[i].NAME,
                    },
                  })
                  that.getshix_list();
                }
              }
            }else{
              that.setData({
                bm_list: data.data.data,
                bmshow: true,
                shix_list: [],
                sxshow: false,
                sx_name: {
                  name: "请选择要办理的事项"
                },
              })
            }
            
          }, 200)
        } else {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }
      }
    })
  },

  getshix_list: function () {
    var that = this;
    that.setData({
      textshow:false,
    })
    if (that.data.bm_name.name == "请选择要办理的部门") {
      wx.showToast({
        title: '请先选择要办理的部门',
        icon: 'none',
      })
      return
    }
    wx.request({
      url: getApp().globalData.url + 'dept/getItems',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        page: 1,
        size: 1000,
        deptId: that.data.bm_name.deptid,
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if (data.data.code == 200) {
          if (getApp().globalData.zixuitme) {
            var bol = false;
            for (var i = 0; i < data.data.data.length; i++) {
              if (JSON.parse(getApp().globalData.zixuitme).SXID == data.data.data[i].ID) {
                that.setData({
                  sx_name: {
                    name: data.data.data[i].SXZXNAME,
                    deptid: data.data.data[i].DEPTID,
                    id: data.data.data[i].ID,
                    largeitemid: data.data.data[i].LARGEITEMID,
                    smallitemid: data.data.data[i].SMALLITEMID,
                    xzxk: data.data.data[i].XZXK,
                  },
                }) 
                bol = true               
              }
            }
            if (bol == false){
              that.setData({
                sx_name: {
                  name: "请选择要办理的事项"
                },
              })
            }
            getApp().globalData.zixuitme = "";
          }else{
            that.setData({
              shix_list: data.data.data,
              sxshow: true,
            })
          }        
        } else {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }
      }
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})