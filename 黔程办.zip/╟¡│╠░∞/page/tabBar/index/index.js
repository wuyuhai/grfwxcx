var QQMapWX = require('../../../utils/qqmap-wx-jssdk.js');
var qqmapsdk; 

Page({
  data: { 
    overflow:'auto',
    dy_url: 'http://202.98.195.208:82/unified_management',
    isSpeaking: false, //是否正在说话v
    shi_list: [],
    shi_index: 0, //市索引
    qu_list: [], //{"PARENTID":"520000","AREAID":"520100","AREANAME":"贵阳市","LAYER":"2"}
    qu_index: 0, //区索引 
    yuyin_box_show: '', //语音输入框 是否显示 为空不显示 show 为显示
    currentId: 2, //卡片swiper默认样式，第二个 
    show: true,
    vi_btn1: '未关联',
    vi_btn2: '请登录',
    scroll_n2_width: '720rpx', //常用服务订阅的第二个侧滑盒子的宽度  
    num: '9', //
    user_name: '',
    card1: { online: false, userAddr: 520100},
    card2: { online: false, userAddr: 520500, userPass:'118627'}, 
    card3: false,
    scrollTop: 100,
    latitude: '106.62',
    longitude: '26.65',
    cityname1: '贵阳',
    cityname2: '南明',
    day_weather: '阵雨', //今天天气
    day_weather_pic: 'http://app1.showapi.com/weather/icon/day/03.png',
    day_air_temperature: '21', //气温
    day_wind_direction: '西南', //风向
    day_wind_power: '0-2级', //风速
    height: '',
    height2:'',
    // 订阅数组
    subscription: [
    ],
    showmode: {
      show: false,
      phone: '',
    },
    showmode2: {
      show: false,
      phone: '',
    },

    assecced_token: "",
    boltime: true,

    phone: "",
    shoucang_list:[],
    hotitems:[],
  },
  itemchange: function(e) { //滑动swiper 改变样式
    var item_index = e.detail.current + 1;
    // 改变得了数据，但是页面不会有反应
    this.data.show = false;
    // 改变数据。页面中的数据随之改变
    this.setData({
      currentId: item_index,
    });
  },
  //登录了去home
  goto_home: function() {
    wx.switchTab({
      url: '/page/tabBar/home/index',
    })
  },
  //没有登录时点击去登录
  to_login: function() {
    if (wx.getStorageSync("openid") == "") {
      this.setData({
        showmode2: {
          show: false
        }
      })
    } else {
      wx.navigateTo({
        url: '/page/home/pages/home/login/login_select',
      })
    }
    // this.setData({
    //   showmode: {
    //     show: false
    //   }
    // })
  },
  cencel_login: function() {
    this.setData({
      showmode: {
        show: false
      }
    })
  },
  cencel_login2: function() {
    this.setData({
      showmode2: {
        show: false
      }
    })
  },
  getSqData() { //设置市区信息
    //从全局变量里面获取地区
    this.setData({
      shi_list: wx.getStorageSync("shi_list"),
      shi_index: wx.getStorageSync("shi_index"),
      qu_list: wx.getStorageSync("qu_list"),
      qu_index: wx.getStorageSync("qu_index"),
      cityname1: wx.getStorageSync("shi_list")[wx.getStorageSync("shi_index")].AREANAME,
      cityname2: wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREANAME,
    });
  },
  getDyData() { //设置订阅信息
    //从全局变量里面获取地区
    this.setData({
      subscription: wx.getStorageSync("dy_subscription2"),
      height: wx.getStorageSync("dy_subscription2").length,
      num: wx.getStorageSync("dy_num"),
      scroll_n2_width: wx.getStorageSync("dy_scroll_n2_width")
    });
  },
  onLoad: function(options) {
    //创建节点选择器    
    // var query = wx.createSelectorQuery();    //选择id    
    // var that = this;
    // query.select('#cyfw1').boundingClientRect(function (rect) {
    //   console.log(rect.height);
    //   that.setData({ height2: rect.height*3.3913 + 'px' })
    // }).exec();
    var that = this;
    // wx.navigateTo({
    //   url: '/page/index/pages/index/card/chushenyx',
    // })
    //console.log(that.data.latitude);
    if (wx.getStorageSync("uType") == "") {} else { //查看个人或法人状态，如果存在状态补休改，，没有的话设置为默认法人
      wx.setStorageSync("uType", 0);
    }
    qqmapsdk = new QQMapWX({
      key: 'VHHBZ-WO2RD-SDH4P-HIYYS-O6CL3-3ABY7'
    });

    this.getaddres();
    const updateManager = wx.getUpdateManager()
    updateManager.onCheckForUpdate(function(res) {
      //console.log(res.hasUpdate)
    })
    updateManager.onUpdateReady(function() {
      wx.showModal({
        title: '更新提示',
        content: '新版本已经准备好，是否重启应用？',
        success: function(res) {
          if (res.confirm) {
            updateManager.applyUpdate()
          }
        }
      })

    })
    updateManager.onUpdateFailed(function() {
      // 新的版本下载失败
    })
    this.setData({
      phone: wx.getStorageSync('phone')
    })
    if (wx.getStorageSync('wxId')){
      wx.request({
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        url: getApp().globalData.url + 'requestDelegate/handle',
        data: {
          'param': JSON.stringify({
            'wxId': wx.getStorageSync('wxId')
          }),
          'url': that.data.dy_url + '/xcxSubscribe/findAllWithSubscribed'
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data);
          // console.log(getApp().globalData.wxId);
          if (data.statusCode == 200 && data.data.ok) {
            var dy_obj = data.data.obj;
            // 计算第二个侧滑的宽度
            var dingyuges = 0;
            for (var d = 0; d < dy_obj.length; d++) { //计算前九个有几个是没订阅的
              if (dy_obj[d].subscribed == true) {
                dingyuges += 1;
              }
            }
            console.log(dingyuges);
            var item_length = dingyuges - 12; //除了第一个盒子的9个
            var width_num = Math.ceil(item_length / 3) < 0 ? 0 : Math.ceil(item_length / 3); //第二个盒子的列数
            var jiu_num = 0;
            var jiu_num2 = 0;
            var new_array = [];
            for (var i = 0; i < 9; i++) { //计算前九个有几个是没订阅的
              if (dy_obj[i].subscribed == false) {
                jiu_num += 1;
              }
            }
            for (var i = 0; i < dy_obj.length; i++) { //计算九个之后有几个是没订阅的
              if (dy_obj[i].subscribed == false) {
                jiu_num2 += 1;
              } else {
                new_array.push(dy_obj[i]);
              }
            }
            var sub = jiu_num2 - jiu_num;
            wx.setStorageSync("dy_subscription", dy_obj);
            wx.setStorageSync("dy_subscription2", new_array);
            wx.setStorageSync("dy_num", jiu_num + 9 + sub);
            wx.setStorageSync("dy_scroll_n2_width", width_num * 184 + 5 + 'rpx');
            that.getDyData();
          }
        }
      })
    }

    //获取当前热点
    this.gethotitems();
  },

  //获取当前的位置
  getaddres: function(e) {
    var that = this;
    wx.getLocation({
      type: 'wgs84',
      success: function(res) {
        var latitude = res.latitude;
        var longitude = res.longitude;
        that.setData({
          latitude: latitude,
          longitude: longitude,
          markers: [{
            iconPath: "/images/icon/dingwei.png",
            id: 0,
            latitude: latitude,
            longitude: longitude,
            width: 35,
            height: 35
          }],
        });
        that.opikinds(latitude, longitude, that)
      }
    })
  },

  //获取中心点附近的opi
  opikinds: function(latitude, longitude, that) {
    qqmapsdk.reverseGeocoder({
      location: {
        latitude: latitude,
        longitude: longitude,
      },
      get_poi: 1,
      success: function(addressRes) {
        if (addressRes.result.address_component.province == "贵州省") {
          var qu_index, shi_index;
          //console.log(that.data.qu_list, addressRes.result.address_component.district)
          for (var i in that.data.shi_list) {
            if (that.data.shi_list[i].AREANAME == addressRes.result.address_component.city) {
              shi_index = i;
              wx.setStorageSync("shi_index", shi_index);
              wx.setStorageSync("qu_index", 0);
              //设置市下面的区
              var shi_obj = wx.getStorageSync("shi_list")[shi_index]; //获取市
              var pid = shi_obj.AREAID; //拿到当前市的id
              var list = [];
              var all_list = wx.getStorageSync("all_list");
              for (var i = 0; i < all_list.length; i++) {
                if (pid == all_list[i].PARENTID || pid == all_list[i].AREAID) {
                  list.push(all_list[i]);
                }
              }
              wx.setStorageSync("qu_list", list);
            }
          }
          var qu_list = wx.getStorageSync("qu_list", list);
          for (var j in qu_list) {
            if (qu_list[j].AREANAME == addressRes.result.address_component.district) {
              qu_index = j;
            }
          }
          that.setData({
            shi_index: shi_index,
            qu_index,
            qu_index,
            qu_list: qu_list,
            // city: addressRes.result.address_component.city,
            // district: addressRes.result.address_component.district,
          })
          that.getWeather();
        } else {
          var data = wx.getStorageSync("all_list");
          var list1 = [];
          var list2 = [];
          list1.push({
            AREAID: "520000",
            AREANAME: "贵州省"
          })
          for (var i = 0; i < data.length; i++) {
            if (data[i].PARENTID == '520000' && data[i].PARENTID != data[i].AREAID) { //设置贵州省的所有市
              list1.push(data[i]);
            }
            if (data[i].PARENTID == '520000') { //设置贵阳市的所有区
              list2.push(data[i]);
            }
          }
          wx.setStorageSync("qu_list", list2);
          wx.setStorageSync("shi_list", list1);
          wx.setStorageSync("shi_index", 0);
          wx.setStorageSync("qu_index", 10);
          that.getSqData();
        }
      }
    })
  },

  onReady: function() {
    // 页面渲染完成
  },
  pickerSHI: function(e) { //选择市后修改数据
    this.setData({
      selfshichangebol: true
    })
    console.log(e)
    getApp().pickerSHI(e);
    this.getSqData();
    this.getWeather();
  },
  pickerQU: function(e) { //选择区后修改数据
    this.setData({
      selfquchangebol: true
    })
    getApp().pickerQU(e);
    this.getSqData();
    this.getWeather();
  },
  getWeather: function() {
    var city = this.data.cityname1;
    var cityname1 = city.replace(/市/gi, '');
    var pf_cityname = cityname1.replace(/州/gi, '');
    var str = this.data.cityname2;
    var str2 = str.replace(/县/gi, '');
    var str3 = str2.replace(/区/gi, '');
    var str4 = str3.replace(/开发区/gi, '');
    var cityname2 = str4.replace(/市/gi, '');
    var areaid = "";
    var that = this;
    // console.log(city);
    // console.log(pf_cityname);
    // console.log(cityname2);
    // 20190109

    // 20190109 end
    //先根据地名去获取地址id，，有些地名直接获取不了天气（六盘水的钟山和广西的钟山有重复）
    var area = JSON.stringify({
      "showapi_appid": '70764', //这里需要改成自己的appid、、这里用到的showapi_appid和sign是我自己注册的
      "showapi_sign": '6ed0837a978b404b8be26867148d976e',
      // "showapi_appid": '707833',
      // "showapi_sign":'b5a13df3f7d54be3a2b19d3ad81f0e55',
      "area": cityname2,
    })
    var area2 = JSON.stringify({
      "showapi_appid": '70764', //这里需要改成自己的appid
      "showapi_sign": '6ed0837a978b404b8be26867148d976e',
      "area": cityname1,
    })
    wx.request({ //第一个请求获取地址id，，如果没有找到这个id用上一级的id
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        'param': area,
        'url': 'http://route.showapi.com/9-3'
      }, //地名获取areaid
      method: 'post',
      dataType: 'json',
      success: function(data) {
        console.log(data);//如果获取到用这个id，，获取不到就获取上一级的areaid（双龙航空港经济区就没有）
        var list = data.data.showapi_res_body.list;
        if (list.length > 0) { //还可能获取到其他省的同名城市
          for (var i = 0; i < list.length; i++) {
            //拿到贵州的城市id
            if (list[i].prov == '贵州') {
              areaid = list[i].areaid;
            }
          }
          var obj_s = {
            "showapi_appid": '70764', //这里需要改成自己的appid
            "showapi_sign": '6ed0837a978b404b8be26867148d976e', //这里需要改成自己的应用的密钥secret
            "from": "5",
            // "lng": '106.63',//经纬度//用经纬度则注释下面的areaid
            // "lat": '26.65',
            "areaid": areaid, //地区id或名称必填其中一个
            // "area": cityname2,
          }
          var obj_s2 = JSON.stringify(obj_s);
          // 第二步,用areaid去请求获取天气
          wx.request({
            url: getApp().globalData.url + 'weather/9-2?areaid=' + areaid,
            header: {
              'Content-Type': getApp().globalData.contentType
            },
            method: 'get',
            dataType: 'json',
            success: function (data) {
              console.log(data);
              if (data.data.code==200){
                that.setData({
                  day_weather_pic: data.data.data.showapi_res_body.now.weather_pic,
                  day_air_temperature: data.data.data.showapi_res_body.now.temperature,
                  day_weather: data.data.data.showapi_res_body.now.weather,
                  day_wind_direction: data.data.data.showapi_res_body.now.wind_direction,
                  day_wind_power: data.data.data.showapi_res_body.now.wind_power.substring(0, 4),
              })
              }
            }
          }) //ajax end
        } else {
          wx.request({
            url: getApp().globalData.url + 'requestDelegate/handle',
            header: {
              'Content-Type': getApp().globalData.contentType
            },
            data: {
              'param': area2,
              'url': 'http://route.showapi.com/9-3'
            }, //地名获取areaid
            method: 'post',
            dataType: 'json',
            success: function(data) {
              // console.log(data);//如果获取到用这个id，，获取不到就获取上一级的areaid（双龙航空港经济区就没有）
              var list2 = data.data.showapi_res_body.list;
              if (list2.length > 0) { //还可能获取到其他省的同名城市
                for (var i = 0; i < list2.length; i++) {
                  //拿到贵州的城市
                  if (list2[i].prov == '贵州' && list2[i].area == cityname1) {
                    areaid = list2[i].areaid;
                  }
                }
                var obj_s = {
                  "showapi_appid": '70764', //这里需要改成自己的appid
                  "showapi_sign": '6ed0837a978b404b8be26867148d976e', //这里需要改成自己的应用的密钥secret
                  "from": "5",
                  "areaid": areaid, //地区id或名称必填其中一个
                }
                var obj_s2 = JSON.stringify(obj_s);
                wx.request({
                  url: getApp().globalData.url + 'requestDelegate/handle',
                  header: {
                    'Content-Type': getApp().globalData.contentType
                  },
                  data: {
                    'param': obj_s2,
                    'url': 'http://route.showapi.com/9-2'
                  }, //地区id请求地址
                  method: 'post',
                  dataType: 'json',
                  success: function(data) {
                    console.log('天气请求成功' + cityname2);
                    that.setData({
                      day_weather_pic: data.data.data.showapi_res_body.now.weather_pic,
                      day_air_temperature: data.data.data.showapi_res_body.now.temperature,
                      day_weather: data.data.data.showapi_res_body.now.weather,
                      day_wind_direction: data.data.data.showapi_res_body.now.wind_direction,
                      day_wind_power: data.data.data.showapi_res_body.now.wind_power.substring(0, 4),
                    })
                  }
                }) //ajax end
              }
              // console.log(areaid);
            }
          }) //ajax end
        }
        // console.log(areaid);
      }
    }) //ajax end
  },
  onShow: function() {
    if (wx.getStorageSync("dy_subscription2")){
      var dw_num = wx.getStorageSync("dy_subscription2").length;
   }else{
      var dw_num = 7;
   }
    var that = this;
    wx.getSetting({
      success: function(res) {
        if (res.authSetting['scope.userInfo']) {} else {
          that.setData({
            showmode2: {
              show: true
            }
          })
        }
      }
    })
    that.setData({
      assecced_token: wx.getStorageSync("token"),
      user_name: wx.getStorageSync("user_name"),
      height: dw_num,
      showmode: {
        show: false,
        phone: wx.getStorageSync("phone"),
      },
    })
    //获取地区  
    if (wx.getStorageSync("qu_list").length == 0) {
      wx.request({
        url: getApp().globalData.url + 'region/getRegions',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          pageNum: 1,
          pageSize: 10000
        },
        method: 'post',
        dataType: 'json',
        success: function(data) {
          console.log(data)
          if (data.data.code == 200) {
            var list1 = [];
            var list2 = [];
            list1.push({
              AREAID: "520000",
              AREANAME: "贵州省"
            })
            for (var i = 0; i < data.data.data.length; i++) {
              if (data.data.data[i].PARENTID == '520000' && data.data.data[i].PARENTID != data.data.data[i].AREAID) { //设置贵州省的所有市
                list1.push(data.data.data[i]);
              }
              if (data.data.data[i].PARENTID == '520100') { //设置贵阳市的所有区
                list2.push(data.data.data[i]);
              }
            }
            wx.setStorageSync("qu_list", list2);
            wx.setStorageSync("shi_list", list1);
            wx.setStorageSync("all_list", data.data.data);
            wx.setStorageSync("shi_index", 0);
            wx.setStorageSync("qu_index", 0);
            that.getSqData();
          }
        }
      })
    } else {
      that.getSqData();
    }

    //获取我的订阅

    // setTimeout(function () {
      //要延时执行的代码
    if (wx.getStorageSync("dy_subscription").length == 0) {
      console.log(2)
      wx.request({
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        url: getApp().globalData.url + 'requestDelegate/handle',
        data: {
          'param': JSON.stringify({
            'wxId': wx.getStorageSync('wxId')
          }),
          'url': that.data.dy_url + '/xcxSubscribe/findAllWithSubscribed'
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data);
          // console.log(getApp().globalData.wxId);
          if (data.statusCode == 200 && data.data.ok) {
            var dy_obj = data.data.obj;
            // 计算第二个侧滑的宽度
            var dingyuges = 0;
            for (var d = 0; d < dy_obj.length; d++) { //计算前九个有几个是没订阅的
              if (dy_obj[d].subscribed == true) {
                dingyuges += 1;
              }
            }
            console.log(dingyuges);
            var item_length = dingyuges - 12; //除了第一个盒子的9个
            var width_num = Math.ceil(item_length / 3) < 0 ? 0 : Math.ceil(item_length / 3); //第二个盒子的列数
            var jiu_num = 0;
            var jiu_num2 = 0;
            var new_array = [];
            for (var i = 0; i < 9; i++) { //计算前九个有几个是没订阅的
              if (dy_obj[i].subscribed == false) {
                jiu_num += 1;
              }
            }
            for (var i = 0; i < dy_obj.length; i++) { //计算九个之后有几个是没订阅的
              if (dy_obj[i].subscribed == false) {
                jiu_num2 += 1;
              } else {
                new_array.push(dy_obj[i]);
              }
            }
            var sub = jiu_num2 - jiu_num;
            wx.setStorageSync("dy_subscription", dy_obj);
            wx.setStorageSync("dy_subscription2", new_array);
            wx.setStorageSync("dy_num", jiu_num + 9 + sub);
            wx.setStorageSync("dy_scroll_n2_width", width_num * 184 + 5 + 'rpx');
            that.getDyData();
          }
        }
      })
    } else {
      that.getDyData();
      }
    // }, 2000) 
    if (wx.getStorageSync("wxId") && wx.getStorageSync("user_name")){
      // 获取收藏
      wx.request({
        url: getApp().globalData.url + 'userFavorItem/getList',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          wxId: wx.getStorageSync('wxId'),
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data);
          if (data.data.code == 200) {
            if (data.data.data.length >0) {
              var colle_arr = [];
              //打乱数组
              var list = data.data.data.sort(() => Math.random() - 0.5);
              for (var i = 0; i < (list.length > 4 ? 4 : list.length); i++) {
                // var charIndex = Math.floor(Math.random() * list.length);
                // console.log(charIndex);
                colle_arr.push(list[i]);
              }
              that.setData({
                shoucang_list: colle_arr,
              })
            }
          }
        }
      }) //ajax end
      // 获取收藏 end
      wx.request({
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        url: getApp().globalData.url + 'requestDelegate/handle',
        data: {
          'param': JSON.stringify({
            'wxId': wx.getStorageSync('wxId')
          }),
          'url': that.data.dy_url + '/xcxSubscribe/findAllWithSubscribed'
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data);
          // console.log(getApp().globalData.wxId);
          if (data.statusCode == 200 && data.data.ok) {
            var dy_obj = data.data.obj;
            // 计算第二个侧滑的宽度
            var dingyuges = 0;
            for (var d = 0; d < dy_obj.length; d++) { //计算前九个有几个是没订阅的
              if (dy_obj[d].subscribed == true) {
                dingyuges += 1;
              }
            }
            console.log(dingyuges);
            var item_length = dingyuges - 12; //除了第一个盒子的9个
            var width_num = Math.ceil(item_length / 3) < 0 ? 0 : Math.ceil(item_length / 3); //第二个盒子的列数
            var jiu_num = 0;
            var jiu_num2 = 0;
            var new_array = [];
            for (var i = 0; i < 9; i++) { //计算前九个有几个是没订阅的
              if (dy_obj[i].subscribed == false) {
                jiu_num += 1;
              }
            }
            for (var i = 0; i < dy_obj.length; i++) { //计算九个之后有几个是没订阅的
              if (dy_obj[i].subscribed == false) {
                jiu_num2 += 1;
              } else {
                new_array.push(dy_obj[i]);
              }
            }
            var sub = jiu_num2 - jiu_num;
            wx.setStorageSync("dy_subscription", dy_obj);
            wx.setStorageSync("dy_subscription2", new_array);
            wx.setStorageSync("dy_num", jiu_num + 9 + sub);
            wx.setStorageSync("dy_scroll_n2_width", width_num * 184 + 5 + 'rpx');
            that.getDyData();
          }
        }
      })
    }else{
      wx.request({
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        url: getApp().globalData.url + 'requestDelegate/handle',
        data: {
          'param': JSON.stringify({
            'wxId': '123456'
          }),
          'url': that.data.dy_url + '/xcxSubscribe/findAllWithSubscribed'
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data);
          // console.log(getApp().globalData.wxId);
          if (data.statusCode == 200 && data.data.ok) {
            var dy_obj = data.data.obj;
            // 计算第二个侧滑的宽度
            var dingyuges = 0;
            for (var d = 0; d < dy_obj.length; d++) { //计算前九个有几个是没订阅的
              if (dy_obj[d].subscribed == true) {
                dingyuges += 1;
              }
            }
            console.log(dingyuges);
            var item_length = dingyuges - 12; //除了第一个盒子的9个
            var width_num = Math.ceil(item_length / 3) < 0 ? 0 : Math.ceil(item_length / 3); //第二个盒子的列数
            var jiu_num = 0;
            var jiu_num2 = 0;
            var new_array = [];
            for (var i = 0; i < 9; i++) { //计算前九个有几个是没订阅的
              if (dy_obj[i].subscribed == false) {
                jiu_num += 1;
              }
            }
            for (var i = 0; i < dy_obj.length; i++) { //计算九个之后有几个是没订阅的
              if (dy_obj[i].subscribed == false) {
                jiu_num2 += 1;
              } else {
                new_array.push(dy_obj[i]);
              }
            }
            var sub = jiu_num2 - jiu_num;
            wx.setStorageSync("dy_subscription", dy_obj);
            wx.setStorageSync("dy_subscription2", new_array);
            wx.setStorageSync("dy_num", jiu_num + 9 + sub);
            wx.setStorageSync("dy_scroll_n2_width", width_num * 184 + 5 + 'rpx');
            that.getDyData();
          }
        }
      })
    }
    if (this.data.user_name != '') {
      this.getmycards()
    }else{
      this.setData({
        card_arr: []
      })
    }
  },

  //页面跳转
  navigatetos: function(e) {
    var that = this;
    if (e.currentTarget.dataset.kind == 2) {
      if (that.data.boltime == true) {
        that.setData({
          boltime: false,
        })
        wx.navigateTo({
          url: e.currentTarget.dataset.url,
        })
        var timer = setTimeout(function() {
          clearTimeout(timer);
          that.setData({
            boltime: true,
          })
        }, 1000)
      }
      return
    }
    if (wx.getStorageSync("token") == "") {
      this.setData({
        // overflow: 'hidden',
        showmode: {
          show: true,
          phone: wx.getStorageSync("phone")
        }
      })
    } else {
      wx.navigateTo({
        url: e.currentTarget.dataset.url,
      })
    }
  },
  getmycards: function() {
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: {'Content-Type': getApp().globalData.contentType},
      data: {
        'param': JSON.stringify({
          wxId: userId
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/findByWxId'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.obj){
          var data = data.data.obj;
          for(var i=0;i<data.length;i++){
            data[i].remark = JSON.parse(data[i].remark);
            // data[i].userData = JSON.parse(data[i].userData);
          }
          that.setData({
            card_arr: data,
          })
        }
      }
    })
  },

  //获取用户手机号码
  getPhoneNumber: function(e) { //点击获取手机号码按钮
    var that = this;
    console.log(e);
    wx.login({
      success: data => {
        console.log(data)
        console.log(e.detail.encryptedData)
        var ency = e.detail.encryptedData;
        var iv = e.detail.iv;
        if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
          // 用户取消了获取手机号
        } else { //同意授权
          wx.request({
            method: "POST",
            // url: 'https://face.fotoit.cn:84/UrbanService/user/decodeUserInfo',  //这个解密地址能用
            url: getApp().globalData.url + 'user/decodeUserInfo',
            data: {
              code: data.code,
              encryptedData: e.detail.encryptedData,
              iv: iv,
              wxType: 0
            },
            header: {
              'content-type': getApp().globalData.contentType,
            },
            success: (res) => {
              console.log(res);
              if (res.data.code == 200) { //code好像只有线上的可以，发布之后如果获取手机号成功会返回200，，跳转选择登陆
                if (res.data.data.phoneNumber) {
                  var phone = res.data.data.phoneNumber.toString();
                  getApp().savewxinfo(res.data.data.phoneNumber); //把用户信息传到后台保存
                  wx.setStorageSync("phone", phone);
                  that.setData({
                    showmode: {
                      show: false,
                      phone: phone,
                    }
                  })
                  wx.navigateTo({
                    url: '/page/home/pages/home/login/login_select',
                  })
                  // wx.showToast({
                  //   title: "解密成功" + phone,
                  //   icon: 'none'
                  // });
                } else {
                  wx.showToast({
                    title: "解密失败",
                    icon: 'none'
                  });
                  that.setData({
                    showmode: {
                      show: false,
                      phone: '',
                    }
                  })
                }
              }
            },
            fail: function(res) {
              console.log("解密失败~~~~~~~~~~~~~");
              console.log(res);
              wx.showToast({
                title: '获取用户手机失败，请再试一次',
                icon: 'none'
              });
            }
          });
        }
      }
    })
  },
  bindGetUserInfo: function(e) {
    console.log(e);

    var that = this;
    this.setData({
      showmode2: {
        show: false,
        phone: '',
      }
    })
    //console.log(e.detail.userInfo)
    if (e.detail.userInfo) {
      wx.login({
        success: data => {
          wx.getUserInfo({
            withCredentials: true,
            success: function(res) {
              console.log(res)
              wx.request({
                // url: 'https://face.fotoit.cn:84/UrbanService/user/decodeUserInfo', //这个解密地址能用
                url: getApp().globalData.url + 'user/decodeUserInfo',
                header: {
                  'Content-Type': getApp().globalData.contentType
                },
                data: {
                  code: data.code,
                  encryptedData: res.encryptedData,
                  iv: res.iv,
                }, //传微信id  unionId
                method: 'post',
                dataType: 'json',
                success: function(reslut) {
                  console.log(reslut);
                  // wx.showToast({ title: reslut.data.code.toString(), icon: 'none' });
                  if (reslut.data.code == 200) {
                    // wx.showToast({
                    //   title: '获取用户信息成功',
                    //   icon: 'none'
                    // });
                    // wx.setStorageSync("token", reslut.data.data.token);
                    // wx.setStorageSync("wxId", reslut.data.data.unionId);
                    wx.setStorageSync("wxId", reslut.data.data.openId);
                    wx.setStorageSync("openid", reslut.data.data.openId);
                    wx.setStorageSync("userdata", reslut.data.data);
                    getApp().globalData.wxId = reslut.data.data.openId;

                    console.log(getApp().globalData.wxId)
                  } else {
                    wx.showToast({
                      title: reslut.data.msg, //开发工具测试返回的是这个，，上线了之后只要解密地址授权，应该是上面成功的提示
                      icon: 'none'
                    });
                  }
                }
              }) //ajax end
            }
          })
        }
      })
    }
  },

  //热点事项
  gethotitems:function(){
    // console.log('开始调用hot')
    var that = this;
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        'param': JSON.stringify({
          
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxHotItemSort/list'
      },//实际调用接口
    // wx.request({
    //   url:'https://face.fotoit.cn:84/unified_management/xcxHotItemSort/list',
    //   header: {
    //     'Content-Type': getApp().globalData.contentType
    //   },
    //   data: {},
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if (data.data.ok == true){
          that.setData({
            hotitems: data.data.obj
          })
        }
      },
      fail:function(e){
        console.log(e);
      }
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
   
  }

})