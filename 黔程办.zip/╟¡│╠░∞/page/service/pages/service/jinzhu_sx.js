var page = 2;
var has_more = true;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wxId:'',
    phone:'',
    email:"",
    pageIndex: '1',
    pageSize: '20',
    itemList:[],
    count:2,
    addrname:''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
this.setData({
  wxId: wx.getStorageSync("wxId"),
  phone: wx.getStorageSync("phone"),
  email: wx.getStorageSync("email"),
})
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      addrname: wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREANAME,
    })
     page = 2;
     has_more = true;
    this.setData({
      wxId: wx.getStorageSync("wxId"),
      phone: wx.getStorageSync("phone"),
      email: wx.getStorageSync("email"),
    })
    var that = this;
    var obj_s2 = JSON.stringify({ "areaId": wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID, "pageIndex": that.data.pageIndex, "pageSize": that.data.pageSize });
    wx.request({
      url: getApp().globalData.url + 'statistics/item',//查询公用后台接口
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      // data: { 'param': obj_s2, 'url': 'http://59.215.229.116/UrbanService_GA/statistics/businessState' },//实际调用接口
      data:{
        pageNum:1,
        pageSize:20,
        regionId: wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID
      }
      ,
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.code == 200) {
          that.setData({
            count: data.data.data.count,
            itemList: data.data.data.list,
          });
        } else {
          wx.showToast({ title: data.data.msg, icon: 'none' });
        }
      }
    }) //ajax end
  },
  onReachBottom: function () {
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    if (has_more) {
      wx.request({
        url: getApp().globalData.url + 'statistics/item',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        // data: { 'param': obj_s2, 'url': 'http://59.215.229.116/UrbanService_GA/statistics/businessState' },
        data: {
          pageNum: page,
          pageSize: 20,
          regionId: wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data)
          wx.hideLoading();
          if (data.data.code == 200) {
            var array = that.data.itemList;
            var list = data.data.data.list;
            for (var i = 0; i < list.length; i++) {
              array.push(list[i]);
            }
            that.setData({
              itemList: array
            });
          } else {
            wx.showToast({ title: data.data.msg, icon: 'none' });
          }
          page = page + 1;
          if (data.data.data.list.length < 20) {
            has_more = false;
          }
        },
        fail: function () {
          wx.showToast({
            title: '请检查网络连接',
            icon: 'none'
          });
        }
      })
    } else {
      wx.showToast({
        title: '没有更多了',
        icon: 'none'
      });
    }
  },
})