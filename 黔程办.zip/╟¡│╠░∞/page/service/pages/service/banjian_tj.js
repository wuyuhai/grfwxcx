// pages/public/no_open.js
var page = 2;
var has_more = true;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    areaId:'520000',//地区id
    toView: "昨日办件",
    d_shoul_num:'--',
    d_no_shoul_num: '--',//天统计数量
    d_juedxk_num: '--',
    d_noxk_num: '--',
    d_yicx_num: '--',
    d_zhengzbl_num: '--',
    m_no_shoul_num:'--',//月度统计数量
    m_shoul_num: '--',
    m_juedxk_num:'--',
    m_noxk_num:'--',
    m_yicx_num:'--',
    m_zhengzbl_num:'--',
    y_no_shoul_num: '--',//年度统计数量
    y_shoul_num: '--',
    y_juedxk_num: '--',
    y_noxk_num: '--',
    y_yicx_num: '--',
    y_zhengzbl_num: '--',
    years:'',
    months:'',
    yesterday:''
  },
  changeView: function (e) {
    var that = this;
    this.setData({
      toView: e.currentTarget.id,
      // channelId: e.currentTarget.dataset.index,
    })
    // that.onShow();
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {


    //3秒返回
    // setTimeout(function () {
    //   wx.navigateBack();  //返回上一个页面
    // }, 3000)

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var obj_s2 = JSON.stringify({ "areaId": wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID, });
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: { 'param': obj_s2, 'url': 'http://59.215.229.116/UrbanService_GA/statistics/deptBusinessCount' },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if (data.data.code == 200) {
          that.setData({
            yesterday: data.data.data.yesterday,
            months: data.data.data.months,
            years: data.data.data.years,
            total: data.data.data.total,
          });
        } else {
          wx.showToast({ title: data.data.msg, icon: 'none' });
        }
      }
    }) //ajax end
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {


  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})