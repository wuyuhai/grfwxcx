Page({

  /**
   * 页面的初始数据
   */
  data: {
    wxId:'',
    phone:'',
    email:"",
    pageIndex: '1',
    pageSize: '20',
    itemList:[],
    count:0,
    addrname:'',
    year1: 0,
    year2: 0,
    month1: 0,
    month2:0,
    yerstoday1: 0,
    yerstoday2:0
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
this.setData({
  wxId: wx.getStorageSync("wxId"),
  phone: wx.getStorageSync("phone"),
  email: wx.getStorageSync("email"),
})
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      addrname: wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREANAME,
    })
    this.setData({
      wxId: wx.getStorageSync("wxId"),
      phone: wx.getStorageSync("phone"),
      email: wx.getStorageSync("email"),
    })
    var that = this;
    var date = new Date();
    var Y = date.getFullYear();
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    var D = date.getDate() < 10 ? '0' + date.getDate() + ' ' : date.getDate();
    wx.request({//咨询
      header: {'Content-Type': getApp().globalData.contentType,},
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: {'param': JSON.stringify({ data: {
            "checktime": Y,
            "sysid": 4 }}),
        'headers': JSON.stringify({'apiCode': '100W1324','netType': '1'}),
        'url': getApp().globalData.sousuo_url + '/postJson'
      },
      method: 'post', dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.head.code == 200 && data.data.result) {
          that.setData({
            count: data.data.result.total,
            year1: data.data.result.total,
          })
        }
      }
    }) //ajax end
    wx.request({//咨询
      header: { 'Content-Type': getApp().globalData.contentType, },
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: {
        'param': JSON.stringify({
          data: {
            "checktime": Y+'-'+M,
            "sysid": 4
          }
        }),
        'headers': JSON.stringify({ 'apiCode': '100W1324', 'netType': '1' }),
        'url': getApp().globalData.sousuo_url + '/postJson'
      },
      method: 'post', dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.head.code == 200 && data.data.result.total) {
          that.setData({
            month1: data.data.result.total,
          })
        }
      }
    }) //ajax end
    wx.request({//咨询
      header: { 'Content-Type': getApp().globalData.contentType, },
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: {
        'param': JSON.stringify({
          data: {
            "checktime": Y+'-'+M+'-'+D,
            "sysid": 4
          }
        }),
        'headers': JSON.stringify({ 'apiCode': '100W1324', 'netType': '1' }),
        'url': getApp().globalData.sousuo_url + '/postJson'
      },
      method: 'post', dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.head.code == 200 && data.data.result.total) {
          that.setData({
            yerstoday1: data.data.result.total,
          })
        }
      }
    }) //ajax end
    // var obj_s2 = JSON.stringify({ "areaid": wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID, "type": 1});
    // wx.request({
    //   url: getApp().globalData.sousuo_url+'/zxts',//查询公用后台接口
    //   header: {
    //     'Content-Type': getApp().globalData.contentType
    //   },
    //   data: { areaid: wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID,type:1},//实际调用接口
    //   method: 'post',
    //   dataType: 'json',
    //   success: function (data) {
    //     console.log(data);
    //     if(data.data.code == 200){
    //       var obj = data.data.data;
    //       that.setData({
    //         count: obj[0],
    //         year1: obj[3],
    //         year2: obj[4],
    //         month1: obj[5],
    //         month2: obj[6],
    //         yerstoday1: obj[7],
    //         yerstoday2: obj[8]
    //       })
    //     }
    //   }
    // }) //ajax end
  },
})