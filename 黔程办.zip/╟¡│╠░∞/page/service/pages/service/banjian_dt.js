// pages/public/no_open.js
var page = 2;
var has_more = true;
Page({

  /**
   * 页面的初始数据 
   */
  data: {
    name:'邓威',
    idCardNumber:'522427199311297013',
    pageIndex:'1',
    pageSize:'20',
    banjian_list:[],
    count:220,//地区总条数
    addrname:'',
    dw:'asdasdv234sdhlkcsdv45s6d451321',
  },
  login:function(){
    var that = this;
    wx.request({
      url: getApp().globalData.url + 'user/getUserInfo',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        key: '522427199311297013',
        keyType: '3',
        wxId: '88648',
      }, //传微信id  unionId
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        // 登录成功
        if (data.data.code == 200) {
          wx.hideLoading();
          wx.showToast({ title: '登录成功！', icon: 'none' });
          wx.setStorageSync("token", data.data.data.token);
          wx.setStorageSync("wxId", data.data.data.wx_id);
          wx.setStorageSync("user_name", data.data.data.USER_NAME);
          wx.setStorageSync("idCardNumber", that.data.idCardNumber);
          wx.setStorageSync("login_name", that.data.name);
          wx.setStorageSync("id", data.data.data.id);
        //   wx.switchTab({
        //     url: '/page/tabBar/home/index',
        // })
        }else{
          wx.showToast({ title: data.data.msg, icon: 'none' });
        }
      }
    }) //ajax end
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      addrname: wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREANAME,
    })
    page = 2;
    has_more = true;
    var that = this;
    var obj_s2 = JSON.stringify({ "areaId": wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID, "pageIndex": that.data.pageIndex, "pageSize": that.data.pageSize });
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: { 'param': obj_s2, 'url': 'http://59.215.229.116/UrbanService_GA/statistics/businessState' },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        for(var i=0;i<20;i++){
          data.data.data.list[i].createtime = data.data.data.list[i].createtime.substring(0, 10);
        }
        if (data.data.code == 200) {
          that.setData({
            banjian_list:data.data.data.list,
            count:data.data.data.count,
          });
        } else {
          wx.showToast({ title: data.data.msg, icon: 'none' });
        }
      }
    }) //ajax end
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {


  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    var obj_s2 = JSON.stringify({ "areaId": wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID, "pageIndex": page.toString(), "pageSize": that.data.pageSize });
    if (has_more) {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: { 'param': obj_s2, 'url': 'http://59.215.229.116/UrbanService_GA/statistics/businessState' },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data)
          wx.hideLoading();
          for (var i = 0; i < 20; i++) {
            data.data.data.list[i].createtime = data.data.data.list[i].createtime.substring(0, 10);
          }
          if (data.data.code == 200) {
            var array = that.data.banjian_list;
            var list = data.data.data.list;
            for (var i = 0; i < list.length; i++) {
              array.push(list[i]);
            }
            that.setData({
              banjian_list: array
            });
          } else {
            wx.showToast({ title: data.data.msg, icon: 'none' });
          }
          page = page + 1;
          if (data.data.data.list.length < 20) {
            has_more = false;
          }
        },
        fail: function () {
          wx.showToast({
            title: '请检查网络连接',
            icon: 'none'
          });
        }
      })
    } else {
      wx.showToast({
        title: '没有更多了',
        icon: 'none'
      });
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})