// pages/public/no_open.js
var page = 2;
var has_more = true;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    work: [],//工作动态
    news_url: 'http://202.98.195.208:83/news_climbing/getNews',
    channelId:'10'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      channelId: options.channelId,
    })
    // 获取工作动态
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        'param': JSON.stringify({
        }), 'url': that.data.news_url + '?page=1&size=20&type=' + options.channelId
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        wx.hideLoading();
        console.log(data);
        if (data.data.content) {
          that.setData({
            work: data.data.content,
          })
        }
      }
    }) //ajax end
    // wx.request({
    //   url: getApp().globalData.url + 'news/getList',
    //   header: {
    //     'Content-Type': getApp().globalData.contentType
    //   },
    //   data: {
    //     channelId: options.channelId,
    //     regionId: wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID,
    //     pageNum: '1',
    //     pageSize: '10'
    //   }, //传微信id  unionId
    //   method: 'post',
    //   dataType: 'json',
    //   success: function (data) {
    //     console.log(data);
    //     if (data.data.code == 200) {
    //       that.setData({
    //         work: data.data.data,
    //       })
    //     }
    //   }
    // }) //ajax end

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    has_more = true;
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {


  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    if (has_more) {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
          }), 'url': that.data.news_url + '?page=1&size='+page+'&type=' + that.data.channelId
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          if (data.data.content){
          var list = that.data.work;
          for (var i = 0; i < data.data.content.length; i++) {
            list.push(data.data.content[i]);
          }
          page = page + 1;
          that.setData({
            work: list
          })
          if (data.data.content.length < 20) {
            has_more = false;
          }
        }
        },
        fail: function () {
          wx.showToast({
            title: '请检查网络连接',
            icon: 'none'
          });
        }
      })
    } else {
      wx.showToast({
        title: '没有更多了',
        icon: 'none'
      });
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})