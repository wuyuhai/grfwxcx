// pages/public/no_open.js
var page = 2;
var has_more=true;
Page({

  /**
   * 页面的初始数据
   */
  data: {


    rdsx: [] //热点事项
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {


    //3秒返回
    // setTimeout(function () {
    //   wx.navigateBack();  //返回上一个页面
    // }, 3000)

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    if (wx.getStorageSync("hot_item_list").length == 0) {
      getApp().get_hot_item();
      setTimeout(function() {
        that.setData({
          rdsx: wx.getStorageSync("hot_item_list")
        })
      }, 3000)

    } else {
      that.setData({
        rdsx: wx.getStorageSync("hot_item_list")
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {


  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    wx.showLoading({
      title: '加载中',
    })
    var that=this;
    if(has_more){
    wx.request({
      url: getApp().globalData.url + 'item/getHotItems',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        pageNum: page,
        pageSize: 10,
        regionId: wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID
      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        wx.hideLoading()
        var list = that.data.rdsx;
        for (var i = 0; i < data.data.data.length; i++) {
          list.push(data.data.data[i]);
        }
        page = page + 1;
        that.setData({
          rdsx: list
        })
        if (data.data.data.length<10){
          has_more=false;
        }

      },
      fail: function() {
        wx.showToast({
          title: '请检查网络连接',
          icon: 'none'
        });
      }
    })
    }else{
      wx.showToast({
        title: '没有更多了',
        icon: 'none'
      });
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})