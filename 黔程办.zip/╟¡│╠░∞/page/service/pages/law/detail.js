
Page({

  /**
   * 页面的初始数据
   */
  data: {
    title: '',
    department: '',
    publishDate: '',
    executeDate: '',
    effect: '',
    lawId: '',
    lawHtml:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;
    //获取该法律的信息
    wx.request({
      url: getApp().globalData.url + 'law/findOneInfo',//上线的话必须是https，没有appId的本地请求貌似不受影响  
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        lawId: options.id,
        apiKey: 'wx_CityService',
        apiSign: getApp().getSign(),
        apiTimestamp: getApp().getyyyyMMddhh()
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        if (data.data.code == 200) {
          that.setData({//把选中值放入判断值
            title: data.data.data.title,
            department: data.data.data.department,
            publishDate: data.data.data.publishDate,
            executeDate: data.data.data.executeDate,
            effect: data.data.data.effect,
            lawId: options.id
          });
        }
      }
    })

    //获取该法律的html
    wx.request({
      url: getApp().globalData.url + 'law/findByLawId',//上线的话必须是https，没有appId的本地请求貌似不受影响  
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        lawId: options.id,
        apiKey: 'wx_CityService',
        apiSign: getApp().getSign(),
        apiTimestamp: getApp().getyyyyMMddhh()
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
      var html=  data.data.data.lawHtml;
      var str2 = html.replace(/<\/br>/g, '<br>');
       that.setData({
         lawHtml: str2
       })
      
      }
    })



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {


  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})