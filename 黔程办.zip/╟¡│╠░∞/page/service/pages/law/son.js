
var page, show_type, findKey, hasmore;//show_type不等于0获取子类   =0搜索的结果
// pages/law/son.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show_input: true,
    fl: [//法律    
    ]
    , title: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    page = 1;
    hasmore = true;

    var that = this;
    show_type = options.type
    if (options.type > 0) {//>0获取子类   =0搜索的结果
      var lawType = options.type;
      if (lawType == 2) {
        that.setData({//把选中值放入判断值
          title: '法律'
        });

      }
      if (lawType == 3) {
        that.setData({//把选中值放入判断值
          title: '行政法规'
        });

      }
      if (lawType == 4) {
        that.setData({//把选中值放入判断值
          title: '国务院部门规章'
        });

      }
      if (lawType == 5) {
        that.setData({//把选中值放入判断值
          title: '地方性法规'
        });

      }
      if (lawType == 6) {
        that.setData({//把选中值放入判断值
          title: '地方政府规章'
        });
      }

      //获取数据
      wx.request({
        url: getApp().globalData.url + 'law/listAllByType',//上线的话必须是https，没有appId的本地请求貌似不受影响  
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          page: page,
          size: 30,
          type: options.type,
          apiKey: 'wx_CityService',
          apiSign: getApp().getSign(),
          apiTimestamp: getApp().getyyyyMMddhh()
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          if (data.data.code == 200) {
            that.setData({//把选中值放入判断值
              fl: data.data.data
            });
            page = page + 1;
            if (data.data.data.length < 30) {
              hasmore = false;
            }
          } else {
            wx.showToast({
              title: data.data.msg,
              icon: 'none'
            });
          }
        },
        fail: function () {
          wx.showToast({
            title: '请检查网络连接',
            icon: 'none'
          });
        }
      })

    } else {//搜索的结果
      findKey = options.findKey;
      wx.request({
        url: getApp().globalData.url + 'law/findByKey',//上线的话必须是https，没有appId的本地请求貌似不受影响  
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          page: page,
          size: 30,
          findkey: options.findKey,
          apiKey: 'wx_CityService',
          apiSign: getApp().getSign(),
          apiTimestamp: getApp().getyyyyMMddhh()
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          if (data.data.code == 200) {
            that.setData({//把选中值放入判断值
              fl: data.data.data,
              show_input: false,
              title: data.data.msg
            });
            if (data.data.data.length < 30) {
              hasmore = false;
            }
            page = page + 1;
          } else {
            wx.showToast({
              title: data.data.msg,
              icon: 'none'
            });
          }
        },
        fail: function () {
          wx.showToast({
            title: '请检查网络连接',
            icon: 'none'
          });
        }
      })

    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.info(show_type);
    var that = this;
    if (show_type > 0) {//>0获取子类   =0搜索的结果
      if (hasmore) {

        //获取数据
        wx.request({
          url: getApp().globalData.url + 'law/listAllByType',//上线的话必须是https，没有appId的本地请求貌似不受影响  
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            page: page,
            size: 30,
            type: show_type,
            apiKey: 'wx_CityService',
            apiSign: getApp().getSign(),
            apiTimestamp: getApp().getyyyyMMddhh()
          },
          method: 'post',
          dataType: 'json',
          success: function (data) {
            //取出原来的法律集合
            
            if (data.data.code == 200) {
              var list = that.data.fl;
              for (var i = 0; i < data.data.data.length; i++) {
                list.push(data.data.data[i]);
              }
              page = page + 1;
              if (data.data.data.length < 30) {
                hasmore = false;
              }

            } else {
              wx.showToast({
                title: data.data.msg,
                icon: 'none'
              });
            }
            that.setData({
              fl: list
            });
          },
          fail: function () {
            wx.showToast({
              title: '请检查网络连接',
              icon: 'none'
            });
          }
        })
      } else {
        wx.showToast({
          title: "已经没有更多数据",
          icon: 'none'
        });
      }

    } else {//搜索的结果
      if (hasmore) {

        wx.request({
          url: getApp().globalData.url + 'law/findByKey',//上线的话必须是https，没有appId的本地请求貌似不受影响  
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            page: page,
            size: 30,
            findkey: findKey,
            apiKey: 'wx_CityService',
            apiSign: getApp().getSign(),
            apiTimestamp: getApp().getyyyyMMddhh()
          },
          method: 'post',
          dataType: 'json',
          success: function (data) {
            var list = that.data.fl;
            if (data.data.code == 200) {
              for (var i = 0; i < data.data.data.length; i++) {
                list.push(data.data.data[i]);
              }
              page = page + 1;

              if (data.data.data.length < 30) {
                hasmore = false;
              }
            } else {
              wx.showToast({
                title: data.data.msg,
                icon: 'none'
              });
            }
            that.setData({
              fl: list
            });
          },
          fail: function () {
            wx.showToast({
              title: '请检查网络连接',
              icon: 'none'
            });
          }
        })

      } else {
        wx.showToast({
          title: "已经没有更多数据",
          icon: 'none'
        });
      }
    }

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})