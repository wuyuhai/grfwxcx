// pages/hudon/tousu.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    shi_list: [],
    shi_index: 0, //市索引
    qu_list: [], //{"PARENTID":"520000","AREAID":"520100","AREANAME":"贵阳市","LAYER":"2"}
    qu_index: 0, //区索引
    bm_list: [ //部门办事列表     
    ],
    bm_index: 0 //部门索引
    ,
    item_list: [ //事项列表     
    ],
    item_index: 0 //事项索引
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getDept()
  },
  pickerSHI: function (e) { //选择市后修改数据
    getApp().pickerSHI(e);
    this.getDept()

  },
  pickerQU: function (e) { //选择区后修改数据

    getApp().pickerQU(e);

    this.getDept()
  },
  pickerDept: function (e) { //选择部门
    this.setData({
      bm_index: e.detail.value
    })
    this.getItem()
  },
  pickerItem: function (e) {
    this.setData({
      item_index: e.detail.value
    })
    this.getDate()

  },
  getDept: function () {
    var that = this;
    //获取部门
    wx.request({
      url: getApp().globalData.url + 'region/getDepts',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        page: 1,
        size: 1000,
        regionId: wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID
      },
      method: 'post',
      dataType: 'json',
      success: function (data1) {
        if (data1.data.code == 200) {
          that.setData({
            shi_list: wx.getStorageSync("shi_list"),
            shi_index: wx.getStorageSync("shi_index"),
            qu_list: wx.getStorageSync("qu_list"),
            qu_index: wx.getStorageSync("qu_index"),
            bm_list: data1.data.data

          });
        }
      }
    })

  },

  getItem() {
    var that = this;
    //获取部门事项
    wx.request({
      url: getApp().globalData.url + 'dept/getItems',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        page: 1,
        size: 1000,
        deptId: that.data.bm_list[that.data.bm_index].DEPTID
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        if (data.data.code == 200) {
          that.setData({
            item_list: data.data.data
          });
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})