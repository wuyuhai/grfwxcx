// pages/index/shixiang_lb.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    hotid:'',
    hotname:'',
    qiquxuanze:"",

    items:[],
    clickbol:true,
  },

  onLoad: function(options) {
    console.log(options)
    if (options.hotid){
      this.setData({
        hotid: options.hotid,
        hotname: options.name,
      })
    }
    var qulist = wx.getStorageSync('qu_list');
    var quindex = wx.getStorageSync('qu_index');
    var qiquxuanze = {
      city: qulist[quindex].AREANAME,
      id: qulist[quindex].AREAID,
    }
    this.setData({
      qiquxuanze: qiquxuanze,
    })
    this.getitems();
    wx.setNavigationBarTitle({
      title: this.data.hotname
    })
  },

  godiqu: function () {
    wx.navigateTo({
      url: '../selectcity/city',
    })
  },

  //获取具体的办理事项
  getitems: function () {
    wx.showLoading({
      title: '加载中',
    })
    console.log(this.data.qiquxuanze)
    var that = this;
    var data={
      regionId: this.data.qiquxuanze.id,
      sId: this.data.hotid,
    }
    console.log(data)
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        'param': JSON.stringify(data), 'url': 'http://202.98.195.208:82/unified_management/xcxHotItemDetail/findByRegionIdAndSid'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if (data.data.ok == true) {
          that.setData({
            items: data.data.obj
          })
          wx.hideLoading();
        }
      }
    })
  },

  goshixiangbanli(e){
    console.log(e)
    var that = this;
    if (this.data.clickbol == true){
      this.data.clickbol = false;
      var data = {
        //52000020160922162734014958
        //520102520102111588
        itemId: e.currentTarget.dataset.id
      }
      wx.request({
        url: getApp().globalData.url + '/services/getItemDetail',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: data,
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data)
          if (data.data.code == 200) {
            var items = data.data.data;
            var bol = items.SFYDSB == 1 ? true : false
            wx.navigateTo({
              url: 'shixiang_xq?itemId=' + items.ID + '&canDo=' + bol + '&deptname=' + items.DEPTNAME + '&sxzxname=' + items.SXZXNAME + '&isShouc==false&shouc_id=0',
              // 'shixiang_xq?itemId={{item.id}}&canDo={{item.sfwssb==1}}&deptname={{item.spsljgmc}}&sxzxname={{item.sxzxname}}&isShouc==false&shouc_id=0'
            })
          }
        }
      }) 
      var timer=setTimeout(function(){
        clearTimeout(timer)
        that.data.clickbol = true;
      },1000)
    }
      
  },

  onShow: function (){
    this.getitems();
  },
})