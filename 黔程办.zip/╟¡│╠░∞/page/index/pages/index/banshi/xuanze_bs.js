Page({

  /**
   * 页面的初始数据 
   */
  data: {
    url: 'https://m.gzegn.gov.cn/terminal_management/workGuide',
    type: "",
    shi_list: [],
    shi_index: 0,
    qu_list: [], //{"PARENTID":"520000","AREAID":"520100","AREANAME":"贵阳市","LAYER":"2"}
    qu_index: 0,
    toView: "个人", //个人 组织 部门 经营 默认个人
    gr_zz_fl_qb: "事件分类",
    fl_tj: "主题", //分类条件
    // show_shen: true, //显示省级部门  
    chose_btn: ["省级部门", "地区切换"],
    chose_btn_index: 0,
    //分类条件 个人办事时  主题（主题分类001001） 事件（事件分类 001002） 特定（特定对象 001003）
    //分类条件 组织办事时  主题（主题分类002001） 事件（事件分类 002002） 特定（特定对象 002003）
    fl_code: "001001",
    btn_list: [], //个人  组织共用一个集合
    bm_btn_list: [ //部门办事列表     
    ],
    pageNum:1,
    baizero:false,
    qkind:1,
    puls:true
  },
  getData() {
    this.setData({
      shi_list: wx.getStorageSync("shi_list"),
      shi_index: wx.getStorageSync("shi_index"),
      qu_list: wx.getStorageSync("qu_list"),
      qu_index: wx.getStorageSync("qu_index"), 
      pageNum: 1
    });
  },
  // 获取分类列表
  bans_get_list(){
    var that = this;
    wx.showLoading({
      title: '加载中',
    });
    // wx.request({
    //   url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
    //   header: {
    //     'Content-Type': getApp().globalData.contentType
    //   },
    //   data: {
    //     'param': JSON.stringify({
    //       data: {
    //         'parentTitleId': that.data.fl_code
    //       }
    //     }),
    //     'headers': JSON.stringify({
    //       'Content-Type': 'application/json'
    //     }),
    //     'url': 'http://103.3.152.111:84/terminal_management/workGuide/findTitleInfo'
    //   },//实际调用接口
    wx.request({
      url:that.data.url+'/findTitleInfo',
      // url:'http://103.3.152.111:84/terminal_management/workGuide/findTitleInfo',
      header: {
        'Content-Type': 'application/json'
      },
      data: JSON.stringify({
        'parentTitleId': that.data.fl_code
      }),
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        wx.hideLoading();
        if (data.data.code == 200) {
          that.setData({ //把选中值放入判断值
            btn_list: data.data.data,
          });
          // wx.setStorageSync('btn_list', data.data.data)
        } else {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }
      },
      fail: function (res) {
        wx.hideLoading();
        console.log(res);
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    that.getData();
    that.bans_get_list();
    that.setData({ 
      type: options.type
    });
    //从全局变量里面获取地区
    //获取个人和组织办事
    // that.getDept();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  getDept: function(a) { //获取部门
    //console.log(a)
    var that = this;
    if (that.data.qu_list.length == 0) {
      return;
    }
    //   省级部门的先屏蔽了，，，暂时没有接口
    wx.showLoading({
      title: '加载中',
    })
    var addr_id = that.data.qu_list[that.data.qu_index].AREAID
    //获取部门
    var baizero=Number(addr_id)%100 == 0?true:false;
    console.log(baizero)
    console.log(addr_id)
    wx.request({
      // url: getApp().globalData.url + 'region/getDepts',
      url: that.data.url +'/findDeptList',
      header: {
        'Content-Type': 'application/json'
      },
      data: JSON.stringify({
        "areaId": addr_id,
        "pageNum": 1,
        "pageSize":10000
      }),
      method: 'post',
      dataType: 'json',
      success: function(data) {
        console.log(data)
        wx.hideLoading();
        if (data.data.code == 200) {
          var dept_l = data.data.data;
          var dept_array = [];
          if(a==1){
            // 1是县市区级别的
            for(var i=0;i<dept_l.length;i++){
              if (dept_l[i].isenforeorg!='1'){
                dept_array.push(dept_l[i]);
              }
            }
            that.setData({
              bm_btn_list: dept_array
            })
          }else if(a==2){
            // 2是乡镇级别
            for (var i = 0; i < dept_l.length; i++) {
              if (dept_l[i].isenforeorg=='1') {
                dept_array.push(dept_l[i]);
              }
            }
            that.setData({
              bm_btn_list: dept_array
            })
          }else{
            that.setData({
              bm_btn_list: dept_l
            })
          }
          that.setData({
            baizero: baizero
          })
        } else {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }

      }
    })
  },

  pickerSHI: function(e) { //选择市后修改数据
    getApp().pickerSHI(e);
    this.setData({
      qkind: 1,
      puls:true
    })
    //从全局变量里面获取地区
    this.getData();
    this.getDept(1);
  },
  pickerQU: function(e) { //选择区后修改数据
    var that = this;
    getApp().pickerQU(e);
    //从全局变量里面获取地区
    this.setData({
      qkind: 1,
      puls: true
    })
    this.getData();
    this.getDept(1);
  },
  pickerBtn: function(e) { //选择地区切换和省级
    var that = this;
    console.info(e)
    if (e.detail.value == 0) { //省级
      that.setData({
        show_shen: true,
        chose_btn_index: 0,
        bm_btn_list:[]
      })

    } else {
      that.setData({
        show_shen: false,
        chose_btn_index: 1,
        bm_btn_list: []
      })
    }
    this.getDept();
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.getData();
    this.getDept(1);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  // onReachBottom: function() {
  //   //console.log('加载更多');
  //   if (this.data.toView != "部门") return;
  //   var that = this;
  //   var pageNum = this.data.pageNum + 1;
  //   var addr_id = that.data.show_shen ?'520000':that.data.qu_list[that.data.qu_index].AREAID;
  //   console.log(pageNum)
  //   if(that.data.puls){
  //     wx.showLoading({
  //       title: '加载中',
  //     })
  //   wx.request({
  //     url: 'http://103.3.152.111:84/terminal_management/workGuide/findDeptList',
  //     header: {
  //       'Content-Type': 'application/json'
  //     },
  //     data: JSON.stringify({
  //       "areaId": addr_id,
  //       "pageNum": pageNum,
  //       "pageSize": 40
  //     }),
  //     method: 'post',
  //     dataType: 'json',
  //     success: function (data) {
  //       console.log(data)
  //       if (data.data.code == 200) {
  //         // 111
  //         var dept_l = data.data.data;
  //         var bm_btn_list = that.data.bm_btn_list;
  //         if (that.data.qkind == 1) {
  //           for (var i = 0; i < dept_l.length; i++) {
  //             if (dept_l[i].isenforeorg != '1') {
  //               bm_btn_list.push(dept_l[i]);
  //             }
  //           }
  //           that.setData({
  //             bm_btn_list: bm_btn_list
  //           })
  //         } else if (that.data.qkind == 2) {
  //           for (var i = 0; i < dept_l.length; i++) {
  //             if (dept_l[i].isenforeorg == '1') {
  //               bm_btn_list.push(dept_l[i]);
  //             }
  //           }
  //           that.setData({
  //             bm_btn_list: bm_btn_list
  //           })
  //         }
  //         if (data.data.data.length == 40){
  //           that.setData({
  //             pageNum: pageNum,
  //             puls:true
  //           })
  //         }else{
  //           pageNum = pageNum - 1;
  //           console.log(pageNum)
  //           that.setData({
  //             pageNum: pageNum,
  //             puls: false
  //           })
  //           wx.showToast({
  //             title: '没有更多数据了！',
  //             icon: 'none'
  //           });
  //         }  
  //         wx.hideLoading();    
  //       } else {
  //         wx.hideLoading();
  //         wx.showToast({
  //           title: data.data.msg,
  //           icon: 'none'
  //         });
  //       }
  //     }
  //   })
  //   }
  // },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },

  changeView: function(e) { // 个人 组织 部门 切换视图
  var that = this;
    if (this.data.toView != e.currentTarget.id) {
      if (e.currentTarget.id == "个人") {
        this.setData({
          toView: e.currentTarget.id,
          fl_code: "001001",
          fl_tj: "主题",
          gr_zz_fl_qb: "事件分类"
        })
        that.bans_get_list();
      } else if (e.currentTarget.id == "组织") {
        this.setData({
          toView: e.currentTarget.id,
          fl_code: "002001",
          fl_tj: "主题",
          gr_zz_fl_qb: "经营活动"
        })
        that.bans_get_list();
      } else {
        this.setData({
          toView: e.currentTarget.id
        })
      }
    }
  },
  changeFL: function(e) { // 主题分类 事件分类 特定对象分类 切换视图
    // fl_tj: "主题",
    //分类条件 个人办事  主题（主题分类001001） 事件（事件分类 001002） 特定（特定对象 001003）
    //   fl_code:"001001",
    //个人时
    var that = this;
    if (this.data.toView == "个人") {
      if (this.fl_tj != e.currentTarget.id) {
        if (e.currentTarget.id == "主题") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "001001"
          })
        } else if (e.currentTarget.id == "事件") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "001002"
          })
        } else if (e.currentTarget.id == "特定") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "001003"
          })
        }
        that.bans_get_list();
      }
    } else if (this.data.toView == "组织") { //分类条件 组织办事时  主题（主题分类002001） 事件（事件分类 002002） 特定（特定对象 002003）
      if (this.fl_tj != e.currentTarget.id) {
        if (e.currentTarget.id == "主题") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "002001"
          })
        } else if (e.currentTarget.id == "事件") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "002002"
          })
        } else if (e.currentTarget.id == "特定") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "002003"
          })
        }
        that.bans_get_list();
      }
    }
  },
  /**
    * 用户点击右上角分享
    */
  onShareAppMessage: function () {

  },
  changexiangqu:function(e){
    this.setData({
      qkind:e.currentTarget.dataset.qkind
    })
    this.getDept(e.currentTarget.dataset.qkind);
  },

  newlower:function(){
    //console.log('加载更多');
    if (this.data.toView != "部门") return
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    var pageNum = this.data.pageNum + 1;
    var addr_id = that.data.show_shen ? '520000' : that.data.qu_list[that.data.qu_index].AREAID;
    console.log(pageNum)
    wx.request({
      url: getApp().globalData.url + 'region/getDepts',
      // url: 'http://192.168.0.107:8080/region/getDepts',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        pageNum: pageNum,
        pageSize: 40,
        regionId: addr_id,
        deptType: this.data.qkind,
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if (data.data.code == 200) {
          if (data.data.data.length > 0) {
            var bm_btn_list = that.data.bm_btn_list;
            for (var i = 0; i < data.data.data.length; i++) {
              bm_btn_list.push(data.data.data[i]);
            }
            that.setData({
              bm_btn_list: bm_btn_list,
              pageNum: pageNum
            })
          } else {
            pageNum = pageNum - 1;
            console.log(pageNum)
            that.setData({
              pageNum: pageNum
            })
          }
          wx.hideLoading();
        } else {
          wx.hideLoading();
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }
      }
    })
  }
})