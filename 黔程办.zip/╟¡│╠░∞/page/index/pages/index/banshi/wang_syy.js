// pages/index/wang_syy.js
var zhenze = require('../../../../../utils/zhenze.js').check;  
Page({ 

  /**
   * 页面的初始数据
   */
  data: {
    shi_list: [],
    shi_index: 0, //市索引
    qu_list: [], //{"PARENTID":"520000","AREAID":"520100","AREANAME":"贵阳市","LAYER":"2"}
    qu_index: 0, //区索引
    bm_list: [ //部门办事列表      
    ],
    bm_index: 0 //部门索引
      ,
    item_list: [ //事项列表     
    ],
    item_index: 0 //事项索引
      ,
    date_list: [ //事项预约日期列表     
    ],
    date_index: 0 //事项预约日期索引
      ,
    time_list: [ //事项预约时间列表     
    ],
    time_index: 0, //事项预约时间索引

    name:"",
    idcard:"",
    telphone:"",

    qiquxuanze: {
      city: "请选择要预约的城市",
      id: 0
    },

    bm_name: {
      name: "请选择要预约的部门"
    },
    sx_name: {
      name: "请选择要预约的事项"
    },

    viewkin1: 1,
    viewkin2: 1,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  getDept: function () { //获取部门
    var that = this;
    if (that.data.qiquxuanze.id == 0) {
      console.log(11)
      wx.showToast({
        title: '请先选择要预约的城市',
        icon: 'none',
      })
      return
    }

    wx.request({
      url: getApp().globalData.url + 'region/getDepts',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        pageNum: 1,
        pageSize: 10000,
        regionId: that.data.qiquxuanze.id
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        if (data.data.code == 200) {
          console.log(data)
          var timer = setTimeout(function () {
            clearTimeout(timer)
            that.setData({
              bm_list: data.data.data,
              bmshow: true,
              shix_list: [],
              sxshow: false,
              sx_name: {
                name: "请选择要办理的事项"
              },
            })
          }, 200)
        } else {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }
      }
    })
  },

  getshix_list: function () {
    var that = this;
    if (that.data.bm_name.name == "请选择要预约的部门") {
      wx.showToast({
        title: '请先选择要预约的部门',
        icon: 'none',
      })
      return
    }
    wx.request({
      url: getApp().globalData.url + 'dept/getItems',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        page: 1,
        size: 1000,
        deptId: that.data.bm_name.deptid,
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if (data.data.code == 200) {
          that.setData({
            shix_list: data.data.data,
            sxshow: true,
          })
        } else {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }
      }
    })
  },


  getDate() {
    var that = this;
    //获取部门事项
    if(this.data.sx_name.anem == "请选择要预约的事项"){
      wx.showToast({
        title: '请选择要预约的事项',
        icon:'icon'
      })
      return
    }
    console.log(this.data.bm_name,this.data.sx_name)
    wx.request({
      url: getApp().globalData.url + 'appointment/getFreeDate',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        token: wx.getStorageSync('token'),
        itemId: that.data.sx_name.id,
        deptId: that.data.sx_name.deptid,
      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        console.log(data)
        if (data.data.code == 200) {
          var time = [];
          for (var i in data.data.data.Items){
            if(i>1){
              time.push(data.data.data.Items[i])
            }
          }
          var timer = setTimeout(function () {
            clearTimeout(timer)
            that.setData({
              date_list: time
            });
            that.getTime()
          }, 200)       
        }else{
          if (data.data.msg == "登录已超时，请重新登录") {
            wx.showToast({
              title: '登录超时，请重新登录',
              icon: 'none'
            });
            wx.removeStorageSync('token');
            wx.navigateTo({
              url: '../login/selcet_login_type',
            })
            return
          } else {
            wx.showToast({
              title: '政务系统繁忙',
              icon: 'none'
            });
          }
        }
      }
    })
  },

  getTime() {
    var that = this;
    //获取部门事项
    wx.request({
      url: getApp().globalData.url + 'appointment/getFreeTime',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        token: wx.getStorageSync('token'),
        itemId: that.data.sx_name.id,
        deptId: that.data.sx_name.deptid,
        appointmentDate: that.data.date_list[that.data.date_index].RESERVEDATE
      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        console.log(data)
        if (data.data.code == 200) {
          that.setData({
            time_list: data.data.data.Items
          });
        }else{
          if (data.data.msg == "登录已超时，请重新登录") {
            wx.showToast({
              title: '登录超时，请重新登录',
              icon: 'none'
            });
            wx.removeStorageSync('token');
            wx.navigateTo({
              url: '../login/selcet_login_type',
            })
            return
          } else {
            wx.showToast({
              title: '政务系统繁忙',
              icon: 'none'
            });
          }
        }
      }
    })
  },
  onLoad: function(options) {
    if (wx.getStorageSync('user_name') != "" && wx.getStorageSync("token")!=""){
      this.setData({
        name: wx.getStorageSync("user_name") ? wx.getStorageSync("user_name") : wx.getStorageSync("login_name"),
        idcard: wx.getStorageSync('idCardNumber'),
        telphone: wx.getStorageSync('phone'),    
        // emails: wx.getStorageSync('user_mobile') ? wx.getStorageSync('user_mobile'):"",
      })
    }else{
      wx.showModal({
        title: '提示',
        content: '当前用户未登录，返回首页',
        success: function (res) {
          if (res.confirm) {
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          } else if (res.cancel) {
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          }
        },
      })
    }
  },
  pickerSHI: function(e) { //选择市后修改数据
    getApp().pickerSHI(e);
    this.setData({
      item_list: [],
    })
  },
  pickerQU: function(e) { //选择区后修改数据
    getApp().pickerQU(e);
    this.setData({
      item_list: [],
    })
  },
  pickerDept: function(e) { //选择部门
    this.setData({
      bm_index: e.detail.value
    })
    this.getItem()
  },
  pickerItem: function(e) {
    this.setData({
      item_index: e.detail.value
    })
    this.getDate()
  },
  pickerDate: function(e) {
    this.setData({
      date_index: e.detail.value
    })
    this.getTime()
  },

  pickerTime: function(e) {
    this.setData({
      time_index: e.detail.value
    })
  },

  formSubmit: function(e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    if (!zhenze.isNameAvailable(e.detail.value.name)) {
      wx.showToast({
        title: '姓名必须为中文简体，且不少于2个字',
        icon: 'none'
      })
      return
    }
    if (!zhenze.isShenfenAvailable(e.detail.value.idcard)) {
      wx.showToast({
        title: '身份证输入有误，请仔细填写',
        icon: 'none'
      })
      return
    }
    if (e.detail.value.email != "" && !zhenze.fChkMail(e.detail.value.email)) {
      wx.showToast({
        title: '请填写正确的邮箱没有可以不填',
        icon: 'none'
      })
      return
    }
    if (!zhenze.isTelAvailable(e.detail.value.tel)) {
      wx.showToast({
        title: '请输入正确的手机号码',
        icon: 'none'
      })
      return
    }
    if (this.data.qiquxuanze.city =="请选择要预约的城市") {
      wx.showToast({
        title: '请选择要预约的城市',
        icon: 'none'
      })
      return
    }
    if (this.data.bm_name.name == "请选择要预约的部门") {
      wx.showToast({
        title: '请选择要预约的部门',
        icon: 'none'
      })
      return
    }
    if (this.data.bm_name.name == "请选择要预约的事项") {
      wx.showToast({
        title: '请选择要预约的事项',
        icon: 'none'
      })
      return
    }
      var token = wx.getStorageSync('token');
      var data = {
        token: token,
        itemId: this.data.bm_name.id,
        appointmentDate: e.detail.value.date,
        appointmentTime: e.detail.value.time,
        deptId: this.data.bm_name.deptid,
        applicantId: wx.getStorageSync('user_id'),
      };
    wx.request({
      url: getApp().globalData.url + '/appointment/infoSubmit',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: data,
      method: 'post',
      dataType: 'json',
      success: function(data) {
        console.log(data)
        if(data.data.code == 200){
          //console.log("预约成功");
          wx.showToast({
            title: '预约成功2s后返回首页',
            icon:'none'
          })
          var timer = setTimeout(function(){
            clearTimeout(timer)
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          },2000)
        }else{
          wx.showToast({
            title: '预约失败，政务系统繁忙',
            icon: 'none'
          })
        }
      }
    })
  },

  godiqu: function () {
    wx.navigateTo({
      url: '../selectcity/city',
    })
  },

  //选择部门
  selectbm: function (e) {
    console.log(e)
    var bm_name = {
      cityid: e.currentTarget.dataset.cityid,
      deptid: e.currentTarget.dataset.deptid,
      num: e.currentTarget.dataset.num,
      shortname: e.currentTarget.dataset.shortname,
      name: e.currentTarget.dataset.name,
    }
    this.setData({
      bm_name: bm_name,
      bmshow: false,
    })
  },

  selectsx: function (e) {
    console.log(e)
    var sx_name = {
      name: e.currentTarget.dataset.name,
      deptid: e.currentTarget.dataset.deptid,
      id: e.currentTarget.dataset.id,
      largeitemid: e.currentTarget.dataset.largeitemid,
      smallitemid: e.currentTarget.dataset.smallitemid,
      xzxk: e.currentTarget.dataset.xzxk,
    }
    this.setData({
      sx_name: sx_name,
      sxshow: false,
    })
    this.getDate()
  },

  showhide: function () {
    this.setData({
      sxshow: false,
      bmshow: false,
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})