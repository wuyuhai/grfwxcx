var check = require('../../../../../utils/zhenze.js');  

Page({

  /**
   * 页面的初始数据
   */
  data: {
    toView: "基本信息",
    item_info: {},
    canDo: false, //是否支持网上申请
    deptName: '',
    sxzxname: '',
    itemId: '',
    isShouc: false, //判断是否收藏
    wxId: '123456',
    shouc_id: '1',

    downimg: "",

    showmode: {
      show: false,
      phone: '',
    },

  },

  /**
   * 生命周期函数--监听页面加载
   */
  shouc: function(e) { //收藏
    var that = this;
    wx.request({
      url: getApp().globalData.url + 'userFavorItem/add',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        wx_id: wx.getStorageSync('wxId'),
        item_id: that.data.itemId,
        SFYDSB: that.data.canDo,
        item_name: that.data.sxzxname, //事项名 
        dept_name: that.data.deptName //部门名
      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        console.log(data)
        if (data.data.code == 200) {
          wx.showToast({
            title: '收藏成功！',
            icon: 'none'
          });
          that.setData({
            isShouc: true,
            shouc_id: data.data.data,
          })
        } else {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }
      }
    }) //ajax end
  },
  close_shouc: function(e) {
    var that = this;
    console.log(that.data.shouc_id)
    wx.request({
      url: getApp().globalData.url + 'userFavorItem/del',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        delList: that.data.shouc_id,
      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        if (data.data.code == 200) {
          wx.showToast({
            title: '取消收藏成功！',
            icon: 'none'
          });
          that.setData({
            isShouc: false,
            shouc_id:'',
          })
        } else {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }
      }
    }) //ajax end
  },
  onLoad: function(options) {
    console.log(options);
    wx.showLoading({
      title: '加载中',
    });
    var that = this;
    // 获取事项信息
    //  wx.request({
    //   url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
    //   header: {
    //     'Content-Type': getApp().globalData.contentType
    //   },
    //   data: {
    //     'param': JSON.stringify({
    //       // data: {
    //         "itemId": options.itemId
    //       // }
    //     }),
    //     'header': JSON.stringify({
    //       'Content-Type': 'application/json'
    //     }),
    //     'url': 'http://103.3.152.111:84/terminal_management/workGuide/findItemInfo'
    //   },//实际调用接口
    // 
    wx.request({
      url: 'https://m.gzegn.gov.cn/terminal_management/workGuide/findItemInfo',
      header: {
        'Content-Type': 'application/json'
      },
      timeout: 5000,
      data: JSON.stringify({
        "itemId": options.itemId
      }),
      method: 'post',
      dataType: 'json',
      success: function(data) {
        wx.hideLoading();
        console.log(data)
        if (data.data.code == 200) {
          if (data.data.data.length>0){
            that.setData({ //把选中值放入判断值
              canDo: options.canDo,
              deptName: options.deptname,
              itemId: options.itemId,
              sxzxname: options.sxzxname,
              shouc_id: options.shouc_id,
              item_info: data.data.data[0],
              isShouc: options.isShouc,
            });
            wx.setNavigationBarTitle({ //设置标题
              title: data.data.data[0].sxzxname,
            })
          }else{
            wx.showToast({
              title: '没有找到该事项的详细信息！',
              icon: 'none'
            });
            setTimeout(function () {
              wx.navigateBack({ changed: true });
            }, 2000);
          }
        }
        // 获取收藏列表
        wx.request({
          url: getApp().globalData.url + 'userFavorItem/getList',
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            wxId: getApp().globalData.wxId,
          },
          method: 'post',
          dataType: 'json',
          success: function(data) {
            // console.log(data);
            if (data.data.code == 200) {
              var shouc_arr = data.data.data;
              for (var i = 0; i < shouc_arr.length; i++) { //判断现在的事项是否在用户的收藏列表里面
                if (shouc_arr[i].item_id == that.data.itemId) {
                  that.setData({
                    isShouc: true,
                    shouc_id: shouc_arr[i].id,
                  })
                }
              }
            } else {
              wx.showToast({
                title: data.data.msg,
                icon: 'none'
              });
            }
          }
        }) //ajax end
      },
      fail:function(e){
        wx.hideLoading();
        console.log(e); 
        wx.showToast({
          title: '网络请求异常！',
          icon: 'none'
        });
      }
    }) //获取数据end
  },
  changeView: function(e) { // 基本信息 申报材料 申请条件 切换视图
    if (this.data.toView != e.currentTarget.id) {
      this.setData({
        toView: e.currentTarget.id
      })
    }
  },

  zixun: function() { //点击咨询按钮后
    var zixuitme = {
      SXID: this.data.item_info.id,
      deptid: this.data.item_info.department,
      sxname: this.data.item_info.sxzxname,
    }
    getApp().globalData.zixuitme = JSON.stringify(zixuitme)
    wx.switchTab({
      url: '/page/tabBar/hudon/index',
    })
  },

  shenbao: function() { //点击申报按钮后
    wx.navigateTo({
      url: 'shixiang_sb?itemId=' + this.data.item_info.id +
        '&canDo=true',
    })
  },

  download: function(e) {
    var that = this;
    console.log(e)
    var data = {
      "fileName": e.currentTarget.dataset.name,
      "fileNo": e.currentTarget.id
    }
    console.log(data)
    wx.request({
      url: getApp().globalData.url + 'file/download',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      method: "POST",
      data: data,
      dataType: 'json',
      success: function(data) {
        console.log(data);
        if (data.data.code == 200) {
          if (e.currentTarget.dataset.name) {
            var url = getApp().globalData.url + "resources/" + e.currentTarget.dataset.name;
            url = encodeURI(url);
            const downloadTask = wx.downloadFile({
              url: url,
              success: function(res) {
                console.info(res)
                if (res.statusCode == 200 && res.tempFilePath) {
                  if (check.check.isImage(res.tempFilePath)) {
                    //console.log("这是张图片");
                    that.setData({
                      downimg: res.tempFilePath,
                      imgshow: true,
                    })
                  } else {
                    var filePath = res.tempFilePath;
                    wx.saveFile({
                      tempFilePath: filePath,
                      success: function(res1) {
                        console.info(res1)
                        var filep = res1.savedFilePath;
                        wx.openDocument({
                          filePath: filep,
                          success: function(res2) {
                            //console.info(res2)
                            //console.log('打开文档成功')
                          },
                          fail: function(res) {
                            //console.log(res)
                            wx.showToast({
                              title: '该文件暂不提供下载！',
                              icon: 'none'
                            });
                          }
                        })
                      }
                    })
                  }
                }
              }
            })
            downloadTask.onProgressUpdate((res) => {
              wx.showLoading({
                title: '下载进度 ' + res.progress + "%",
              })
              if (res.progress == 100){
                wx.hideLoading();
              }
            })
          } else {
            wx.showToast({
              title: '该文件暂不提供下载！',
              icon: 'none'
            });
          }
        } else {
          wx.showToast({
            title: '该文件暂不提供下载！',
            icon: 'none'
          });
        }
      }
    })
  },

  closeimgshow: function() {
    this.setData({
      imgshow: false,
    })
  },

  //点击下载图片进行预览
  previewImage: function(e) {
    console.log(e)
    var imgalist = [];
    imgalist.push(e.currentTarget.dataset.src)
    wx.previewImage({
      current: imgalist, // 当前显示图片的http链接 
      urls: imgalist // 需要预览的图片http链接列表 
    })
  },
  
  //页面跳转
  navigatetos: function (e) {
    var that = this;
    if (wx.getStorageSync("token") == "") {
      this.setData({
        showmode: {
          show: true,
          phone: wx.getStorageSync("phone")
        }
      })
    } else {
      if (e.currentTarget.dataset.kind == 'zx'){
        this.zixun();
      }
      if (e.currentTarget.dataset.kind == 'sb'){
        this.shenbao()
      }      
      if (e.currentTarget.dataset.kind == 'sc') {
        this.shouc()
      } 
      if (e.currentTarget.dataset.kind == 'deletsc') {
        this.close_shouc()
      } 
    }
  },

  //没有登录时点击去登录
  to_login: function () {
    wx.navigateTo({
      url: '/page/home/pages/home/login/login_select',
    })
    this.setData({
      showmode: {
        show: false
      }
    })
  },

  cencel_login: function () {
    this.setData({
      showmode: {
        show: false
      }
    })
  },

  //获取用户手机号码
  getPhoneNumber: function (e) { //点击获取手机号码按钮
    var that = this;
    wx.login({
      success: data => {
        console.log(e.detail.iv)
        console.log(e.detail.encryptedData)
        var ency = e.detail.encryptedData;
        var iv = e.detail.iv;
        if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
          // 用户取消了获取手机号
        } else { //同意授权
          wx.request({
            method: "POST",
            // url: 'https://face.fotoit.cn:84/UrbanService/user/decodeUserInfo',  //这个解密地址能用
            url: getApp().globalData.url + 'user/decodeUserInfo',
            data: {
              code: data.code,
              encryptedData: e.detail.encryptedData,
              iv: iv,
            },
            header: {
              'content-type': getApp().globalData.contentType,
            },
            success: (res) => {
              console.log(res);
              if (res.data.code == 200) { //code好像只有线上的可以，发布之后如果获取手机号成功会返回200，，跳转选择登陆
                if (res.data.data.phoneNumber) {
                  var phone = res.data.data.phoneNumber.toString();
                  getApp().savewxinfo(res.data.data.phoneNumber); //把用户信息传到后台保存
                  wx.setStorageSync("phone", phone);
                  that.setData({
                    showmode: {
                      show: false,
                      phone: phone,
                    }
                  })
                  wx.navigateTo({
                    url: '/page/home/pages/home/login/login_select',
                  })
                  // wx.showToast({
                  //   title: "解密成功" + phone,
                  //   icon: 'none'
                  // });
                } else {
                  wx.showToast({
                    title: "解密失败",
                    icon: 'none'
                  });
                  that.setData({
                    showmode: {
                      show: false,
                      phone: '',
                    }
                  })
                }
              }
            },
            fail: function (res) {
              console.log("解密失败~~~~~~~~~~~~~");
              console.log(res);
              wx.showToast({
                title: '获取用户手机失败，请再试一次',
                icon: 'none'
              });
            }
          });
        } 
      }
    })
  },
  /**
    * 用户点击右上角分享
    */
  onShareAppMessage: function () {

  }
})