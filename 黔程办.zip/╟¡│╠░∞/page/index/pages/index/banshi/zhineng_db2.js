Page({

  /**
   * 页面的初始数据 
   */
  data: {
    type: "bszn",
    shi_list: [],
    shi_index: 0, 
    qu_list: [], //{"PARENTID":"520000","AREAID":"520100","AREANAME":"贵阳市","LAYER":"2"}
    bm_list: [],
    qu_index: 0,
    bm_name: {
      name: "请选择要办理的部门"
    },
    sx_name: {
      name: "请选择要办理的事项"
    },

    show_shen: true, //显示省级部门  
    chose_btn: ["省级部门", "地区切换"],
    chose_btn_index: 0,
    //分类条件 个人办事时  主题（主题分类001001） 事件（事件分类 001002） 特定（特定对象 001003）
    //分类条件 组织办事时  主题（主题分类002001） 事件（事件分类 002002） 特定（特定对象 002003）
    // fl_code: "001001",
    // btn_list: [], //个人  组织共用一个集合
    bm_btn_list: [],
    shix_list: [],
    tishi_title: true,

    qiquxuanze: {
      city: "请选择要办理的城市",
      id: 0
    },

    viewkin1: 1,
    viewkin2: 1,
  },
  close_ts: function() {
    this.setData({
      tishi_title: false,
    })
  },

  onLoad: function(options) {
    var that = this;
  },



  getDept: function() { //获取部门
    var that = this;
    if (that.data.qiquxuanze.id == 0) {
      console.log(11)
      wx.showToast({
        title: '请先选择要办理的城市',
        icon: 'none',
      })
      return
    }

    wx.request({
      url: getApp().globalData.url + 'region/getDepts',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        pageNum: 1,
        pageSize: 10000,
        regionId: that.data.qiquxuanze.id
      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        if (data.data.code == 200) {
          console.log(data)
          var timer = setTimeout(function() {
            clearTimeout(timer)
            that.setData({
              bm_list: data.data.data,
              bmshow: true,
              shix_list: [],
              sxshow: false,
              sx_name: {
                name: "请选择要办理的事项"
              },
            })
          }, 200)
        } else {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }
      }
    })
  },

  getshix_list: function() {
    var that = this;
    if (that.data.bm_name.name == "请选择要办理的部门") {
      wx.showToast({
        title: '请先选择要办理的部门',
        icon: 'none',
      })
      return
    }
    wx.request({
      url: getApp().globalData.url + 'dept/getItems',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        page: 1,
        size: 1000,
        deptId: that.data.bm_name.deptid,
      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        console.log(data)
        if (data.data.code == 200) {
          console.log(data);
          var shix_list = [];
          for (var i = 0; i < data.data.data.length;i++){
            if (data.data.data[i].SFYDSB == 1){
              shix_list.push(data.data.data[i])
            }
          }
          that.setData({
            shix_list: shix_list,
            sxshow: true,
          })
        } else {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }
      }
    })
  },

  pickerSHI: function(e) { //选择市后修改数据

    getApp().pickerSHI(e);
    //从全局变量里面获取地区
    //getApp().get_sx_list();
    var that = this;
    var time = setTimeout(function() {
      that.setData({
        shix_list: getApp().globalData.shix_list,
      })
      clearTimeout(time)
    }, 200)
    this.getDept();
    this.pickerBM(e);
  },
  pickerQU: function(e) { //选择区后修改数据
    var that = this;
    getApp().pickerQU(e);

    //从全局变量里面获取地区
    //getApp().get_sx_list();
    var that = this;
    var time = setTimeout(function() {
      that.setData({
        shix_list: getApp().globalData.shix_list,
      })
      clearTimeout(time)
    }, 200)
    this.getDept();
    this.pickerBM(e);
  },
  pickerBM: function(e) { //选择市后修改数据
    var that = this;
    getApp().pickerBM(e);
    var time = setTimeout(function() {
      that.setData({
        shix_list: getApp().globalData.shix_list,
        sxshow: true,
      })
      clearTimeout(time)
    }, 200)
    //从全局变量里面获取地区
    this.getDept();
  },
  pickerSX: function(e) { //选择市后修改数据
    getApp().pickerSX(e);
    //从全局变量里面获取地区
    this.getDept();
    // this.pickerBM();

  },
  pickerBtn: function(e) { //选择地区切换和省级
    var that = this;
    console.info(e)
    if (e.detail.value == 0) { //省级
      that.setData({
        show_shen: true,
        chose_btn_index: 0
      })
      wx.setStorageSync("show_shen", 'true');
    } else {
      that.setData({
        show_shen: false,
        chose_btn_index: 1
      })
      wx.setStorageSync("show_shen", 'false');
    }
    getApp().get_sx_list();
    this.getDept();
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.setData({
      show_shen: true,
      chose_btn_index: 0
    });
  },

  formSubmit: function(e) {
    if (this.data.sx_name.name == "请选择要办理的事项") {
      wx.showToast({
        title: '请确认要办理的事项',
        icon: 'icon'
      })
    }
    wx.navigateTo({
      url: 'shixiang_xq?itemId=' + this.data.sx_name.id + '&canDo=' + this.data.sx_name.cando + '&deptname=' + this.data.sx_name.deptid + '&sxzxname=' + this.data.sx_name.name + '&isShouc==false&shouc_id=0',
    })
  },

  godiqu: function() {
    wx.navigateTo({
      url: '../selectcity/city',
    })
  },

  //选择部门
  selectbm: function(e) {
    console.log(e)
    var bm_name = {
      cityid: e.currentTarget.dataset.cityid,
      deptid: e.currentTarget.dataset.deptid,
      num: e.currentTarget.dataset.num,
      shortname: e.currentTarget.dataset.shortname,
      name: e.currentTarget.dataset.name,
    }
    this.setData({
      bm_name: bm_name,
      bmshow: false,
    })
  },

  selectsx: function(e) {
    console.log(e)
    var sx_name = {
      name: e.currentTarget.dataset.name,
      deptid: e.currentTarget.dataset.deptid,
      id: e.currentTarget.dataset.id,
      largeitemid: e.currentTarget.dataset.largeitemid,
      smallitemid: e.currentTarget.dataset.smallitemid,
      xzxk: e.currentTarget.dataset.xzxk,
      cando: e.currentTarget.dataset.cando,
    }
    this.setData({
      sx_name: sx_name,
      sxshow: false,
    })
  },

  showhide:function(){
    this.setData({
      sxshow: false,
      bmshow:false,
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})