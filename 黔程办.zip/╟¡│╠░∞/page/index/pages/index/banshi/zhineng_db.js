Page({

  /**
   * 页面的初始数据
   */
  data: {
    type: "",

    shi_list: [],
    shi_index: 0,
    qu_list: [], //{"PARENTID":"520000","AREAID":"520100","AREANAME":"贵阳市","LAYER":"2"}
    qu_index: 0,
    toView: "个人", //个人 组织 部门 经营 默认个人
    gr_zz_fl_qb: "事件分类",
    fl_tj: "主题", //分类条件
    show_shen: true, //显示省级部门  
    chose_btn: ["省级部门", "地区切换"],
    chose_btn_index: 0,
    //分类条件 个人办事时  主题（主题分类001001） 事件（事件分类 001002） 特定（特定对象 001003）
    //分类条件 组织办事时  主题（主题分类002001） 事件（事件分类 002002） 特定（特定对象 002003）
    fl_code: "001001",
    btn_list: [], //个人  组织共用一个集合
    bm_btn_list: [ //部门办事列表     
    ]


  },

  jinru_dd: function(e) { //进入当地部门


    this.setData({
      show_shen: false

    })
    this.getDept();

  },
  xianshi_sj: function(e) { //显示省级
    this.setData({
      show_shen: true
    })
    this.getDept();
  },
  getData() {//从缓存中刷入市区信息
    this.setData({
      shi_list: wx.getStorageSync("shi_list"),
      shi_index: wx.getStorageSync("shi_index"),
      qu_list: wx.getStorageSync("qu_list"),
      qu_index: wx.getStorageSync("qu_index")
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    options.type = "bszn"
    var that = this;
    that.getData()
    //从全局变量里面获取地区



    //获取个人和组织办事
    if (wx.getStorageSync("btn_list").length == 0) {
      wx.request({
        url: getApp().globalData.url + 'services/getAllServices',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {},
        method: 'post',
        dataType: 'json',
        success: function(data) {
          if (data.data.code == 200) {
            that.setData({ //把选中值放入判断值
              btn_list: data.data.data,
              type: options.type
            });
            wx.setStorageSync('btn_list', data.data.data)
          } else {
            wx.showToast({
              title: data.data.msg,
              icon: 'none'
            });
          }
        }
      })
    } else {
      that.setData({ //把选中值放入判断值
        btn_list: wx.getStorageSync("btn_list"),
        type: options.type
      });
    }
    that.getDept();

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  getDept: function() { //获取部门
    var that = this;
    if (that.data.qu_list.length == 0) {
      return;
    }


    if (that.data.show_shen) {
      if (wx.getStorageSync("shen_dept").length == 0) {
        wx.request({
          url: getApp().globalData.url + 'region/getDepts',
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            pageNum: 1,
            pageSize: 10000,
            regionId: "520000"
          },
          method: 'post',
          dataType: 'json',
          success: function(data) {
            if (data.data.code == 200) {
              that.setData({
                bm_btn_list: data.data.data
              })
              wx.setStorageSync("shen_dept", data.data.data)
            } else {
              wx.showToast({
                title: data.data.msg,
                icon: 'none'
              });
            }
          }
        })
      } else {
        that.setData({
          bm_btn_list: wx.getStorageSync("shen_dept")
        })
      }
      return;
    }


    wx.showLoading({
      title: '加载中',
    })
    var addr_id = that.data.qu_list[that.data.qu_index].AREAID
    //获取部门
    wx.request({
      url: getApp().globalData.url + 'region/getDepts',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        pageNum: 1,
        pageSize: 10000,
        regionId: addr_id,

      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        wx.hideLoading();
        if (data.data.code == 200) {
          that.setData({
            bm_btn_list: data.data.data
          })
        } else {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
        }

      }
    })
  },

  pickerSHI: function(e) { //选择市后修改数据

    getApp().pickerSHI(e);
    //从全局变量里面获取地区
    this.getData();
    this.getDept();

  },
  pickerQU: function(e) { //选择区后修改数据
    var that = this;
    getApp().pickerQU(e);

    //从全局变量里面获取地区
    this.getData();

    this.getDept();

  },
  pickerBtn: function(e) { //选择地区切换和省级
    var that = this;
    console.info(e)

    if (e.detail.value == 0) { //省级
      that.setData({
        show_shen: true,
        chose_btn_index: 0
      })

    } else {
      that.setData({
        show_shen: false,
        chose_btn_index: 1
      })
    }
    this.getDept();
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.getData();
    this.setData({
      show_shen: true //设置显示部门
        ,
      chose_btn_index: 0
    });
    this.getDept();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },

  changeView: function(e) { // 个人 组织 部门 切换视图

    if (this.data.toView != e.currentTarget.id) {
      if (e.currentTarget.id == "个人") {
        this.setData({
          toView: e.currentTarget.id,
          fl_code: "001001",
          fl_tj: "主题",
          gr_zz_fl_qb: "事件分类"
        })
      } else if (e.currentTarget.id == "组织") {
        this.setData({
          toView: e.currentTarget.id,
          fl_code: "002001",
          fl_tj: "主题",
          gr_zz_fl_qb: "经营活动"
        })
      } else {
        this.setData({
          toView: e.currentTarget.id
        })
      }
    }
  },
  changeFL: function(e) { // 主题分类 事件分类 特定对象分类 切换视图
    // fl_tj: "主题",
    //分类条件 个人办事  主题（主题分类001001） 事件（事件分类 001002） 特定（特定对象 001003）
    //   fl_code:"001001",
    //个人时
    if (this.data.toView == "个人") {
      if (this.fl_tj != e.currentTarget.id) {
        if (e.currentTarget.id == "主题") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "001001"
          })
        } else if (e.currentTarget.id == "事件") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "001002"
          })
        } else if (e.currentTarget.id == "特定") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "001003"
          })
        }
      }
    } else if (this.data.toView == "组织") { //分类条件 组织办事时  主题（主题分类002001） 事件（事件分类 002002） 特定（特定对象 002003）
      if (this.fl_tj != e.currentTarget.id) {
        if (e.currentTarget.id == "主题") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "002001"
          })
        } else if (e.currentTarget.id == "事件") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "002002"
          })
        } else if (e.currentTarget.id == "特定") {
          this.setData({
            fl_tj: e.currentTarget.id,
            fl_code: "002003"
          })
        }
      }
    }
  },
  /**
    * 用户点击右上角分享
    */
  onShareAppMessage: function () {

  }
})