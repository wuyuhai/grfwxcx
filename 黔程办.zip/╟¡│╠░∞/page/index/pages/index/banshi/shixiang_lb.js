// pages/index/shixiang_lb.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    itemList: [],
    // deptname:'',
    type: "", //网上申请 ：wssq   和办事指南 ：bszn（如果是网上申请则不进入事项详情页面而是直接申报）
    shix_url:'https://m.gzegn.gov.cn/terminal_management/workGuide/findItemInfo'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    // that.setData({
    //   deptname: options.deptname
    // })
    wx.showLoading({
      title: '加载中',
    })
    if (options.intoType != "部门") {
    console.log('按分类查询事项列表');
      wx.request({
        url: that.data.shix_url,
        header: {
          'Content-Type': 'application/json'
        },
        data: JSON.stringify({
          "areaId": wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID,
          "sortCode": options.sortCode,
          // "isDeclare": "1"
        }),
        method: 'post',
        dataType: 'json',
        success: function(data) {
          console.log(data)
          wx.hideLoading()
          if (data.data.code == 200) {
            that.setData({
              itemList: data.data.data,
              type: options.type
            })
          } else {
            wx.showToast({
              title: data.data.msg,
              icon: 'none'
            });
          }
        }
      })
    } else {
      console.log('按部门查询事项列表');
      wx.request({
        url: that.data.shix_url,
        header: {
          'Content-Type': 'application/json'
        },
        data: JSON.stringify({
          "department": options.deptId
          // "isDeclare": "1"
        }),
        method: 'post',
        dataType: 'json',
        success: function(data) {
          console.log(data);
          wx.hideLoading()
          if (data.data.code == 200) {
            that.setData({
              itemList: data.data.data,
              type: options.type
            })
          }else{
            wx.showToast({
              title: data.data.msg,
              icon: 'none'
            });
          }         
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})