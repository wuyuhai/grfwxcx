// pages/index/banshi/shixiang_sb.js 
 
Page({

  /**
   * 页面的初始数据
   */
  data: {
    toView: 'jbbd',
    btns: [{
        id: "jbbd",
        name: "①基本表单",
        img: "/img/quangou.png", 
        is_ok: false
      },
      {
        id: "clsc",
        name: "②材料上传",
        img: "/img/quangou.png",
        is_ok: false
      },

      {
        id: "sdfw",
        name: "③速递服务",
        img: "/img/quangou.png",
        is_ok: false
      },

      {
        id: "sbqr",
        name: "④申报确认",
        img: "/img/quangou.png",
        is_ok: false
      },

    ],
    zj_list: [{ //证件类型
        id: 10,
        name: "身份证"
      }, {
        id: 11,
        name: "军官证"
      },
      {
        id: 12,
        name: "士兵证"
      },

      {
        id: 13,
        name: "警官证"
      },
      {
        id: 14,
        name: "港澳居民来往内地通行证"
      },
      {
        id: 15,
        name: "台湾居民来往大陆通行证"
      },

      {
        id: 16,
        name: "香港身份证"
      },
      {
        id: 17,
        name: "澳门身份证"
      },
      {
        id: 18,
        name: "台湾身份证"
      },
      {
        id: 20,
        name: "护照"
      }, {
        id: 90,
        name: "其他"
      }
    ],
    zz_lx: ["企业", "事业单位", "社团", "机关", "其他"],
    zz_lx_index: 0,
    zj_index: 0, //证件索引
    banshi_type: "个人办事",
    item_info: {}, //当前事项详情
    file_list: [], //文件列表
    //表单1信息
    sqr_mc: "", //申请人名称
    sqr_sfzjhm: "", //申请人身份证号码
    sqr_yddh: "", //申请人移动电话
    zz_mc: "", //组织名称 
    sh_xydm: "", //社会信用代码  
    fd_dbr: "", //法定代表人  
    shudi_type: "窗口递交", //递交材料方式
    shou_jr: "", //收件人
    shou_jrsjh: "", //收件人手机号

    shou_jrxxdz: "", //收件人详细地址
    zz_lxr:"",
    zz_lxrphone:"",
    zz_zjleixin:0 
  },
  digui: function(f_list, i) {
    var that = this;
    if (i < f_list.length) {
      for (var o = 0; o < f_list[i].img.length;o++){
      wx.uploadFile({
        url: getApp().globalData.url + 'file/upload', //仅为示例，非真实的接口地址
        filePath: f_list[i].img[o],
        name: 'file',
        formData: {
          'userId': wx.getStorageSync('user_id'),// wx.getStorageSync('user_id'),
          'itemId': that.data.item_info.ID,
          'fileType': f_list[i].CLMC,
          'itemName': that.data.item_info.SXZXNAME,
        },
        success: function(res) {
          var data = JSON.parse(res.data);
          if (data.code == 200) {
            console.log(data);
            f_list[i].file_id = data.data.FILEID;
            i = i + 1;
            that.digui(f_list, i);
          } else {
            wx.showToast({
              title: '文件上传出错：'+res.data.msg,
              icon: 'none'
            });
            console.log('panduan2')
          }
        }
      })
    }
    } else {
      wx.hideLoading();
      that.sub_form(f_list);
    }
  },
  upload_file_and_sub_form: function() {
    var f_list = this.data.file_list;
    wx.showLoading({
      title: '正在上传材料',
    })
    this.digui(f_list, 0)
  },
  sub_form: function(f_list) { //提交表单
    wx.showLoading({
      title: '提交数据',
    })
    console.log(this.data.shudi_type, this.data.shou_jrsjh, this.data.shou_jr, this.data.shou_jrsjh, this.data.shou_jrxxdz)
    var kindsk = this.data.shudi_type=="窗口递交"?"1":"2";
    if (kindsk == 1){
      var result = "<result><resulttype>" + kindsk + "</resulttype></result>";
    }else{
      var result = "<result><resulttype>" + kindsk + "</resulttype>" +
        "<resultname>" + this.data.shou_jr + "</resultname><resultphone>" + this.data.shou_jrsjh + "</resultphone>" +
        "<resultmobile>" + this.data.shou_jrsjh + "</resultmobile><resultaddress>" + this.data.shou_jrxxdz + "</resultaddress>" +
        "</result>"
    }
    

    //提交表单
    // //材料信息
    var materials = '<materials>';
    for (var i = 0, len = f_list.length; i < len; i++) {
      var tmpItem = f_list[i];
      materials +=
        "<materialinfo><id><![CDATA[" + tmpItem.ID + "]]></id>" +
        "<materialid><![CDATA[" + tmpItem.CLBH + "]]></materialid>" +
        "<materialname><![CDATA[" + tmpItem.CLMC + "]]></materialname>" +
        "<submittype><![CDATA[" + tmpItem.DZHYQ + "]]></submittype>" +
        "<orinum><![CDATA[" + tmpItem.ORINUM + "]]></orinum>" +
        "<copynum><![CDATA[" + tmpItem.COPYNUM + "]]></copynum>" +
        "<isneed><![CDATA[1]]></isneed><status><![CDATA[1]]></status>" +
        "<formid><![CDATA[" + tmpItem.FORMID + "]]></formid>" +
        "<formver><![CDATA[" + tmpItem.FORMVER + "]]></formver>" +
        "<username><![CDATA[" + this.data.sqr_mc + "]]></username>" +
        "<file><fileid><![CDATA[" + tmpItem.file_id + "]]></fileid>" +
        "<filename><![CDATA[" + tmpItem.img[0] + "]]></filename>" +
        "<filedel><![CDATA[1]]></filedel></file></materialinfo>";
    }
    materials += '</materials>';



    //事项信息
    var business =
      '<business><permid><![CDATA[' + this.data.item_info.ID + ']]></permid><largeitemid>' +
      '<![CDATA[' + this.data.item_info.LARGEITEMID + ']]></largeitemid>' +
      '<smallitemid><![CDATA[' + this.data.item_info.LARGEITEMID + ']]></smallitemid>' +
      '<smallitemname><![CDATA[' + this.data.item_info.SXZXNAME + ']]></smallitemname>' +
      '<itemversion><![CDATA[' + this.data.item_info.ITEMVERSION + ']]></itemversion>' +
      '<itemlimittime><![CDATA[' + this.data.item_info.ITEMLIMITTIME + ']]></itemlimittime>' +
      '<itemlimitunit><![CDATA[' + this.data.item_info.ITEMLIMITUNIT + ']]></itemlimitunit>' +
      '<regionid><![CDATA[' + this.data.item_info.REGIONID + ']]></regionid>' +
      '<deptcode><![CDATA[' + this.data.item_info.DEPTID + ']]></deptcode>' +
      '<deptname><![CDATA[' + this.data.item_info.DEPTNAME + ']]></deptname>' +
      '<status><![CDATA[0]]></status><state><![CDATA[5]]></state>' +
      '<applicantid><![CDATA[' + wx.getStorageSync('user_id') + ']]></applicantid></business>';
    var base_form;
    //基本表单
    if (this.data.banshi_type == "个人办事") { //个人办事的基本表单
      base_form = '<baseForm><pid>' + this.data.item_info.ID + '</pid><formid></formid>' +
        '<version>1</version><formtype>10</formtype>' +
        '<datas><data><jbr_mc>' + this.data.sqr_mc + '</jbr_mc><jbr_sfzjhm>' + this.data.sqr_sfzjhm + '</jbr_sfzjhm>' +
        '<jbr_yddh>' + this.data.sqr_yddh + '</jbr_yddh><sqsxmc>' + this.data.item_info.SXZXNAME + '</sqsxmc>'+
        '<sqr_mc>' + this.data.sqr_mc + '</sqr_mc><sqr_sfzjhm>' + this.data.sqr_sfzjhm + '</sqr_sfzjhm>' +
        '<sqr_yddh>' + this.data.sqr_yddh + '</sqr_yddh><sqr_gddh>' + this.data.sqr_yddh + '</sqr_gddh>' +
        '<per_zztype>' + this.data.zj_list[this.data.zj_index].id + '</per_zztype><per_name>' + this.data.sqr_mc + '</per_name>' +
        '<per_idcard>' + this.data.sqr_sfzjhm + '</per_idcard><per_phone>' + this.data.sqr_yddh + '</per_phone>' +
        '<sqr_type>P</sqr_type></data></datas></baseForm>'

    } else { //组织办事基本表单
      base_form = '<baseForm><pid>' + this.data.item_info.ID + '</pid><formid></formid>' +
        '<version>1</version><formtype>10</formtype>' +
        '<datas><data><jbr_mc>' + this.data.sqr_mc + '</jbr_mc><jbr_sfzjhm>' + this.data.sqr_sfzjhm + '</jbr_sfzjhm>' +
        '<jbr_yddh>' + this.data.sqr_yddh + '</jbr_yddh><sqsxmc>' + this.data.item_info.SXZXNAME + '</sqsxmc>'+
        '<sqr_mc>' + this.data.zz_lxr + '</sqr_mc><sqr_sfzjhm>' + this.data.fdzj_num1 + '</sqr_sfzjhm>' +
        '<sqr_yddh>' + this.data.zz_lxrphone + '</sqr_yddh><sqr_gddh>' + this.data.zz_lxrphone + '</sqr_gddh>'+
        "<ler_cname>" + this.data.zz_mc + "</ler_cname><ler_type>" + this.data.zz_lx[this.data.zz_lx_index] + "</ler_type>" +
        "<ler_addr>组织地址</ler_addr><ler_regmoney>" + this.data.sh_xydm + "</ler_regmoney>" +
        "<ler_pname>" + this.data.fd_dbr + "</ler_pname><ler_zjhm>组织证件号码</ler_zjhm>" +
        "<ler_zztype>证件类型</ler_zztype><ler_zzjgdm>123131</ler_zzjgdm>" +
        '<sqr_type>I</sqr_type></data></datas></baseForm>';
    }
    console.log(materials, business, base_form, result)
    wx.request({
      url: getApp().globalData.url + 'online/formSubmit',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        token: wx.getStorageSync('token'),
        materials: materials,
        business: business,
        baseForm: base_form,
        result: result,
        // paper:1
      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        wx.hideLoading();
        if (data.data.code == 200) {
          wx.showModal({
            showCancel: false,
            title: '申报成功',
            content: '订单号为:' + data.data.data.bsnum,
            success: function(res) {
              wx.redirectTo({
                url: '/page/home/pages/home/my_banjian',
              })
            }
          })
        } else {
          if (data.data.msg == "登录已超时，请重新登录") {
            wx.showToast({
              title: '登录超时，请重新登录,2s后跳到登录页面',
              icon: 'none'
            });
            wx.removeStorageSync('token');
            var timer = setTimeout(function(){
              clearTimeout(timer)
              wx.navigateTo({
                url: '/page/home/pages/home/login/selcet_login_type',
              })
            },2000)     
            return
          } else {
            wx.showToast({
              title: '政务系统繁忙',
              icon: 'none'
            });
          } 
        }
      },
      fail: function(res) {
        console.log(res)
      }
    })


  },
  set_shou_jr: function(e) { //设置收件人
    this.setData({
      shou_jr: e.detail.value
    })
  },
  set_shou_jrsjh: function(e) { //设置收件人手机号
    this.setData({
      shou_jrsjh: e.detail.value
    })
  },

  set_shou_jrxxdz: function(e) { //设置收件人详细地址
    this.setData({
      shou_jrxxdz: e.detail.value
    })
  },

  set_zz_mc: function(e) { //设置组织名称
    this.setData({
      zz_mc: e.detail.value
    })
  },
  set_sh_xydm: function(e) { //设置社会信用代码
    this.setData({
      sh_xydm: e.detail.value
    })
  },
  set_fd_dbr: function(e) { //设置法定代表人
    this.setData({
      fd_dbr: e.detail.value
    })
  },
  set_sqr_mc: function(e) { //设置申请人名称
    this.setData({
      sqr_mc: e.detail.value
    })
  },
  set_sqr_sfzjhm: function(e) { //设置申请人身份证号码
    this.setData({
      sqr_sfzjhm: e.detail.value
    })
  },
  set_sqr_yddh: function(e) { //设置申请人身份证号码
    this.setData({
      sqr_yddh: e.detail.value
    })
  },
  picker_zz_zjleixin: function(e) {
    if (this.data.zz_zjleixin != e.detail.value) {
      this.setData({
        zz_zjleixin: e.detail.value
      })
    }
  },
  set_fdzj_num1: function () {
    this.setData({
      fdzj_num1: e.detail.value
    })
  },
  set_zz_lxr: function () {
    this.setData({
      zz_lxr: e.detail.value
    })
  },
  set_zz_lxrphone:function(){
    this.setData({
      zz_lxrphone: e.detail.value
    })
  },
  change_view: function(e) { //点击切换展示栏
    if (this.data.toView != e.currentTarget.id) {
      var toView = this.data.toView; //被验证的页面
      if (toView == "jbbd") { //验证基本表单
        if (this.data.sqr_mc != "" && this.data.sqr_sfzjhm != "" && this.data.sqr_yddh != "") {
          if (this.data.banshi_type == "组织办事") { //组织办事验证表单
            if (this.data.zz_mc != "" && this.data.sh_xydm != "" && this.data.fd_dbr != "") {
              this.set_is_ok_true("jbbd", true)
            } else {
              this.set_is_ok_true("jbbd", false)
            }
          } else { //检查个人申请部分
            this.set_is_ok_true("jbbd", true)
          }
        } else {
          this.set_is_ok_true("jbbd", false)
        }
      } else if (toView == "clsc") { //验证材料上传
        var file_list = this.data.file_list;
        var flag = true;
        for (var i = 0; i < file_list.length; i++) {
          if (file_list[i].img == null) {
            flag = false;
            break;
          }
        }
        if (flag) {
          this.set_is_ok_true("clsc", true)
        } else {
          this.set_is_ok_true("clsc", false)
        }
      } else if (toView == "sdfw") { //验证速递服务
        if (this.data.shudi_type == "窗口递交") {
          this.set_is_ok_true("sdfw", true)
        } else {
          if (this.data.shou_jr != "" && this.data.shou_jrsjh != "" && this.data.shou_jrxxdz != "") {
            this.set_is_ok_true("sdfw", true)
          } else {
            this.set_is_ok_true("sdfw", false)
          }
        }
      }


      if (e.currentTarget.id == "sbqr") { //进入申报确认是直接验证
        if (this.data.btns[0].is_ok && this.data.btns[1].is_ok && this.data.btns[2].is_ok) {
          //如果前两个都通过，则进入该页面时直接通过验证
          this.set_is_ok_true("sbqr", true)
        } else {
          this.set_is_ok_true("sbqr", false)
        }
      }
      this.setData({ //切换视图
        toView: e.currentTarget.id
      })
    }
  },

  set_is_ok_true: function(id, ok) { //设置菜单是否通过验证
    var list = this.data.btns; //四个待验证的按钮
    for (var i = 0; i < list.length; i++) {
      if (list[i].id == id) {
        list[i].is_ok = ok;
      }
    }
    this.setData({
      btns: list
    })
  },

  change_sqlx: function(e) { //改变申请类型
    if (this.data.toView != e.currentTarget.id) {
      this.setData({
        banshi_type: e.currentTarget.id
      })
    }


  },
  change_shoujian: function(e) { //改变申请类型
    if (this.data.shoujian_type != e.currentTarget.id) {
      this.setData({
        shoujian_type: e.currentTarget.id
      })
    }


  },
  change_sdlx: function(e) { //改变申请类型
    if (this.data.toView != e.currentTarget.id) {
      this.setData({
        shudi_type: e.currentTarget.id
      })
      if (this.data.shou_jr == "" && this.data.shou_jrsjh == "" && this.data.shou_jrxxdz == ""){
        this.morenaddress();
      }      
    }

  },
  picker_zj: function(e) { //选择证件类型
    if (this.data.zj_index != e.detail.value) {
      this.setData({
        zj_index: e.detail.value
      })

    }
  },
  picker_zz_lx: function(e) { //选择组织类型
    if (this.data.zj_index != e.detail.value) {
      this.setData({
        zz_lx_index: e.detail.value
      })
    }
  },
  delete_file: function(e) { //删除文件
  console.log(e)
    var list = this.data.file_list;
    var idx = e.target.dataset.idx;
    for (var i = 0; i < list.length; i++) {
      if (list[i].ID == e.currentTarget.id) {
        // list[i].img = null
        list[i].img.splice(idx,1);
      }
    }

    this.setData({
      file_list: list
    })

  },
  select_file: function(en) {
    console.log(en.currentTarget.id)
    var that = this;
    wx.showActionSheet({
      itemList: ['拍照', '图库','我的材料'],
      success: function(e) {
        if (e.tapIndex == 0) { //拍照
          wx.chooseImage({
            count: 1, // 默认9
            sizeType: ['original'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function(res) {
              // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
              var tempFilePaths = res.tempFilePaths
              that.change_img_src(en.currentTarget.id, tempFilePaths, e.tapIndex, en.currentTarget.dataset.item)
            }
          })
        } else if (e.tapIndex == 1){ //图库
          wx.chooseImage({
            count: 9, // 默认9
            sizeType: ['original'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album'], // 可以指定来源是相册还是相机，默认二者都有
            success: function(res) {
              // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
              var tempFilePaths = res.tempFilePaths

              that.change_img_src(en.currentTarget.id, tempFilePaths, e.tapIndex, en.currentTarget.dataset.item)
            }
          })
        }else{
          
          wx.navigateTo({
            url: '/page/home/pages/home/my_srcs?kind=2&id=' + en.currentTarget.id + "&list=" + JSON.stringify(that.data.file_list),
          })
        }
      }
    })

  },

  change_img_src(id, tempFilePaths,c,d) { //修改每个办事文件的路径
    console.log(tempFilePaths)
    if (tempFilePaths != "") {
      var list = this.data.file_list;
      for (var i = 0; i < list.length; i++) {
        if (list[i].ID == id) {
          // list[i].img = tempFilePaths
          if (list[i].img){
            for (var o = 0; o < tempFilePaths.length;o++){
              list[i].img.push(tempFilePaths[o])
            }
          }else{
            list[i].img = tempFilePaths
          }
        }
      }
      this.setData({
        file_list: list
      })
      wx.showModal({
        title: '温馨提示',
        content: '文件上传成功，是否添加到我的材料下次使用',
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定');
            var mysrcs;
            if (wx.getStorageSync("mysrcs")){
              mysrcs = wx.getStorageSync("mysrcs");
            }else{
              mysrcs = [];
            }
            if (mysrcs.length >= 0){
              var namesame = false,srcsame = false;
              for (var i = 0; i < mysrcs.length; i++) {
                if (mysrcs[i].srcname == d){
                  namesame = true;
                  for (var j = 0; j < mysrcs[i].srcimg.length;j++){
                    var str = mysrcs[i].srcimg[j].src;
                    str = str.substring(str.length-36);
                    if (str == tempFilePaths[0].substring(tempFilePaths[0].length - 36)){                  
                      srcsame = true;
                    }
                  }
                  if (srcsame == false){
                    mysrcs[i].srcimg.push({ src: tempFilePaths[0] })
                  }                
                }
              }
              if (namesame == false){
                mysrcs.push({ srcname: d, time: Date.parse(new Date()), srcimg: [{ src: tempFilePaths[0] }] })
              }
            }      
            wx.setStorageSync("mysrcs", mysrcs);
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      console.info(list)
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

    if (options.canDo != "true") {
      wx.redirectTo({
        url: '/pages/public/no_pass?title=该事项不支持网上申报',
      });
      return;
    } else {
      this.setData({
        sqr_mc: wx.getStorageSync('user_name'),
        sqr_sfzjhm: wx.getStorageSync('idCardNumber'),
        sqr_yddh: wx.getStorageSync('user_mobile'),
      })
      var that = this;
      //获取事件详情
      wx.request({
        url: getApp().globalData.url + 'services/getItemDetail',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          itemId: options.itemId
        },
        method: 'post',
        dataType: 'json',
        success: function(data) {
          if (data.data.code == 200) {
            that.setData({ //把选中值放入判断值
              canDo: options.canDo,
              item_info: data.data.data
            });
          }
        }
      })

      //获取文件列表
      wx.request({
        url: getApp().globalData.url + 'item/getItemFile',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          itemId: options.itemId
        },
        method: 'post',
        dataType: 'json',
        success: function(data) {
          console.log(data)
          if (data.data.code == 200) {
            var list = data.data.data;
            var list_bixu = [];
            for (var i = 0; i < list.length; i++) {
              if (list[i].SFBY == 1) {
                list_bixu.push(list[i])
              }
            }
            that.setData({ //把选中值放入判断值           
              file_list: list_bixu
            });

          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.setData({
      sqr_mc: wx.getStorageSync('user_name'),
      sqr_sfzjhm:wx.getStorageSync('idCardNumber'),
      sqr_yddh: wx.getStorageSync('user_mobile'),
    })
    console.log(this.data.sqr_yddh)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },


  no_can_sb: function() {

    wx.showToast({
      title: '表单验证不通过，不能申报',
      icon: 'none',
      duration: 2000
    })
  },

  //获取默认地址
  morenaddress:function(){
    var that = this;
    wx.request({
      url: getApp().globalData.url + 'shippingAddr/getList',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: { uType: wx.getStorageSync('uType'), userId: wx.getStorageSync('user_id') },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if (data.data.code == 200) {
          if (data.data.data.length > 0) {
            for (var i = 0; i < data.data.data.length; i++) {
              if (data.data.data[i].defaultAddr == true) {
                console.log(data.data.data[i])
                that.setData({
                  shou_jr: data.data.data[i].consignee,
                  shou_jrsjh: data.data.data[i].mobile,
                  shou_jrxxdz: data.data.data[i].city + data.data.data[i].district + data.data.data[i].street
                })                
              }
            }
          }
        } else {
          wx.showToast({
            title: '政务系统繁忙',
            icon: 'none'
          })
        }
      }
    }) 
  },
  /**
    * 用户点击右上角分享
    */
  onShareAppMessage: function () {

  }
})