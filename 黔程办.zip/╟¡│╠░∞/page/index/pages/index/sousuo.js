// pages/index/sousuo.js

//微信小程序新录音接口，录出来的是aac或者mp3，这里要录成mp3
const mp3Recorder = wx.getRecorderManager()
const mp3RecoderOptions = {
  duration: 60000,
  sampleRate: 16000, 
  numberOfChannels: 1,
  encodeBitRate: 48000,
  format: 'mp3',
}

Page({

  /**
   * 页面的初始数据
   */
  data: {
    key: '', //搜索关键字  
    yuyin_box_show: '', //语音输入框 是否显示 为空不显示 show 为显示
    scroll_y: true, //是否允许竖向滚动
    sousuo_text: "请按住按钮说话",
    is_quedin: "", //是否倾听完毕  “” 没有 xuanzhe 确定
    show_search_box: false,
    rmss_list: [ //热门搜索
    ],
    search_box: [ //搜索结果
    ],
    jqss_list: [ //近期搜索
    ],
    kind:""
  },
  input_and_select: function(e) { //输入并搜索
    var that = this;
    that.setData({
      key: e.currentTarget.id
    });
    that.search_key()
  },
  get_rmss: function() { //获取热门搜索关键词 /item/getHotWords
    var that = this;
    //请求搜索结果
    wx.request({
      url: getApp().globalData.url + 'item/getHotWords',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {},
      method: 'post',
      dataType: 'json',
      success: function(data) {
        console.log(data)
        if (data.data.code == 200) {
          that.setData({
            rmss_list: data.data.data
          });
        }
      }
    })
  },
  to_project:function(e){
    console.log(e.currentTarget.dataset)
    var can;
    if (e.currentTarget.dataset.can){
      can = true;
    }else{
      can = false;
    }
    if(this.data.kind == 1){
      wx.navigateTo({
        url: '/page/index/pages/index/banshi/shixiang_xq?itemId=' + e.currentTarget.dataset.id + '&canDo=' + can + '&deptname=' + e.currentTarget.dataset.deptname + '&sxzxname=' + e.currentTarget.dataset.sxzxname + '&isShouc==false&shouc_id=0',
      })
    }else{
      wx.navigateTo({
        url: '/page/home/pages/home/shixian/shixiang_xq?itemId=' + e.currentTarget.dataset.id + '&canDo=' + can + '&deptname=' + e.currentTarget.dataset.deptname + '&sxzxname=' + e.currentTarget.dataset.sxzxname,
      })
    }
   
  },
  get_jqss_form_strag: function() { //将缓存中的近期搜索刷如集合
    this.setData({
      jqss_list: wx.getStorageSync("search_history")
    })
  },
  delete_history: function(e) { //删除单项近期搜索
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定要删除该条近期记录吗？',
      success: function(res) {
        if (res.confirm) {

          var his_list = that.data.jqss_list;
          var new_his_list = [];
          for (var i = 0; i < his_list.length; i++) {
            if (his_list[i].ID == e.currentTarget.id) {} else {
              new_his_list.push(his_list[i])
            }
          }
          that.setData({
            jqss_list: new_his_list
          })
          wx.setStorageSync("search_history", new_his_list);
        }
      }
    })
  },
  delete_all_jqss: function() { //清除所有近期搜索
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定要清除近期搜索',
      success: function(res) {
        if (res.confirm) {
          that.setData({
            jqss_list: []
          })
          wx.removeStorageSync("search_history")
        }
      }
    })

  },
  setKey: function(e) { //同步数据
    this.setData({
      key: e.detail.value,
      show_search_box: false
    })
  },
  search_key: function() { //搜索按钮点击
    if (this.data.key.trim() != "") { //如果关键字不为空，则查询
      var that = this;
      wx.showLoading({
        title: '搜索中...',
      })
      //请求搜索结果
      wx.request({
        url: getApp().globalData.url + 'item/getItemByKeyWord',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          page: 1,
          size: 100,
          keyWord: this.data.key,
          regionId: 520000 //wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID
        },
        method: 'post',
        dataType: 'json',
        success: function(data) {
          wx.hideLoading()
          console.log(data);
          if (data.data.code == 200) {
            that.setData({
              search_box: data.data.data,
              show_search_box: true
            });
            var old_list = wx.getStorageSync("search_history");
            var new_list = data.data.data;
            var nolist = []
            for (var i = 0; i < new_list.length;i++){
              var bol = false;
              for (var j = 0; j < old_list.length;j++){
                if (new_list[i].ID == old_list[j].ID){
                  bol = true;
                }
              }
              if (bol == false){
                nolist.push(new_list[i]);
              }
            }
            wx.setStorageSync("search_history", nolist.concat(old_list));
          }
        }
      })

      this.get_jqss_form_strag()
    } else { //如果关键字为空，提示并隐藏查询结果
      wx.showToast({
        title: '请输入关键字',
        icon: 'none'
      });
      this.get_jqss_form_strag()
      this.setData({
        show_search_box: false
      })

    }
  },
  xianshi_box: function() { //显示语音输入
    this.setData({
      yuyin_box_show: "show",
      scroll_y: false,
      sousuo_text: "请按住按钮说话",
    });
  },
  yinchan_box: function() { //隐藏语音输入
    this.setData({
      yuyin_box_show: "",
      scroll_y: true
    });
  },
  quedin_box: function() { //确定按钮
    if (this.data.is_quedin == "xuanzhe") {
      this.search_key();
      this.yinchan_box();
    }

  },

  touchdown: function() { //按下按钮
    //touchdown_mp3: function () {
    console.log("按下按钮")
    var _this = this;
    this.setData({
      sousuo_text: "正在倾听..."
    })
    mp3Recorder.start(mp3RecoderOptions); //调用开始录音方法
  },
  touchup: function() { //松开按钮
    //touchup_mp3: function () {
    console.log("松开按钮")
    this.setData({
      sousuo_text: "倾听完毕",
      is_quedin: "xuanzhe"
    })
    mp3Recorder.stop();
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log(options)
    this.setData({
      kind: options.kind
    })

    mp3Recorder.onStart(() => { //定义开始录音方法
      console.log('开始录音')
    })

    mp3Recorder.onStop((res) => { //定义结束录音时获取录音文件 大小和路径    
      var {
        tempFilePath
      } = res;
      var urls = "https://api.happycxz.com/wxapp/mp32asr";
      processFileUploadForAsr(urls, tempFilePath, this); //上传录音识别
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    // wx.setStorageSync("search_history", this.data.jqss_list)
    this.get_jqss_form_strag()
    this.get_rmss()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})

//上传录音文件到 api.happycxz.com 接口，处理语音识别和语义，结果输出到界面
function processFileUploadForAsr(urls, filePath, that) {
  wx.uploadFile({
    url: urls,
    filePath: filePath,
    name: 'file',
    formData: {
      "appKey": 'b4118cd178064b45b7c8f1242bcde31f',
      "appSecret": '7908028332a64e47b8336d71ad3ce9ab',
      "userId": '9dc6138a-f39a-18dd-77a7-debf2405f3b7'
    },
    header: {
      'content-type': 'multipart/form-data'
    },
    success: function(res) {
      try {
        var obj = JSON.parse(res.data);
        var result = JSON.parse(obj.result);
        if (result.seg !== "") {
          var findkey = result.seg.replace(/\s/g, "");
          that.setData({
            key: findkey
          });
        }
      } catch (err) {
        wx.showToast({
          title: '语音识别故障',
          icon: 'none'
        });
      }
    },
    fail: function(res) {
      wx.showModal({
        title: '提示',
        content: "网络请求失败，请确保网络是否正常",
        showCancel: false,
        success: function(res) {}
      });

    }
  });
}