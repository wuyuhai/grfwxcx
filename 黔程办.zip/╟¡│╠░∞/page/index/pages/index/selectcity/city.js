Page({
  data: {
    seleccity: "",
    erjisecity:{},
    shi_list: [],
    qu_list:[],
    lvtwo:false,
    lvone: true,
  },
  onLoad: function(options) {
    this.getcity("520000")
  },

  select: function(e) {
    var city = {}
    if (e.currentTarget.dataset.kind == 0){ 
      city = {
        city: e.currentTarget.dataset.city,
        id: e.currentTarget.dataset.id,
      }
      this.addressure(city)
    }
    if (e.currentTarget.dataset.kind == 1){
      this.getcity(e.currentTarget.dataset.id);
      this.setData({
        seleccity: e.currentTarget.dataset.city,
        erjisecity: { name: e.currentTarget.dataset.city,
          id: e.currentTarget.dataset.id }
      })      
    }  
    if (e.currentTarget.dataset.kind == 2) {
      city = {
        city: e.currentTarget.dataset.city,
        id: e.currentTarget.dataset.id,
      }
      this.setData({
        areacity: e.currentTarget.dataset.city,
      })
      this.addressure(city)
    }  
  },

  //请求地址
  getcity: function(id) {
    var that = this;
    wx.request({
      url: getApp().globalData.url + 'region/getRegions',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        pageNum: 1,
        pageSize: 10000
      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        //console.log(data)
        if (data.data.code == 200) {
          var list = [];
          for (var i = 0; i < data.data.data.length; i++) {
            if (data.data.data[i].PARENTID == id) { //设置贵州省的所有市
              if (data.data.data[i].AREAID != "520000"){
                list.push(data.data.data[i]);
              }
            }
          }
         // console.log(list)
          if(id == "520000"){
            that.setData({
              shi_list: list
            })
          }else{
            that.setData({
              qu_list: list,
              lvtwo: true,
              lvone: false,
            })
          }  
        }
      }
    })
  },

  nachange:function(e){
    if (e.currentTarget.dataset.kind == 1){
      this.setData({
        lvtwo: false,
        lvone: true,
      })
    }
    if (e.currentTarget.dataset.kind == 2) {
      this.setData({
        lvtwo: true,
        lvone: false,
      })
    }
  },

  //信息确认
  addressure: function(city) {
    var that = this;
    var pages = getCurrentPages();
    var currPage = pages[pages.length - 1]; //当前页面
    var prevPage = pages[pages.length - 2]; //上一个页面
    console.log(city)
    prevPage.setData({
      qiquxuanze:city,
      shix_list:[],
      bm_list:[],
      bmshow: false,
      sxshow: false,
      bm_name: {name: "请选择要办理的部门"},
      sx_name: { name: "请选择要办理的事项" },
    })
    wx.navigateBack({
      delta: 1
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})