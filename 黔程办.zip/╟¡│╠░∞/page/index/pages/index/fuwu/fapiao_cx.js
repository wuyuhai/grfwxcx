// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    msg: "发票查询",
    code: 'ly5V',
    user_code: 'ly5V',//测试时验证码可以和初始验证码一样，上线后必须修改
    date: '1996-06-24',
    date_i:'1996/06/24', 
    show:true,
    ghdw: '邓威',
    fplx:'普通类型',
    str1:'',
    str2:'',
    str3:''
  },
  input_str1: function (e) {this.setData({str1: e.detail.value})},
  input_str2: function (e) {this.setData({str2: e.detail.value})},
  input_str3: function (e) {this.setData({ str3: e.detail.value})},
  bindDateChange: function (e) {//更改日期时修改上传日期格式
    this.setData({
      date: e.detail.value,
      date_i: e.detail.value.replace(/-/g, "/"),
    })
  },
  changeCode: function () {
    var chang_code = '';
    var codeLength = 4;
    var random = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
      'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'); //随机数
    for (var i = 0; i < codeLength; i++) {
      var charIndex = Math.floor(Math.random() * 36); //取得随机数的索引
      chang_code += random[charIndex];
    }
    this.setData({
      code: chang_code
    })
  },
  user_code: function (e) {//用户修改验证码
    this.setData({
      user_code: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
    // if (this.data.user_code.toUpperCase() == _that.data.code.toUpperCase()) {
      // 验证码输入正确时的操作
      console.log('form发生了submit事件，携带数据为：', e.detail.value);
      var obj_s2 = JSON.stringify(e.detail.value);
      // { invoiceCode: "152001422001", invoiceDate: "2015/01/12", invoiceMoney: "38000", invoiceNum: "00070415" }
      if (_that.data.str1 == '' || _that.data.str2 == '' || _that.data.str3 == '' ) {
        wx.showToast({
          title: '请输入完整信息！所有项必填!',
          icon: 'none'
        });
      } else {
      wx.showLoading({
        title: '查询中',
      })
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        // data: e.detail.value,
        data: { 'param': obj_s2, 'url': 'http://202.98.195.208:83/IntegratedQuery/invoiceQuery' },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if(data.data.code == 200){
            if (data.data.data.fplx == 'JDCFP'){
              _that.setData({ fplx:'机动车发票'});
            } else if (data.data.data.fplx == 'ZZSFP'){
              _that.setData({ fplx: '增值税发票' });
            }else{
              _that.setData({ fplx: '普通发票' });
            }
            _that.setData({
              show: false,
              ghdw: data.data.data.ghdw
            });
          }else if(data.data.code == 501){
            wx.showToast({
              title: '发票查询系统异常！请稍后再试',
              icon: 'none'
            });
            _that.setData({
              show: true,
            });
          }else{
            wx.showToast({
              title: '没有查到数据，请检查输入！',
              icon: 'none'
            });
            _that.setData({
              show: true,
            });
          }
        }
      })//ajax end
      }
    // } else {
    //   wx.showToast({
    //     title: '验证码输入有误！',
    //     icon: 'none'
    //   });
    // }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})