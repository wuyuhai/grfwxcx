var app = getApp();
Page({
  data: {
   code:'R5DV',
   user_code:'R5DV',
   msg:"社保查询",
    array: ['贵州省省本级', '贵阳','六盘水市', '安顺市', '铜仁市', '贵安新区', '遵义市', '毕节市', '黔东南苗族侗族自治州', '黔南布依族苗族自治州','黔西南布依族苗族自治州'],
    array2: ['529900', '520100', '520200', '520400', '522200', '527000', '520300', '520500', '522600', '522700','522300'],
   index: 0,
   show: true,
   listData: [],
   listData2:[],
   str2: '',
   idCard:'',
   user_name:'',
   showmode: {
     show: false,
     phone: '',
   },
   id:0,
  },
  bindPickerChange: function (e) {
    this.setData({
      index: e.detail.value,
      show:true
    })
  },
  input_str: function (e) { this.setData({ idCard: e.detail.value }) },
  input_str2: function (e) { this.setData({ str2: e.detail.value }) },
  changeCode:function(){
    var chang_code = '';
    var codeLength = 4;
    var random = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
      'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'); //随机数
    for (var i = 0; i < codeLength;i++){
      var charIndex = Math.floor(Math.random() * 36); //取得随机数的索引
      chang_code += random[charIndex];
    }
    this.setData({
      code: chang_code
    })
  },
  user_code: function(e){
    this.setData({
      user_code: e.detail.value
    })
  },
  formSubmit: function (e) {
    var that = this;
    if (this.data.user_code.toUpperCase() == this.data.code){
      // 验证码输入正确时的操作
      console.log('form发生了submit事件，携带数据为：', e.detail.value);
      // {idCard: "522428198801240046", sbPassword: "118627", addrNo: "520500"}
      var obj_s2 = JSON.stringify(e.detail.value);
      if (that.data.idCard ==''){
        wx.showToast({
          title: '请输入社保卡身份证号！',
          icon: 'none'
        });
      } else if (that.data.str2 == ''){
        wx.showToast({
          title: '请输入密码！',
          icon: 'none'
        });
      }
      else{
        wx.showLoading({
          title: '查询中',
        });
        if (e.detail.value.addrNo == '520100'){
          wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',
            header: {
            'Content-Type': getApp().globalData.contentType
          },
          // 522427199311297013
          data: {
            'param': JSON.stringify({
              "appid": "cf6dc16744ab4613b871e3745c812ce1",
              "apiu": "GYSRSJSHBXGLXXXT/shbxglxt_grjbxxcxb",
              "paramMap": {
                "SFZHM": that.data.idCard
                //"SFZHM": '522427199311297013'
              },
              "apikey": "eb7669c72516fb9a558b6c26d49891d6"
            }),
              'headers': JSON.stringify({
                'apiCode': '100W1376',
                "netType":1
              }),
            'url': getApp().globalData.sousuo_url +'/postJson'
          },
          method: 'post',
            dataType: 'json',
              success: function (data) {
                wx.hideLoading();
                console.log(data);
                if (data.data.code==500){
                  wx.showToast({
                    title: '请求异常，请稍后重试！',
                    icon: 'none'
                  });
                  return;
                }
                if (data.data.head.code == 200) {
                  if (data.data.result.data.items) {
                    that.setData({
                      show: false,
                      listData2: data.data.result.data.items,
                    })
                  } else {
                    wx.showToast({
                      title: '没有查到数据，请检查输入或是否开通此业务！',
                      icon: 'none'
                    });
                  }
                } else {
                  wx.showToast({
                    title: '没有查到数据，请检查输入或是否开通此业务！',
                    icon: 'none'
                  });
                }
              }
        })//ajax end
        }else if(e.detail.value.addrNo == '522300'){
          wx.request({
            url: getApp().globalData.url + 'requestDelegate/handle',
            header: {
              'Content-Type': getApp().globalData.contentType
            },
            // 522328196512240424
            data:{
              'param':JSON.stringify({
                'data': 'idCard=' + that.data.idCard,
              }),
              'headers':JSON.stringify({
                'apiCode':'100W1115'
              }),
              'url': getApp().globalData.sousuo_url + '/postJson'
            },
            method: 'post',
            dataType: 'json',
            success: function (data) {
              wx.hideLoading();
              console.log(data);
              if (data.data.result.code==500){
                wx.showToast({
                  title: '请求异常，请稍后重试！',
                  icon: 'none'
                });
                return;
              }
              if (data.data.head.code == 200) {
                if (data.data.result.data.length>0) {
                  that.setData({
                    show: false,
                    listData2: data.data.result.data,
                  })
                } else {
                  wx.showToast({
                    title: '没有查到数据，请检查输入或是否开通此业务！',
                    icon: 'none'
                  });
                }
              } else {
                wx.showToast({
                  title: '没有查到数据，请检查输入或是否开通此业务！',
                  icon: 'none'
                });
              }
            }
          })//ajax end
        }else{
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        // data: e.detail.value,
        data: { 'param': obj_s2, 'url': 'http://202.98.195.208:83/apiroute/sbFind' },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data); 
          wx.hideLoading();
          if(data.statusCode == 200){
            if (data.data.sbkxx){
              var list = data.data.sbkxx.body.output.resultset.row;
              delete list.rn;
              delete list.createTime;
              var array = [];
              for (var key in list) {
                if (key == 'aab301') { key = '参保所在地'; list['参保所在地'] = list['aab301']; }
                if (key == 'aac003') { key = '参保人姓名'; list['参保人姓名'] = list['aac003']; }
                if (key == 'yac005') { key = '卡号'; list['卡号'] = list['yac005']; }
                if (key == 'yac181') { key = '卡状态';
                  if (list['卡状态'] = '1'){
                    list['卡状态'] = '正常';
                  } else if (list['卡状态'] = '2'){
                    list['卡状态'] = '注销';
                  } else if (list['卡状态'] = '3'){
                    list['卡状态'] = '正式挂失';
                  } else if (list['卡状态'] = '4'){
                    list['卡状态'] = '临时挂失';
                  }else{
                    list['卡状态'] = '已发卡未启用';
                  }
                 }
                if (key == 'yac202') { key = '制卡银行'; list['制卡银行'] = list['yac202']; }
                var list2 = data.data.sbxx.body.output.resultset;
                array.push({ 'text': key, 'type': list[key] });
              }
              that.setData({
                show: false,
                listData: array,
                listData2: list2,
              })
          }else{
              wx.showToast({
                title: '没有查到数据，请检查输入或是否开通此业务！',
                icon: 'none'
              });
          }
          }
        }
      })//ajax end
      }
      }
    }else{
      wx.showToast({
        title: '验证码输入有误！',
        icon: 'none'
      });
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function(){
      that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
    },1600)
  },
  //订阅
  subs:function(e){
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs:function(e){
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub:function(){
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  this.setData({
    idCard: wx.getStorageSync("idCardNumber"),
    user_name: wx.getStorageSync("user_name"),
  })
  if (this.data.user_name == '' || this.data.user_name == null){
    this.setData({
      showmode: {
        show: true,
        phone: wx.getStorageSync("phone")
      }
    })
  }
  },
  cencel_login: function () {
    wx.switchTab({
      url: '/page/tabBar/index/index',
    })
  },
  to_login: function () {
    wx.navigateTo({
      url: '/page/home/pages/home/login/login_select',
    })
  },
  getPhoneNumber: function (e) { //点击获取手机号码按钮
    var that = this;
    wx.login({
      success: data => {
        console.log(data)
        console.log(e.detail.iv)
        console.log(e.detail.encryptedData)
        var ency = e.detail.encryptedData;
        var iv = e.detail.iv;
        if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
          // 用户取消了获取手机号
        } else { //同意授权
          wx.request({
            method: "POST",
            // url: 'https://face.fotoit.cn:84/UrbanService/user/decodeUserInfo',  //这个解密地址能用
            url: getApp().globalData.url + 'user/decodeUserInfo',
            data: {
              code: data.code,
              encryptedData: e.detail.encryptedData,
              iv: iv,
            },
            header: {
              'content-type': getApp().globalData.contentType,
            },
            success: (res) => {
              console.log(res);
              if (res.data.code == 200) { //code好像只有线上的可以，发布之后如果获取手机号成功会返回200，，跳转选择登陆
                if (res.data.data.phoneNumber) {
                  getApp().savewxinfo(res.data.data.phoneNumber);
                  var phone = res.data.data.phoneNumber.toString();
                  wx.setStorageSync("phone", phone);
                  that.setData({
                    showmode: {
                      show: false,
                      phone: phone,
                    }
                  })
                  wx.navigateTo({
                    url: '/page/home/pages/home/login/login_select',
                  })
                  // wx.showToast({
                  //   title: "解密成功" + phone,
                  //   icon: 'none'
                  // });
                } else {
                  wx.showToast({
                    title: "解密失败",
                    icon: 'none'
                  });
                  that.setData({
                    showmode: {
                      show: false,
                      phone: '',
                    }
                  })
                }
              }
            },
            fail: function (res) {
              console.log("解密失败~~~~~~~~~~~~~");
              console.log(res);
              wx.showToast({
                title: '获取手机号失败，请检查网络！',
                icon: 'none'
              });
            }
          });
        }
      }
    })

  },
})