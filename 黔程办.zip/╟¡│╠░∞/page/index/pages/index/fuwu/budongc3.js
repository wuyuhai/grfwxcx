// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    msg: "不动产办件进度查询",
    code: 'ARJR',
    user_code: 'ARJR',//测试时验证码可以和初始验证码一样，上线后必须修改
    show: true,
    listData: [],
    listData2: [],
    ghdw: '邓威', 
    fplx: '普通类型',
    str: '',
    str2:'',
  },
  input_str: function (e) { this.setData({ str1: e.detail.value }) },
  input_str2: function (e) { this.setData({ str2: e.detail.value }) },
  changeCode: function () {
    var chang_code = '';
    var codeLength = 4;
    var random = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
      'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'); //随机数
    for (var i = 0; i < codeLength; i++) {
      var charIndex = Math.floor(Math.random() * 36); //取得随机数的索引
      chang_code += random[charIndex];
    }
    this.setData({
      code: chang_code
    })
  },
  user_code: function (e) {//用户修改验证码
    this.setData({
      user_code: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
    if (this.data.user_code.toUpperCase() == this.data.code.toUpperCase()) {
      // 验证码输入正确时的操作
      console.log('form发生了submit事件，携带数据为：', e.detail.value);
      // http://bdcbigdata.com/preexam/web/queryProgress/queryProgressBySexcutdocnum?sexcutdocnum=600-61-201811559&password=9661
      if (this.data.str1 == '' || this.data.str2 == '' ) {
        wx.showToast({
          title: '请输入完整信息，所有项必填！',
          icon: 'none'
        });
      } else {
        var obj_s2 = JSON.stringify(e.detail.value);
      wx.request({
        // url: 'http://202.98.195.208:83/IntegratedQuery/realPropertyQueryProgress',
        url: getApp().globalData.url + 'requestDelegate/handle',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        // data: e.detail.value,
        data: { 'param': obj_s2, 'url': 'http://202.98.195.208:83/IntegratedQuery/realPropertyQueryProgress' },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data);
          if (data.data.code == 200) {
            var res0 = data.data.data.list[0].task;
            var res1 = data.data.data.list[0].taskInstance;
            _that.setData({
              show: false,
              listData: res0,
              listData2: res1,
            });
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入！',
              icon: 'none'
            });
            _that.setData({
              show: true,
            });
          }
        }
      })//ajax end
    }
    } else {
      wx.showToast({
        title: '验证码输入有误！',
        icon: 'none'
      });
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})