// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    msg: "工商信息",
    code: 'yu5x',
    user_code: 'yu5x',
    result: '',
    show: true,
    input_str: '',
    listData: [],
  },
  input_str: function(e) {
    this.setData({
      input_str: e.detail.value
    })
  },
  changeCode: function() {
    var chang_code = '';
    var codeLength = 4;
    var random = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
      'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'); //随机数
    for (var i = 0; i < codeLength; i++) {
      var charIndex = Math.floor(Math.random() * 36); //取得随机数的索引
      chang_code += random[charIndex];
    }
    this.setData({
      code: chang_code
    })
  },
  user_code: function(e) {
    this.setData({
      user_code: e.detail.value
    })
  },
  formSubmit: function(e) {
    var _that = this;
    var dw_str = /^[A-Za-z0-9]+$/;
    if (dw_str.test(_that.data.input_str)) {
      var obj_s = {
        entname: "",
        uniscid: _that.data.input_str
      };
    } else {
      var obj_s = {
        entname: _that.data.input_str,
        uniscid: ""
      };
    }
    var obj_s2 = JSON.stringify(obj_s);
    if (this.data.user_code.toUpperCase() == this.data.code.toUpperCase()) {
      // 验证码输入正确时的操作
      console.log('form发生了submit事件，携带数据为：', e.detail.value);
      // ，传递ajax 数据{entname: "珠海方图智能科技有限公司"}或{entname: "91330701717880674U"}
      if (this.data.input_str == '') {
        wx.showToast({
          title: '请输入查询信息！',
          icon: 'none'
        });
      } else {
        wx.showLoading({
          title: '查询中',
        });
      wx.request({
        url: getApp().globalData.url+'requestDelegate/handle',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: { 'param': obj_s2, 'url':'http://202.98.195.208:83/IntegratedQuery/enterpriseInfoQuery'},
        method: 'post',
        dataType: 'json',
        success: function(data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.data != null) {
            var list = data.data.data[0];
            var array = [];
            Date.prototype.Format = function(fmt) {
              var o = {
                "M+": this.getMonth() + 1, //月份   
                "d+": this.getDate(), //日
                "h+": this.getHours(), //小时   
                "m+": this.getMinutes(), //分   
                "s+": this.getSeconds(), //秒   
                "q+": Math.floor((this.getMonth() + 3) / 3), //季度   
                "S": this.getMilliseconds() //毫秒   
              };
              if (/(y+)/.test(fmt))
                fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
              for (var k in o)
                if (new RegExp("(" + k + ")").test(fmt))
                  fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
              return fmt;
            }
            for (var key in list) {
              if (key == 'apprdate') {
                key = '核准日期';
                list['核准日期'] = new Date(list['apprdate']).Format("yyyy-MM-dd");
              }
              if (key == 'dom') {
                key = '注册地址';
                list['注册地址'] = list['dom'];
              }
              if (key == 'entname') {
                key = '企业名称';
                list['企业名称'] = list['entname'];
              }
              if (key == 'enttypeCn') {
                key = '企业类型（中文）';
                list['企业类型（中文）'] = list['enttypeCn'];
              }
              if (key == 'estdate') {
                key = '成立日期';
                list['成立日期'] = new Date(list['estdate']).Format("yyyy-MM-dd");
              }
              if (key == 'name') {
                key = '法定代表人';
                list['法定代表人'] = list['name'];
              }
              if (key == 'opfrom') {
                key = '经营期限自';
                list['经营期限自'] = new Date(list['opfrom']).Format("yyyy-MM-dd");
              }
              if (key == 'opscope') {
                key = '经营范围';
                list['经营范围'] = list['opscope'] == null ? '' : list['opscope'];
              }
              if (key == 'opto') {
                key = '经营期限止';
                list['经营期限止'] = list['opto'] == 0 ? '无固定期限' : new Date(list['opto']).Format("yyyy-MM-dd");
              }
              if (key == 'regcap') {
                key = '注册资本（万元）';
                list['注册资本（万元）'] = list['regcap'];
              }
              if (key == 'regcapcurCn') {
                key = '注册资本币种（中文）';
                list['注册资本币种（中文）'] = list['regcapcurCn'] == null ? "" : list['regcapcurCn'];
              }
              if (key == 'regno') {
                key = '注册号';
                list['注册号'] = list['regno'];
              }
              if (key == 'regorgCn') {
                key = '登记机关（中文）';
                list['登记机关（中文）'] = list['regorgCn'];
              }
              if (key == 'regstateCn') {
                key = '登记状态（中文）';
                list['登记状态（中文）'] = list['regstateCn'];
              }
              if (key == 'uniscid') {
                key = '统一社会信用代码';
                list['统一社会信用代码'] = list['uniscid'];
              }
              if (key == 'sextNodenum') {
                key = '节点号';
                list['节点号'] = list['sextNodenum'] == undefined ? "暂无节点号" : list['sExtNodenum'];
              }
              array.push({
                'text': key,
                'type': list[key]
              }); //把得到的数据对象拆分成对象加到数组里面
            }
            var arr1 = data.data.data;
            console.log(arr1);
            _that.setData({
              show: false,
              listData: array,
            });
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入！',
              icon: 'none'
            });
            _that.setData({
              show: true,
            });
          }
        }
      }) //ajax end
      }
    } else {
      wx.showToast({
        title: '验证码输入有误！',
        icon: 'none'
      });
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})