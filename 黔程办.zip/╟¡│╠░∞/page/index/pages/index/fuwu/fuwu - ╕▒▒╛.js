// pages/index/card/gongjij.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    jiaotong: [
    ],
    wxId: '123456',
    user_name:''
  },
  getData() {
    //从全局变量里面获取地区
    this.setData({
      jiaotong: wx.getStorageSync("dy_subscription")
    });
  },
  dingyue: function(e) {
    var that = this;
    // 点击订阅，，传递ajax
    wx.request({
      url: getApp().globalData.url + 'userSubItem/add',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        uType: wx.getStorageSync("uType") ? wx.getStorageSync("uType"):0,
        addList: e.currentTarget.id, //订阅事项ID
        wxId: getApp().globalData.wxId
      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        if (data.data.code == 200) {
          console.log(data);
          wx.showToast({
            title: '订阅成功！',
            icon: 'none'
          });
          wx.request({
            url: getApp().globalData.url + 'userSubItem/getList',
            header: {
              'Content-Type': getApp().globalData.contentType
            },
            data: {
              uType: wx.getStorageSync("uType") ? wx.getStorageSync("uType") : 0,
              wxId: getApp().globalData.wxId
            }, //传微信id  unionId
            method: 'post',
            dataType: 'json',
            success: function (data) {
              console.log(data);
              if (data.data.code == 200) {
                // 计算第二个侧滑的宽度
                var dingyuges = 0;
                for (var d = 0; d < data.data.data.subInfo.length; d++) { //计算前九个有几个是没订阅的
                  if (data.data.data.subInfo[d].subscribed == true) {
                    dingyuges += 1;
                  }
                }
                console.log(dingyuges);
                var item_length = dingyuges - 9; //除了第一个盒子的9个
                var width_num = Math.ceil(item_length / 3) < 0 ? 0 : Math.ceil(item_length / 3); //第二个盒子的列数
                var jiu_num = 0;
                var jiu_num2 = 0;
                var new_array = [];
                for (var i = 0; i < 9; i++) { //计算前九个有几个是没订阅的
                  if (data.data.data.subInfo[i].subscribed == false) {
                    jiu_num += 1;
                  }
                }
                for (var i = 0; i < data.data.data.subInfo.length; i++) { //计算九个之后有几个是没订阅的
                  if (data.data.data.subInfo[i].subscribed == false) {
                    jiu_num2 += 1;
                  } else {
                    new_array.push(data.data.data.subInfo[i]);
                  }
                }
                var sub = jiu_num2 - jiu_num;
                that.setData({
                  jiaotong: data.data.data.subInfo,
                });
                wx.setStorageSync("dy_subscription", data.data.data.subInfo);
                wx.setStorageSync("dy_subscription2", new_array);
                wx.setStorageSync("dy_num", jiu_num + 9 + sub);
                wx.setStorageSync("dy_scroll_n2_width", width_num * 240 + 5 + 'rpx');
              }
            }
          }) //ajax end
        }
      }
    }) //ajax end
  },
  close_dy: function(e) {
    var that = this;
    // 取消订阅
    wx.request({
      url: getApp().globalData.url + 'userSubItem/del',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        uType: wx.getStorageSync("uType") ? wx.getStorageSync("uType") : 0,
        delList: e.currentTarget.id, //订阅事项ID
        wxId: getApp().globalData.wxId
      },
      method: 'post',
      dataType: 'json',
      success: function(data) {
        if (data.data.code == 200) {
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
          wx.request({
            url: getApp().globalData.url + 'userSubItem/getList',
            header: {
              'Content-Type': getApp().globalData.contentType
            },
            data: {
              uType: wx.getStorageSync("uType") ? wx.getStorageSync("uType") : 0,
              wxId: getApp().globalData.wxId
            }, //传微信id  unionId
            method: 'post',
            dataType: 'json',
            success: function (data) {
              console.log(data);
              if (data.data.code == 200) {
                // 计算第二个侧滑的宽度
                var dingyuges = 0;
                for (var d = 0; d < data.data.data.subInfo.length; d++) { //计算前九个有几个是没订阅的
                  if (data.data.data.subInfo[d].subscribed == true) {
                    dingyuges += 1;
                  }
                }
                console.log(dingyuges);
                var item_length = dingyuges - 9; //除了第一个盒子的9个
                var width_num = Math.ceil(item_length / 3) < 0 ? 0 : Math.ceil(item_length / 3); //第二个盒子的列数
                console.log(width_num);
                var jiu_num = 0;
                var jiu_num2 = 0;
                var new_array = [];
                for (var i = 0; i < 9; i++) { //计算前九个有几个是没订阅的
                  if (data.data.data.subInfo[i].subscribed == false) {
                    jiu_num += 1;
                  }
                }
                for (var i = 0; i < data.data.data.subInfo.length; i++) { //计算九个之后有几个是没订阅的
                  if (data.data.data.subInfo[i].subscribed == false) {
                    jiu_num2 += 1;
                  } else {
                    new_array.push(data.data.data.subInfo[i]);
                  }
                }
                var sub = jiu_num2 - jiu_num;
                that.setData({
                  jiaotong: data.data.data.subInfo,
                });
                wx.setStorageSync("dy_subscription", data.data.data.subInfo);
                wx.setStorageSync("dy_subscription2", new_array);
                wx.setStorageSync("dy_num", jiu_num + 9 + sub);
                wx.setStorageSync("dy_scroll_n2_width", width_num * 240 + 5 + 'rpx');
              }
            }
          }) //ajax end
        }
      }
    }) //ajax end
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this;
    if (wx.getStorageSync("wxId")!= '123456'){
      wx.request({
        url: getApp().globalData.url + 'userSubItem/getList',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          uType: wx.getStorageSync("uType") ? wx.getStorageSync("uType") : 0,
          wxId: getApp().globalData.wxId
        }, //传微信id  unionId
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data);
          if (data.data.code == 200) {
            var dingyuges = 0;
            for (var d = 0; d < data.data.data.subInfo.length; d++) { //计算前九个有几个是没订阅的
              if (data.data.data.subInfo[d].subscribed == true) {
                dingyuges += 1;
              }
            }
            console.log(dingyuges);
            var item_length = dingyuges - 9; //除了第一个盒子的9个
            var width_num = Math.ceil(item_length / 3) < 0 ? 0 : Math.ceil(item_length / 3); //第二个盒子的列数
            var jiu_num = 0;
            var jiu_num2 = 0;
            var new_array = [];
            for (var i = 0; i < 9; i++) { //计算前九个有几个是没订阅的
              if (data.data.data.subInfo[i].subscribed == false) {
                jiu_num += 1;
              }
            }
            for (var i = 0; i < data.data.data.subInfo.length; i++) { //计算九个之后有几个是没订阅的
              if (data.data.data.subInfo[i].subscribed == false) {
                jiu_num2 += 1;
              } else {
                new_array.push(data.data.data.subInfo[i]);
              }
            }
            var sub = jiu_num2 - jiu_num;
            that.setData({
              jiaotong: data.data.data.subInfo,
            });
            wx.setStorageSync("dy_subscription", data.data.data.subInfo);
            wx.setStorageSync("dy_subscription2", new_array);
            wx.setStorageSync("dy_num", jiu_num + 9 + sub);
            wx.setStorageSync("dy_scroll_n2_width", width_num * 240 + 5 + 'rpx');
          }
        }
      }) //ajax end
    }else{
      that.getData();
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.setData({
      user_name: wx.getStorageSync("user_name")
    })
    if (this.data.user_name == '' || this.data.user_name == null) {
      wx.showModal({
        title: '登录',
        content: '登录后可个性化订阅服务，去登录?',
        success: function (res) {
          if (res.confirm) {
            wx.navigateTo({
              url: '/page/home/pages/home/login/login_select',
            })
          } else if (res.cancel) {
            wx.navigateBack({ changed: true });
          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})