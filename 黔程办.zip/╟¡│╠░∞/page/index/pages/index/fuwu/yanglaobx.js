// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    msg: "养老保险",
    code: 'R5DV',
    user_code: 'R5DV',
    result: '',
    show: true,
    listData: [],
    idCard: '',
    user_name: '',
    addrNo:'',
    showmode: {
      show: false,
      phone: '',
    },
    id: 0,
  },
  input_str: function(e) {
    this.setData({
      idCard: e.detail.value
    })
  },
  changeCode: function() {
    var chang_code = '';
    var codeLength = 4;
    var random = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
      'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'); //随机数
    for (var i = 0; i < codeLength; i++) {
      var charIndex = Math.floor(Math.random() * 36); //取得随机数的索引
      chang_code += random[charIndex];
    }
    this.setData({
      code: chang_code
    })
  },
  user_code: function(e) {
    this.setData({
      user_code: e.detail.value
    })
  },
  formSubmit: function(e) {
    var _that = this;
    if (this.data.user_code.toUpperCase() == this.data.code) {
      // 验证码输入正确时的操作
      console.log('form发生了submit事件，携带数据为：', e.detail.value);
      var obj_s2 = JSON.stringify(e.detail.value);
      // ，传递ajax 数据{idCard: "522129195510165011", sb_name: "", addrNo: "520500"}
      if (this.data.idCard == '') {
        wx.showToast({
          title: '请输入身份证号！',
          icon: 'none'
        });
      } else {
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          // data: e.detail.value,
          data: {
            'param': obj_s2,
            'url': 'http://202.98.195.208:83/apiroute/yljFind'
          },
          method: 'post',
          dataType: 'json',
          success: function(data) {
            console.log(data);
            if (data.data.body.code == '1') {
              if (data.data.body.output.recordcount == 1) {
                var list = data.data.body.output.resultset.row;
                delete list.aac060;
                var array = [];
                for (var key in list) {
                  if (key == 'rn') {
                    key = '序号';
                    list['序号'] = list['rn'];
                  }
                  if (key == 'aac001') {
                    key = '社保个人编号';
                    list['社保个人编号'] = list['aac001'];
                  }
                  if (key == 'aac002') {
                    key = '身份证号码';
                    list['身份证号码'] = list['aac002'];
                  }
                  if (key == 'aac003') {
                    key = '姓名';
                    list['姓名'] = list['aac003'];
                  }
                  if (key == 'aac004') {
                    key = '性别';
                    list['性别'] = list['aac004'];
                  }
                  if (key == 'aac006') {
                    key = '出生日期';
                    list['出生日期'] = list['aac006'];
                  }
                  if (key == 'aac007') {
                    key = '参加工作时间';
                    list['参加工作时间'] = list['aac007'];
                  }
                  if (key == 'aac008') {
                    key = '人员状态';
                    list['人员状态'] = list['aac008'];
                  }
                  if (list['aac008'] == 1) {
                    list['aac008'] = "在职";
                  } else {
                    list['aac008'] = "退休";
                  }
                  if (key == 'aac009') {
                    key = '户口性质';
                    list['户口性质'] = list['aac009'];
                  }
                  if (list['aac009'] == 1) {
                    list['aac009'] = '城镇（非农业户口）';
                  } else {
                    list['aac009'] = '农村（农业户口）';
                  }
                  if (key == 'aac010') {
                    key = '生存状态';
                    list['生存状态'] = list['aac010'];
                  }
                  if (key == 'aac017') {
                    key = '婚姻状况';
                    list['婚姻状况'] = list['aac017'];
                  }
                  if (key == 'aac030') {
                    key = '参保日期';
                    list['参保日期'] = list['aac030'];
                  }
                  if (key == 'aac049') {
                    key = '参保登记日期';
                    list['参保登记日期'] = list['aac049'];
                  }
                  if (key == 'aac031') {
                    key = '缴费状态';
                    list['缴费状态'] = list['aac031'];
                  }
                  if (list['aac031'] == 0) {
                    list['aac031'] = "未参保";
                  } else if (list['aac031'] == 1) {
                    list['aac031'] = "参保缴费"
                  } else if (list['aac031'] == 2) {
                    list['aac031'] = "暂停缴费"
                  } else {
                    list['aac031'] = "终止参保"
                  }
                  if (key == 'aac084') {
                    key = '到龄享受待遇标志';
                    list['到龄享受待遇标志'] = list['aac084'];
                  }
                  if (list['aac084'] == 0) {
                    list['aac084'] = '否';
                  } else {
                    list['aac084'] = '是'
                  }
                  if (key == 'aae004') {
                    key = '联系人姓名';
                    list['联系人姓名'] = list['aae004'];
                  }
                  if (key == 'aae005') {
                    key = '联系电话';
                    list['联系电话'] = list['aae005'];
                  }
                  if (key == 'aae006') {
                    key = '地址';
                    list['地址'] = list['aae006'];
                  }
                  if (key == 'aae007') {
                    key = '邮编';
                    list['邮编'] = list['aae007'];
                  }
                  if (key == 'aae019') {
                    key = '月待遇金额';
                    list['月待遇金额'] = list['aae019'] + "元";
                  }
                  if (key == 'aae030') {
                    key = '缴费起始日期';
                    list['缴费起始日期'] = list['aae030'];
                  }
                  if (key == 'aae116') {
                    key = '待遇状态';
                    list['待遇状态'] = list['aae116'];
                  }
                  if (key == 'aac118') {
                    key = '被征地农民社会保险参保标志';
                    list['被征地农民社会保险参保标志'] = list['aac118'];
                  }
                  if (list['aac118'] == 0) {
                    list['aac118'] = '否';
                  } else {
                    list['aac118'] = '是'
                  }
                  if (key == 'aae140') {
                    key = '险种类型';
                    list['险种类型'] = list['aae140'];
                  }
                  if (key == 'aae159') {
                    key = '联系人邮箱';
                    list['联系人邮箱'] = list['aae159'];
                  }
                  if (key == 'aae202') {
                    key = '个人缴费年限';
                    list['个人缴费年限'] = list['aae202'] + "年";
                  }
                  if (key == 'aae240') {
                    key = '个人账户余额';
                    list['个人账户余额'] = list['aae240'] + "元";
                  }
                  if (key == 'aab004') {
                    key = '单位名称';
                    list['单位名称'] = list['aab004'];
                  }
                  if (key == 'aab019') {
                    key = '单位类型';
                    list['单位类型'] = list['aab019'];
                  }
                  if (key == 'aab033') {
                    key = '征收方式';
                    list['征收方式'] = list['aab033'];
                  }
                  if (list['aab033'] == 1) {
                    list['aab033'] = '银行处理';
                  } else {
                    list['aab033'] = '经办机构自收';
                  }
                  if (key == 'aab301') {
                    key = '参保所在地';
                    list['参保所在地'] = list['aab301'];
                  }
                  if (key == 'aab401') {
                    key = '户口本编号';
                    list['户口本编号'] = list['aab401'];
                  }
                  if (key == 'aaz289') {
                    key = '缴费档次';
                    list['缴费档次'] = list['aaz289'];
                  }
                  if (list[key] == '') {
                    list[key] = '--';
                  }
                  array.push({
                    'text': key,
                    'type': list[key]
                  }); //把得到的数据对象拆分成对象加到数组里面
                }
                _that.setData({
                  show: false,
                  listData: array,
                });
              } else {
                wx.showToast({
                  title: '没有查到数据，请检查输入或是否开通此业务！',
                  icon: 'none'
                });
                _that.setData({
                  show: true,
                });
              }
            } else {
              console.log(data);
              wx.showToast({
                title: '政务系统繁忙！',
                icon: 'none'
              });
            }
          }
        }) //ajax end
      }
    } else {
      wx.showToast({
        title: '验证码输入有误！',
        icon: 'none'
      });
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },
  cencel_login: function() {
    wx.switchTab({
      url: '/page/tabBar/index/index',
    })
  },
  to_login: function() {
    wx.navigateTo({
      url: '/page/home/pages/home/login/login_select',
    })
    this.setData({
      showmode: {
        show: false,
        phone: wx.getStorageSync("phone")
      }
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.setData({
      idCard: wx.getStorageSync("idCardNumber"),
      user_name: wx.getStorageSync("user_name"),
      addrNo: wx.getStorageSync("shi_list")[wx.getStorageSync("shi_index")].AREAID,
    })
    if (this.data.user_name == '' || this.data.user_name == null) {
      this.setData({
        showmode: {
          show: true,
          phone: wx.getStorageSync("phone")
        }
      })
      // wx.showModal({
      //   title: '登录',
      //   content: '该查询只支持登录用户查询，前往登录?',
      //   success: function (res) {
      //     if (res.confirm) {
      //       wx.navigateTo({
      //         url: '/page/home/pages/home/login/login_select',
      //       })
      //     } else if (res.cancel) {
      //       wx.navigateBack({ changed: true });
      //     }
      //   }
      // })
    }
  },

  getPhoneNumber: function(e) { //点击获取手机号码按钮
    var that = this;
    wx.login({
      success: data => {
        console.log(data)
        console.log(e.detail.iv)
        console.log(e.detail.encryptedData)
        var ency = e.detail.encryptedData;
        var iv = e.detail.iv;
        if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
          // 用户取消了获取手机号
        } else { //同意授权
          wx.request({
            method: "POST",
            // url: 'https://face.fotoit.cn:84/UrbanService/user/decodeUserInfo',  //这个解密地址能用
            url: getApp().globalData.url + 'user/decodeUserInfo',
            data: {
              code: data.code,
              encryptedData: e.detail.encryptedData,
              iv: iv,
            },
            header: {
              'content-type': getApp().globalData.contentType,
            },
            success: (res) => {
              console.log(res);
              if (res.data.code == 200) { //code好像只有线上的可以，发布之后如果获取手机号成功会返回200，，跳转选择登陆
                if (res.data.data.phoneNumber) {
                  getApp().savewxinfo(res.data.data.phoneNumber);
                  var phone = res.data.data.phoneNumber.toString();
                  wx.setStorageSync("phone", phone);
                  that.setData({
                    showmode: {
                      show: false,
                      phone: phone,
                    }
                  })
                  wx.navigateTo({
                    url: '/page/home/pages/home/login/login_select',
                  })
                  // wx.showToast({
                  //   title: "解密成功" + phone,
                  //   icon: 'none'
                  // });
                } else {
                  wx.showToast({
                    title: "解密失败",
                    icon: 'none'
                  });
                  that.setData({
                    showmode: {
                      show: false,
                      phone: '',
                    }
                  })
                }
              }
            },
            fail: function(res) {
              console.log("解密失败~~~~~~~~~~~~~");
              console.log(res);
              wx.showToast({
                title: '获取手机号失败，请检查网络！',
                icon: 'none'
              });
            }
          });
        }
      }
    })

  }
})