// pages/index/fuwu/shebcx.js
var app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    idCard: '',
    array: ['贵阳', '六盘水', '遵义', '黔南', '黔西南', '黔东南','安顺','铜仁','贵安新区' ],
    array1: ['520100', '520200', '520300', '522700', '522300', '522600', '520400','520600','520555'],
    index: 0,
    show:true,
    obj: {},
    obj2:{},
    xb:'',
    showmode: {
      show: false,
      phone: '',
    },
    id: 0,
  },
  cencel_login: function () {
    wx.switchTab({
      url: '/page/tabBar/index/index',
    })
  },
  to_login: function () {
    wx.navigateTo({
      url: '/page/home/pages/home/login/login_select',
    })
    this.setData({
      showmode: {
        show: false,
        phone: wx.getStorageSync("phone")
      }
    });
  },
  bindPickerChange: function (e) {
    this.setData({
      index: e.detail.value, 
      show: true,
    })
  },
  input_str: function (e) { this.setData({ name: e.detail.value }) },
  input_str2: function (e) { this.setData({ idCard: e.detail.value }) },
  formSubmit: function (e) {
    // 验证码输入正确时的操作
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    var that = this;
    if (that.data.name == '') {
      wx.showToast({ title: '请输入用户名', icon: 'none' });
    } else if (that.data.idCard == '') {
      wx.showToast({ title: '请输入身份证号', icon: 'none' });
    } else {
      wx.showLoading({
        title: '查询中',
      });
      var obj_s2 = JSON.stringify(e.detail.value);
      // var obj_s2 = JSON.stringify({ "citybm": "C52270LS", "xingming": "陈莉", "zjhm": "522701196101070020" });
      // 请求数据    卢波    522324196607070055 C52230LX
      if (e.detail.value.citybm == '520000'){
        // 王铁   520102196310201236
        console.log('选择省级');
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: { 'param': JSON.stringify({
            name:that.data.name,
            idCard: that.data.idCard
          }), 'url': getApp().globalData.sousuo_url +'/queryFund' },//实际调用接口
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.data.list.length != 0) {
              that.setData({
                show: false,
                obj: data.data.data.list[0],
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否有办理业务！',
                icon: 'none'
              });
              that.setData({
                show: true,
              })
            }
          }
        }) //ajax end
      } else if (e.detail.value.citybm == '520200') {
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              'data': {
                "head": {
					            "appid": "95",
					            "transcode": "200020101",
					            "trantime": "20110710150312",
					            "iseqno": "201107101503120011"
					        },
					        "body": {
					            "head": {
                        // "zjhm": '520202198007035110'
                        "zjhm": that.data.idCard
					            },
					            "list": ""
					        }
              }
            }), 'url': getApp().globalData.sousuo_url + '/postJson',
            'headers': JSON.stringify({
              "apiCode": "177W1396",
              "netType": "1"
            })
          },//实际调用接口
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.result.body.list.acc_info) {
              that.setData({
                show: false,
                obj: data.data.result.body.list.acc_info[0]
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否有办理业务！',
                icon: 'none'
              });
            }
          }
        }) //ajax end
      } else if (e.detail.value.citybm == '520300') {
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              'data': {
                "certinum": that.data.idCard
                // "certinum": "522101195901182015",
              }
            }), 'url': getApp().globalData.sousuo_url + '/postJson',
            'headers': JSON.stringify({
              "apiCode": "100W1345",
              "netType": "1"
            })
          },//实际调用接口
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.result.data) {
              that.setData({
                show: false,
                obj: data.data.result.data
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否有办理业务！',
                icon: 'none'
              });
            }
          }
        }) //ajax end
        } else if (e.detail.value.citybm == '520100'){
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              data:{"appid": "f57a9d7e81c84839873fed3541c41a8a",
              "apiu": "GYSGJJZXGYSZFGJJGLXXXT/GYSGJJZXGYSZFGJJGLXXXTZGJBXX",
              "paramMap": {
                "trantime": "20170111101010",
                "spidno": e.detail.value.zjhm
              },
              "apikey": "eb7669c72516fb9a558b6c26d49891d6"}
            }), 'url': getApp().globalData.sousuo_url + '/postJson',
            'headers': JSON.stringify({ 'apiCode': '100W1374', 'netType': '1' })
          },//实际调用接口
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.result.body) {
              that.setData({
                show: false,
                obj: data.data.result.body.detail,
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否有办理业务！',
                icon: 'none'
              });
              that.setData({
                show: true,
              })
            }
          }
        }) //ajax end
      } else if (e.detail.value.citybm == '522600') {
        // 522634196702050019   黔东南
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              'data': {
                "ffbm": "01",
                "zxbm": "01",
                "jgbm": "01",
                "ywfl": "01",
                "ywlb": "99",
                "khbh": "",
                "zhbh": "",
                "blqd": "zxb",
                "userid": 1,
                "pageIndex": 1,
                "pageSize": 1000,
                "value1": e.detail.value.zjhm
                // "value1": "522634196702050019",
              }
            }), 'url': getApp().globalData.sousuo_url + '/postJson',
            'headers': JSON.stringify({ 'apiCode': '100W1362', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52260" }) })
          },//实际调用接口
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.result.data.length > 0) {
              that.setData({
                show: false,
                obj: data.data.result.data[0]
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否有办理业务！',
                icon: 'none'
              });
              that.setData({
                show: true,
              })
            }
          }
        }) //ajax end
      }else if (e.detail.value.citybm == '522700') {
        // 522728198704236332   黔南
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              'data': {
                "ffbm": "01",
                "ffbm": "01",
                "zxbm": "01",
                "jgbm": "01",
                "ywfl": "01",
                "ywlb": "99",
                "khbh": "",
                "zhbh": "",
                "blqd": "zxb",
                "userid": 1,
                "pageIndex": 1,
                "pageSize": 100,
                "value1": e.detail.value.zjhm,
                // "value1": "522728198704236332",
              }
            }), 'url': getApp().globalData.sousuo_url + '/postJson',
            'headers': JSON.stringify({ 'apiCode': '100W1325', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52270" }) })
          },//实际调用接口
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.result.data.length > 0) {
              that.setData({
                show: false,
                obj: data.data.result.data[0]
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否有办理业务！',
                icon: 'none'
              });
              that.setData({
                show: true,
              })
            }
          }
        }) //ajax end
      } else if (e.detail.value.citybm == '522300') {
        // 522321199309211299   黔西南
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              'data': {
                "ffbm": "01",
                "zxbm": "01",
                "jgbm": "01",
                "ywfl": "01",
                "ywlb": "99",
                "khbh": "",
                "zhbh": "",
                "blqd": "zxb",
                "userid": 1,
                "pageIndex": 1,
                "pageSize": 100,
                "value1": e.detail.value.zjhm,
                // "value1": "522321199309211299",
              }
            }), 'url': getApp().globalData.sousuo_url + '/postJson',
            'headers': JSON.stringify({ 'apiCode': '100W1221', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52230" }) })
          },//实际调用接口
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.result.data.length > 0) {
              that.setData({
                show: false,
                obj: data.data.result.data[0]
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否有办理业务！',
                icon: 'none'
              });
              that.setData({
                show: true,
              })
            }
          }
        }) //ajax end
      } else if (e.detail.value.citybm == '520400'){
        // 陈茂森   522426197610202031
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              authName: that.data.name,
              authCardNo: that.data.idCard
            }), 'url': getApp().globalData.sousuo_url + '/anshunPersonalGjj'
          },//实际调用接口
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.data.name) {
              that.setData({
                show: false,
                obj: data.data.data
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否有办理业务！',
                icon: 'none'
              });
              that.setData({
                show: true,
              })
            }
          }
        }) //ajax end
      } else if (e.detail.value.citybm == '520600') {//铜仁公积金
        //  522226198403234018
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              'data': {
                "ffbm": "01",
                "zxbm": "01", "jgbm": "01", "ywfl": "01", "ywlb": "99", "khbh": "", "zhbh": "", "blqd": "zxb", "userid": 1, "pageIndex": 1, "pageSize": 10,
                "value1": that.data.idCard,
                // "value1": "522226198403234018",
              }
            }), 'url': getApp().globalData.sousuo_url +'/postJson',
            'headers': JSON.stringify({ 'apiCode': '100W1211', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52220" }) })
          },//实际调用接口
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.head.code==200&&data.data.result.data.length>0) {
              that.setData({
                show: false,
                obj: data.data.result.data[0]
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否有办理业务！',
                icon: 'none'
              });
              that.setData({
                show: true,
              })
            }
          }
        }) //ajax end
      }else if (e.detail.value.citybm == '520555'){
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              data: {
                extParam: {
                }
              }
            }),
            'headers': JSON.stringify({
              'apiCode': '100W1365',
              'netType': '1'
            }),
            'url': getApp().globalData.sousuo_url + '/postJson'
          },//实际调用接口
          method: 'post',
          dataType: 'json',
          success: function (data) {
            console.log(data)
            if (data.data.result.code == 200) {
              var body=data.data.result.data;
              wx.request({
              url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
                header: {
                'Content-Type': getApp().globalData.contentType
              },
              data: {
                'param': JSON.stringify({
                  'data':{
                    "extParam": {
                      "dwzh": "",
                      "page": 1,
                      "currentPage": 1,
                      "grzh": "",
                      "xingming": "",
                      "zjhm": that.data.idCard,
                      // "zjhm": "522527200006260055",
                      "grzhzt": ""
                    },
                    "qqly": 20
                  }
                }),
                  'headers': JSON.stringify({
                    "apiCode": "100W1144",
                    "netType": "1", "ispToken": body
                  }),
                    'url': getApp().globalData.sousuo_url + '/postJson'
              },//实际调用接口
              method: 'post',
                dataType: 'json',
                  success: function (data) {
                    wx.hideLoading();
                    console.log(data);
                    if (!data.data.result.success){
                      wx.showToast({
                        title: 'token失效！',
                        icon: 'none'
                      });
                      return;
                    }
                    if (data.data.code == 500) {
                      wx.showToast({
                        title: '请求异常，请稍后重试！',
                        icon: 'none'
                      });
                      return;
                    }
                    if (data.data.head.code == 200 && data.data.result.list.length > 0) {
                      that.setData({
                        show: false,
                        obj: data.data.result.list[0]
                      })
                      var dwzh = that.data.obj.dwzh, grzh = that.data.obj.grzh;
                      wx.request({
                        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
                        header: {
                          'Content-Type': getApp().globalData.contentType
                        },
                        data: {
                          'param': JSON.stringify({
                            'data': {
                              "extParam": {
                                "dwzh": "",
                                "grzh": grzh,
                                "page": 1,
                                "currentPage": 1
                              },
                              "qqly": 20
                            }
                          }),
                          'headers': JSON.stringify({
                            "apiCode": "100W1145",
                            "netType": 1, "ispToken": body
                          }),
                          'url': getApp().globalData.sousuo_url + '/postJson'
                        },//实际调用接口
                        method: 'post',
                        dataType: 'json',
                        success: function (data) {
                          console.log(data);
                          if (data.data.result.success) {
                            that.setData({
                              obj2: JSON.parse(data.data.result.body).list[0]
                            })
                          }
                        }
                      }) //ajax end
                    } else {
                      wx.showToast({
                        title: '没有查到数据，请检查输入或是否有办理业务！',
                        icon: 'none'
                      });
                      that.setData({
                        show: true,
                      })
                    }
                  }
            }) //ajax end
            } else {
              wx.showToast({
                title: '获取token失败！',
                icon: 'none'
              });
            }
          }
        })
        }else{
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: { 'param': obj_s2, 'url': getApp().globalData.sousuo_url +'/publicAccumulationFundsQuery' },//实际调用接口
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.data != null) {
              that.setData({
                show: false,
                obj: data.data.data
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否有办理业务！',
                icon: 'none'
              });
              that.setData({
                show: true,
              })
            }
          }
        }) //ajax end
      }
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  // get_body:function(){
  //   var that = this;
    
  // },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      name: wx.getStorageSync("user_name") ? wx.getStorageSync("user_name") : wx.getStorageSync("login_name"),
      idCard: wx.getStorageSync("idCardNumber"),
    })
    if (wx.getStorageSync("user_name") == '' || wx.getStorageSync("user_name") == null) {
      this.setData({
        showmode: {
          show: true,
          phone: wx.getStorageSync("phone")
        }
      })
    }
  },

  getPhoneNumber: function (e) { //点击获取手机号码按钮
    var that = this;
    wx.login({
      success: data => {
        console.log(data)
        console.log(e.detail.iv)
        console.log(e.detail.encryptedData)
        var ency = e.detail.encryptedData;
        var iv = e.detail.iv;
        if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
          // 用户取消了获取手机号
        } else { //同意授权
          wx.request({
            method: "POST",
            // url: 'https://face.fotoit.cn:84/UrbanService/user/decodeUserInfo',  //这个解密地址能用
            url: getApp().globalData.url + 'user/decodeUserInfo',
            data: {
              code: data.code,
              encryptedData: e.detail.encryptedData,
              iv: iv,
            },
            header: {
              'content-type': getApp().globalData.contentType,
            },
            success: (res) => {
              console.log(res);
              if (res.data.code == 200) { //code好像只有线上的可以，发布之后如果获取手机号成功会返回200，，跳转选择登陆
                if (res.data.data.phoneNumber) {
                  getApp().savewxinfo(res.data.data.phoneNumber);
                  var phone = res.data.data.phoneNumber.toString();
                  wx.setStorageSync("phone", phone);
                  that.setData({
                    showmode: {
                      show: false,
                      phone: phone,
                    }
                  })
                  wx.navigateTo({
                    url: '/page/home/pages/home/login/login_select',
                  })
                  // wx.showToast({
                  //   title: "解密成功" + phone,
                  //   icon: 'none'
                  // });
                } else {
                  wx.showToast({
                    title: "解密失败",
                    icon: 'none'
                  });
                  that.setData({
                    showmode: {
                      show: false,
                      phone: '',
                    }
                  })
                }
              }
            },
            fail: function (res) {
              console.log("解密失败~~~~~~~~~~~~~");
              console.log(res);
              wx.showToast({
                title: '获取手机号失败，请检查网络！',
                icon: 'none'
              });
            }
          });
        }
      }
    })

  },
})