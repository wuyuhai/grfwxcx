// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    idno: '',
    regionName: '',
    show:true,
    obj:{}
  },
  input_str: function (e) {
    this.setData({
      idno: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    // ，传递ajax 522628200002110027
    if (this.data.idno == '') {
      wx.showToast({
        title: '请输入身份证号！',
        icon: 'none'
      });
    } else {
      var obj_s2 = JSON.stringify(e.detail.value);
      wx.showLoading({ title: '查询中', });
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: { 'param': obj_s2, 'url': getApp().globalData.sousuo_url + '/getStudent' },//实际调用接口
        // 522628200002110027
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.code==401){
            wx.showToast({
              title: '没有查询到该学生信息！',
              icon: 'none'
            });
            _that.setData({
              show: true,
            })
            return;
          }
          if (data.data.data.idno){
            _that.setData({
              show:false,
              obj: data.data.data
            })
          }else{
            wx.showToast({
              title: '没有查询到数据！',
              icon: 'none'
            });
          }
        },
        fail:function(){
          wx.hideLoading();
          wx.showToast({
            title: '网络链接失败，请稍后重试！',
            icon: 'none'
          });
        }
      }) //ajax end
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    that.setData({
      idno: wx.getStorageSync('idCardNumber')
    })
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})