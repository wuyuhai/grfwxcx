// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:'',
    name:'',
    regionName:'',
    show:true,
    obj:{}
  },
  input_str: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
   input_str2: function (e) {
    this.setData({
      id: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    // ，传递ajax 道市监行处字[2016]118号
    if (this.data.name == '') {
      wx.showToast({
        title: '请输入姓名！',
        icon: 'none'
      });
    }else if(this.data.id == ''){
      wx.showToast({
        title: '请输入身份证号！',
        icon: 'none'
      });
    } else {
      wx.showLoading({
        title: '查询中',
      });
      //陈钰文  520102198710163434
      var oooop = JSON.stringify({'data':{
              id: _that.data.id,
              name: _that.data.name,
              platKey: 'gwEpelawA4NiVzr9afsM',
              platToken: 'osrZ2MpnjzTPzlvAH8Jh'
      }
      });
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            data: JSON.stringify({
              'id': _that.data.id,
              'name': _that.data.name,
              'platKey': 'gwEpelawA4NiVzr9afsM',
              'platToken': 'osrZ2MpnjzTPzlvAH8Jh'
            })
          }),
          'headers': JSON.stringify({
            'apiCode': '105W1097',
            'netType': '1'
          }),
          'url': getApp().globalData.sousuo_url + '/postJson'
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.head.code == 200 && data.data.result.data.length >0){
              _that.setData({
              show:false,
              obj: data.data.result.data
            })
          }else{
            wx.showToast({ title: '没有查询到相应的婚姻登记信息!',icon: 'none'});
            _that.setData({
              show: true,
            })
          }
        },
        fail:function(){
          wx.showToast({
            title: '网络链接失败，请稍后重试！',
            icon: 'none'
          });
        }
      }) //ajax end
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.setData({
      id: wx.getStorageSync("idCardNumber"),
      user_name: wx.getStorageSync("user_name"),
      name: wx.getStorageSync("user_name"),
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})