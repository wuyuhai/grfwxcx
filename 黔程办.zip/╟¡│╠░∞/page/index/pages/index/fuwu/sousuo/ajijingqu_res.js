// pages/index/fuwu/shebcx.js
var page = 1;
var is_next = true;
var change = false;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:{},
    show:true,
    arr:[],
    show: true,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    page = 1;
    is_next = true;
    options.str2 = options.str2 == '全部' ? '' : options.str2;
    this.setData({
      data:{
        searchKey: options.str1,
        level: options.str2,
        page:1,
        size:11
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (num1) {
    if (num1 == undefined) {
      num1 = 1;
    }
    var _this = this;
    wx.showLoading({
      title: '加载中',
    });
    var obj_s2 = JSON.stringify({
      searchKey: _this.data.data.searchKey,
      level: _this.data.data.level,
      page: num1,
      size: 11,
    });
    wx.request({
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: {
        'param': obj_s2,
        'url': getApp().globalData.sousuo_url + '/scenicSpotQuery'
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
    // wx.request({
    //   header: {
    //     'Content-Type': getApp().globalData.contentType
    //   },
    //   url:'https://zwzx.anshun.gov.cn:84/zhengwuji/postForJsonRoute',
    //   data: {
    //     'url': getApp().globalData.sousuo_url + '/scenicSpotQuery',
    //     'data': obj_s2
    //   },
      // success: function (data) {
        console.log(data);
        wx.hideLoading();
        var obj = data.data.data.list;
        if (num1 == 1 && obj == null) {//如果是第一页没有数据就显示无数据，，第二页以后的显示之前的数据
          _this.setData({
            show: false,
          })
          return;
        }
        if (obj == null) {
          wx.showToast({
            title: '没有更多数据了！',
            icon: 'none'
          });
          return;
        } else {
          if(num1!=1){
            var array = _this.data.arr;
            for (var i = 0; i < obj.length; i++) {
              array.push(obj[i]);
            }
            _this.setData({ arr: array });
          } else {
            _this.setData({
              show: true,
              arr: obj
            })
          }
        }
        if (obj.length < 11) {
          is_next = false;
          return;
        }
      }
    }) //ajax end
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (is_next) {
      page += 1;
      this.onShow(page);
      console.log(page)
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})