// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    OrgId:'',
    show:true,
    obj:{}
  },
  input_str2: function (e) {
    this.setData({
      OrgId: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
    if (this.data.OrgId == '') {
      wx.showToast({
        title: '请输入出生医学证编号！',
        icon: 'none'
      });
    } else {
      wx.showLoading({ title: '查询中', });//  P520338231
      wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              data: {
                "code": _that.data.OrgId
              }
            }),
            'headers': JSON.stringify({
              'apiCode': '100W1266',
              'netType':'1'
            }),
            'url': getApp().globalData.sousuo_url + '/postJson'
          },//实际调用接口   P520338231
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.code == 500) {
              wx.showToast({
                title: '网络链接失败，请稍后重试！',
                icon: 'none'
              });
              return;
            }
            if (data.data.head.code == 200 && data.data.result.length>0) {
              var bbbb = JSON.stringify(data.data.result[0]).replace(/}/gi, '').replace(/{/gi, '').replace(/"/gi, '').split(',');
              // for (let i in data.data.result[0]){
              //   arr.push(data.data.result[0][i])
              // }
              _that.setData({
                show: false,
                obj: bbbb
              })
            } else {
              wx.showToast({
                title: '没有查询到数据！',
                icon: 'none'
              });
              _that.setData({
                show: true,
              })
            }
          },
          fail: function () {
            wx.hideLoading();
            _that.setData({
              show: true,
            })
            wx.showToast({
              title: '网络链接失败，请稍后重试！',
              icon: 'none'
            });
          }
        }) //ajax end
      
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})