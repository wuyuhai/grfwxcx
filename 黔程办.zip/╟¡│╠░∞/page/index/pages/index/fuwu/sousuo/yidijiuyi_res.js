// pages/index/fuwu/shebcx.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:'',
    show:true
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var data = options.data;
    this.setData({
      data: {
        regionName: '医院',
        medical: '北京',
        startRow: 1,
        endRow:11,
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var _this = this;
    var obj_s2 = JSON.stringify({
      regionName: '医院',
      medical: '北京',
      startRow: '1',
      endRow:'11'
    });
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: { 'param': obj_s2, 'url': 'http://202.98.195.208:83/IntegratedQuery/medicalQuery' },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
      }
    }) //ajax end
    // wx.request({
    //   url: getApp().globalData.url + 'requestDelegate/handle',
    //   header: {
    //     'Content-Type': getApp().globalData.contentType
    //   },
    //   data: { 'param': _this.data.data, 'url': 'http://202.98.195.208:83/IntegratedQuery/medicalQuery' },
    //   method: 'post',
    //   dataType: 'json',
    //   success: function (data) {
    //     console.log(data);
    //   }
    // }) //ajax end
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})