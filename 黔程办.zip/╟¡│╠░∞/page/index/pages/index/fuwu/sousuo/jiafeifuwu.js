// pages/public/no_open.js
// var WxParse = require('../../../../wxParse/wxParse.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    title: '德国的风格大概v不错从规划法规刚好错过',
    obj1: '<view class="p">安防监控事发现场v 收到了罚款坚实的</view>',
    time: '2018-07-07',
    number:'3264465461',
    come_add:'546',
    keyword:'--',
    nodes: [{
      name: 'div',
      attrs: {
        class: 'div_class',
        style: 'line-height: 60px; color: red;'
      },
      children: [{
        type: 'text',
        text: 'Hello&nbsp;World!'
      }]
    }],
    Html: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.request({
      url: getApp().globalData.url + 'news/getInfo',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        contentId: options.CONTENT_ID
      }, //传微信id  unionId
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        var str = data.data.data.TXT;
        var str2 = str.replace(/\<img/gi, '<div style="margin-top:8px;"></div><img style="max-width:100%;width:100%;height:auto;display:line-block;margin:20rpx 0;padding:20rpx 0;" ');
        var str3 = str2.replace(/\<span/gi, '<span class="span" style="font-size:32rpx;color:#312520;text-indent:2em;padding-bottom:52rpx;"');
        var str4 = str3.replace(/&ldquo/gi, '');
        var str5 = str4.replace(/&rdquo/gi, '');
        var str6 = str5.replace(/&lsquo/gi, '');
        var str7 = str6.replace(/&middot/gi, '');
        var str8 = str7.replace(/&hellip/gi, '');
        var str9 = str8.replace(/\<table/gi, '<table style="display:block;max-width:100%;font-size:32rpx;" ');
        var str10 = str9.replace(/\<td/gi, '<td style="font-size:32rpx;border:1px solid #eee;" ');
        var str11 = str10.replace(/&mdash/gi, '');
        var str12 = str11.replace(/&rarr/gi, '');
        var str13 = str12.replace(/\<h1/gi, '<h1 style="font-size:35rpx;" ');
        var str14 = str13.replace(/&rsquo/gi, '');
        var str15 = str14.replace(/&bull/gi, '');
        var str16 = str15.replace(/\<p/gi, '<p style="display: block;text-align:left;font-size:32rpx;color:#312520;text-indent:2em;margin-bottom:52rpx;"');
        var str17 = str16.replace(/\<div/gi, '<div style="max-width:100%;width:100%;margin:0 auto;"');
        var str18 = str17.replace(/\p>/gi, 'p> <div style="margin-top:10px;"></div>');
        var str19 = str18.replace(/\<h2/gi, '<h2 class="h2" style="font-size:32rpx !important;text-indent:2em;text-align: left;"');
        var str20 = str19.replace(/\>  /gi, '>');
        var oop = JSON.stringify(that.data.obj1);
        if (data.data.code == 200) {
          console.log(str);
          that.setData({
            title: data.data.data.TITLE,
            time: data.data.data.RELEASE_DATE,
            Html: str20,
          })
        }
      }
    }) //ajax end
    //3秒返回
    // setTimeout(function () {
    //   wx.navigateBack();  //返回上一个页面
    // }, 3000)

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})