// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */ 
  data: {
   show: true,
   array: ['业户基本信息', '人员查询', '班线查询','车辆查询'],
   index:0,
   idCard:'',
   obj:{},
  },
  input_str2: function (e) { this.setData({ idCard: e.detail.value }) },
  bindPickerChange:function(e){
    this.setData({
      index:e.detail.value,
      show:true
    })
  },
  formSubmit: function (e) {
    var that = this;
      // 验证码输入正确时的操作 520112118000551
      var obj_s2 = JSON.stringify(e.detail.value);
      if (that.data.idCard ==''){
        wx.showToast({
          title: '请输入查询条件！',
          icon: 'none'
        });
      }else{
        wx.showLoading({title: '查询中',});
        if(that.data.index == 0){
          wx.request({
        header: {
          'Content-Type': getApp().globalData.contentType,
        },
        url: getApp().globalData.url + 'requestDelegate/handle',
        data: {
          'param': JSON.stringify({
              data:{
                "_app_id_": "SZWZX",
                "_license_key_": "A5174DE7A5CE5B8EB81ECC0817E15072",
                "LICENSE_NUMBER": that.data.idCard//520329000861
              }
          }),
          'headers': JSON.stringify({ apiCode: "100W1291", netType: "1" }),
          'url': getApp().globalData.sousuo_url + '/postJson'
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.head.code == 200 && data.data.result.output.body.array0){
            that.setData({
              obj: data.data.result.output.body.array0.rowSet.row[0],
              show:false,
            })
          }else{
            wx.showToast({
              title: '没有查询到业户信息！',
              icon: 'none'
            });
            that.setData({
              show: true,
            })
          }
        }
      })//ajax end
        }else if(that.data.index ==1){
          wx.request({
        header: {
          'Content-Type': getApp().globalData.contentType,
        },
        url: getApp().globalData.url + 'requestDelegate/handle',
          data: {
          'param': JSON.stringify({
            data: {
              "_app_id_": "SZWZX",
              "_license_key_": "A5174DE7A5CE5B8EB81ECC0817E15072",
              "CARDNO": that.data.idCard//522128198110095015
            }
          }),
            'headers': JSON.stringify({ apiCode: "100W1292", netType: "1" }),
            'url': getApp().globalData.sousuo_url + '/postJson'
        },
        method: 'post',
          dataType: 'json',
            success: function (data) {
              wx.hideLoading();
              console.log(data);
              if (data.data.head.code == 200 && data.data.result.output.head.content) {
                that.setData({
                  obj: data.data.result.output.body.array0.rowSet.row[0],
                  show: false,
                })
              } else {
                wx.showToast({
                  title: '没有查询到人员信息!',
                  icon: 'none'
                });
                that.setData({
                  show: true,
                })
              }
            }
      })//ajax end
        }else if(that.data.index ==2){
          wx.request({
  header: {
    'Content-Type': getApp().globalData.contentType,
        },
  url: getApp().globalData.url + 'requestDelegate/handle',
    data: {
    'param': JSON.stringify({
      data: {
        "_app_id_": "SZWZX",
        "_license_key_": "A5174DE7A5CE5B8EB81ECC0817E15072",
        "LINNAME": that.data.idCard//桐梓-八五厂
      }
    }),
      'headers': JSON.stringify({ apiCode: "100W1293", netType: "1" }),
      'url': getApp().globalData.sousuo_url + '/postJson'
  },
  method: 'post',
    dataType: 'json',
      success: function (data) {
        wx.hideLoading();
        console.log(data);
        if (data.data.head.code == 200 && data.data.result.output.body.array0.rowSet.row.length>0) {
          that.setData({
            obj: data.data.result.output.body.array0.rowSet.row,
            show: false,
          })
        } else {
          wx.showToast({
            title: '没有查询到班线信息!',
            icon: 'none'
          });
          that.setData({
            show: true,
          })
        }
      }
})//ajax end
        }else{
          wx.request({
  header: {
    'Content-Type': getApp().globalData.contentType,
        },
  url: getApp().globalData.url + 'requestDelegate/handle',
    data: {
    'param': JSON.stringify({
      data: {
        "_app_id_": "SZWZX",
        "_license_key_": "A5174DE7A5CE5B8EB81ECC0817E15072",
        "BRANUM": that.data.idCard//贵1033398
      }
    }),
      'headers': JSON.stringify({ apiCode: "100W1294", netType: "1" }),
        'url': getApp().globalData.sousuo_url + '/postJson'
  },
  method: 'post',
    dataType: 'json',
      success: function (data) {
        wx.hideLoading();
        console.log(data);
        if (data.data.head.code == 200 && data.data.result.output.head.content) {
          that.setData({
            obj: data.data.result.output.body.array0.rowSet.row[0],
            show: false,
          })
        } else {
          wx.showToast({
            title: '没有查询到车辆信息！',
            icon: 'none'
          });
          that.setData({
            show: true,
          })
        }
      }
})//ajax end
        }
      }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },
  cencel_login: function () {
    wx.switchTab({
      url: '/page/tabBar/index/index',
    })
  },
  to_login: function () {
    wx.navigateTo({
      url: '/page/home/pages/home/login/login_select',
    })
    this.setData({
      showmode: {
        show: false,
        phone: wx.getStorageSync("phone")
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },
})