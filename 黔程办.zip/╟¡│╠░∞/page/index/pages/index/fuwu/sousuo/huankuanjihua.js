// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    idCard:'',
    regionName: '',
    show:true,
    obj:{}
  },
  input_str: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  input_str2: function (e) {
    this.setData({
      idCard: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    // ，传递ajax 肖德序   522121197910227435
    if (this.data.name == '') {
      wx.showToast({
        title: '请输入姓名！',
        icon: 'none'
      });
    } else if (this.data.idCard == ''){
      wx.showToast({
        title: '请输入身份证号！',
        icon: 'none'
      });
    } else {
      wx.showLoading({
        title: '查询中',
      });
      var obj_s2 = JSON.stringify(e.detail.value);
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口 肖德序 522121197910227435
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: { 'param': obj_s2, 'url': getApp().globalData.sousuo_url + '/gjjRespeatment' },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.data != null && data.data.data.length != 0){
            _that.setData({
              show:false,
              obj: data.data.data
            })
          }else{
            wx.showToast({
              title: '没有查询到数据！',
              icon: 'none'
            });
          }
        },
        fail:function(){
          wx.showToast({
            title: '网络链接失败，请稍后重试！',
            icon: 'none'
          });
        }
      }) //ajax end
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },
  cencel_login: function () {
    wx.switchTab({
      url: '/page/tabBar/index/index',
    })
  },
  to_login: function () {
    wx.navigateTo({
      url: '/page/home/pages/home/login/login_select',
    })
    this.setData({
      showmode: {
        show: false,
        phone: wx.getStorageSync("phone")
      }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      idCard: wx.getStorageSync("idCardNumber"),
      user_name: wx.getStorageSync("user_name"),
      name: wx.getStorageSync("user_name")
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})