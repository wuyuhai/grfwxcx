// pages/index/fuwu/shebcx.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    medical:'',
    regionName:''
  },
  input_str: function (e) {
    this.setData({
      medical: e.detail.value
    })
  },
  input_str2: function (e) {
    this.setData({
      regionName: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
      console.log('form发生了submit事件，携带数据为：', e.detail.value);
      // ，传递ajax 数据{entname: "珠海方图智能科技有限公司"}或{entname: "91330701717880674U"}
    if (this.data.medical == '') {
        wx.showToast({
          title: '请输入机构类型！',
          icon: 'none'
        });
    } else if (this.data.regionName == ''){
      wx.showToast({
        title: '请输入地区！',
        icon: 'none'
      });
    } else {
      var obj_s2 = JSON.stringify(e.detail.value);
      wx.navigateTo({
        url: '/page/index/pages/index/fuwu/sousuo/yidijiuyi_res?data=' + obj_s2,
      });
      }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})