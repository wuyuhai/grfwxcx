// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    idCardNumber:'',
    show:true,
    obj:{}
  },
  input_str2: function (e) {
    this.setData({
      idCardNumber: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
    if (this.data.idCardNumber == '') {
      wx.showToast({
        title: '请输入身份证号！',
        icon: 'none'
      });
    } else {
      wx.showLoading({title: '查询中',});
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              data: JSON.stringify({
                "idNum": _that.data.idCardNumber
              })
            }),
            'headers': JSON.stringify({
              'apiCode': '100W1303',
            }),
            'url': getApp().globalData.sousuo_url + '/postJson'
          },//实际调用接口   522423198509110023
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.code == 500) {
              wx.showToast({
                title: '网络链接失败，请稍后重试！',
                icon: 'none'
              });
              return;
            }
            if (data.data.head.code == 200 && data.data.result.obj.code) {
              _that.setData({
                show: false,
                obj: data.data.result.obj.data
              })
            } else {
              wx.showToast({
                title: '没有查询到数据！',
                icon: 'none'
              });
            }
          },
          fail: function () {
            wx.hideLoading();
            wx.showToast({
              title: '网络链接失败，请稍后重试！',
              icon: 'none'
            });
          }
        }) //ajax end
      
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      idCardNumber: wx.getStorageSync("idCardNumber"),
    })
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      idCardNumber: wx.getStorageSync("idCardNumber"),
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})