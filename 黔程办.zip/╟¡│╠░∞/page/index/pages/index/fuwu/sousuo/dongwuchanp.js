// pages/index/fuwu/shebcx.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    useorgname:'',
    array: ['动物A证', '动物B证', '动物产品A证', '动物产品B证'],
    array1: ['001', '002', '003', '004'],
    index: 0,
    show:true,
    obj:{}
  },
  input_str2: function (e) {
    this.setData({
      useorgname: e.detail.value
    })
  },
  bindPickerChange: function (e) {
    this.setData({
      index: e.detail.value,
      show: true,
    })
  },
  timestampToTime: function(){
    var date = new Date();
    var Y = date.getFullYear().toString();
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1).toString();
    var D = date.getDate() < 10 ? '0' + date.getDate() + ' ' : date.getDate();
    return Y + M + D;
  },
  formSubmit: function (e) {
    var _that = this;
    if (this.data.useorgname == '') {
      wx.showToast({
        title: '请输入检疫证印刷编号！',
        icon: 'none'
      });
    } else {
      wx.showLoading({title: '查询中',});
      if (this.data.index == 0){
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              data: JSON.stringify({
                "ID": 2,
                "Name": "SZWZX_SJDJ",
                "YPWS": this.timestampToTime(),
                "JYZNo": _that.data.useorgname
              })
            }),
            'headers': JSON.stringify({
              'apiCode': '100W1188',
            }),
            'url': getApp().globalData.sousuo_url + '/postJson'
          },//实际调用接口
          // 5230661539
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.code == 500) {
              wx.showToast({
                title: '网络链接失败，请稍后重试！',
                icon: 'none'
              });
              return;
            }
            if (data.data.head.code == 200 && data.data.result) {
              _that.setData({
                show: false,
                obj: data.data.result
              })
            } else {
              wx.showToast({
                title: '没有查询到数据！',
                icon: 'none'
              });
            }
          },
          fail: function () {
            wx.hideLoading();
            wx.showToast({
              title: '网络链接失败，请稍后重试！',
              icon: 'none'
            });
          }
        }) //ajax end
      } else if (this.data.index == 1){
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              data: JSON.stringify({
                "ID": 2,
                "Name": "SZWZX_SJDJ",
                "YPWS": this.timestampToTime(),
                "JYZNo": _that.data.useorgname
              })
            }),
            'headers': JSON.stringify({
              'apiCode': '100W1186',
            }),
            'url': getApp().globalData.sousuo_url + '/postJson'
          },//实际调用接口
          // 5204923059
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.code == 500) {
              wx.showToast({
                title: '网络链接失败，请稍后重试！',
                icon: 'none'
              });
              return;
            }
            if (data.data.head.code == 200 && data.data.result) {
              _that.setData({
                show: false,
                obj: data.data.result
              })
            } else {
              wx.showToast({
                title: '没有查询到数据！',
                icon: 'none'
              });
            }
          },
        }) //ajax end
      } else if (this.data.index == 2){
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              data: JSON.stringify({
                "ID": 2,
                "Name": "SZWZX_SJDJ",
                "YPWS": this.timestampToTime(),
                "JYZNo": _that.data.useorgname
              })
            }),
            'headers': JSON.stringify({
              'apiCode': '100W1187',
            }),
            'url': getApp().globalData.sousuo_url + '/postJson'
          },//实际调用接口
          // 5200426984
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.code == 500) {
              wx.showToast({
                title: '网络链接失败，请稍后重试！',
                icon: 'none'
              });
              return;
            }
            if (data.data.head.code == 200 && data.data.result) {
              _that.setData({
                show: false,
                obj: data.data.result
              })
            } else {
              wx.showToast({
                title: '没有查询到数据！',
                icon: 'none'
              });
            }
          },
        }) //ajax end
      }else{
        wx.request({
          url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            'param': JSON.stringify({
              data: JSON.stringify({
                "ID": 2,
                "Name": "SZWZX_SJDJ",
                "YPWS": this.timestampToTime(),
                "JYZNo": _that.data.useorgname
              })
            }),
            'headers': JSON.stringify({
              'apiCode': '100W1188',
            }),
            'url': getApp().globalData.sousuo_url + '/postJson'
          },//实际调用接口
          // 5230661539
          method: 'post',
          dataType: 'json',
          success: function (data) {
            wx.hideLoading();
            console.log(data);
            if (data.data.code == 500) {
              wx.showToast({
                title: '网络链接失败，请稍后重试！',
                icon: 'none'
              });
              return;
            }
            if (data.data.head.code == 200 && data.data.result) {
              _that.setData({
                show: false,
                obj: data.data.result
              })
            } else {
              wx.showToast({
                title: '没有查询到数据！',
                icon: 'none'
              });
            }
          },
        }) //ajax end
      }
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})