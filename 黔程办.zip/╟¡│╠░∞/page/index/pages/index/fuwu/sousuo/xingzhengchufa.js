// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    regionName: '',
    show:true,
    obj:{}
  },
  input_str: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    // ，传递ajax 道市监行处字[2016]118号
    if (this.data.name == '') {
      wx.showToast({
        title: '请输入处罚决定书文号！',
        icon: 'none'
      });
    } else {
      wx.showLoading({
        title: '查询中',
      });
      var paramMap = new Object;
      var array = new Array(_that.data.name);
      var paramsnum = array.length;
      paramMap.id = "7cfd0a946761d0095712d1039a709b52";
      paramMap.params = array;
      paramMap.paramsnum = paramsnum;
      wx.request({
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        url: getApp().globalData.url + 'requestDelegate/handle',
        data: {
          'param': JSON.stringify({
            'data': paramMap
          }),
          'headers': JSON.stringify({
            'apiCode': '100W1089',
            'netType': '1'
            }),
          'url': getApp().globalData.sousuo_url + '/postJson'
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if(data.data.head.code == 200){
            if (data.data.result.result){
              _that.setData({
              show:false,
                obj: data.data.result.result[0]
            })
            }
          }else{
              wx.showToast({title: '没有查询到数据！',icon: 'none'});
          }
        },
        fail:function(){
          wx.showToast({
            title: '网络链接失败，请稍后重试！',
            icon: 'none'
          });
        }
      }) //ajax end
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})