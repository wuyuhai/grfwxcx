// pages/index/fuwu/shebcx.js
var app = getApp();
Page({
  data: {
    id:'',
    name:'',
    securityCode:'',
    regionName:'',
    show:true,
    obj:[],
    src:'data:image/jpeg;base64,',
    rdmid:'',
    mphone:'15585109882',
    rndid:'',
    currentTime:60,
    code_show:true,
    code:'',
    obj_img:'',
    hidden:true,
    nocancel:false,
  },
  cancel: function () {
    this.setData({
      hidden: true
    });
  },
  confirm: function () {
    var _that = this;
    _that.setData({
      hidden:true
    })
    if (_that.data.securityCode==''){
      wx.showToast({
        title: '请输入验证码！',
        icon: 'none'
      });
    }else{
      wx.showLoading({
        title: '正在发送验证码',
      });
      //陈钰文  520102198710163434  赵凯   106571201502001434
      var keydata = {
        rdmid: _that.data.rdmid,
        certificateNumber: _that.data.id,
        name: _that.data.name,
        securityCode: _that.data.securityCode,
      }
      wx.request({
        header: {
          'Content-Type': getApp().globalData.contentType,
        },
        method: 'post',
        dataType: 'json',
        url: getApp().globalData.url + 'requestDelegate/handle',
        data: {
          'param': JSON.stringify({
            data: JSON.stringify(keydata)
          }),
          'headers': JSON.stringify({ "apiCode": "100W1111" }),
          'url': getApp().globalData.sousuo_url + '/anshun/postJson'
        },
        success: function (result) {
          wx.hideLoading();
          console.log(result);
          if (result.data.head.code == 200 && result.data.result.data.rndid) {
            _that.setData({
              rndid: result.data.result.data.rndid,
              show: true
            })
            wx.request({
              header: {
                'Content-Type': getApp().globalData.contentType,
                //  "apiCode": "100W1112",
              },
              method: 'post',
              dataType: 'json',
              url: getApp().globalData.url + 'requestDelegate/handle',
              data: {
                'param': JSON.stringify({
                  data: JSON.stringify({
                    rndid: _that.data.rndid,
                    mphone: _that.data.mphone
                  })
                }),
                'headers': JSON.stringify({ "apiCode": "100W1112" }),
                'url': getApp().globalData.sousuo_url + '/anshun/postJson'
              },
              success: function (data) {
                console.log(data);
                if (data.data.result.status == 200) {
                  wx.showToast({ title: '短信验证码发送成功，请注意查收！', icon: 'none' });
                  _that.settime();
                  //  _that.onShow();
                  _that.setData({
                    securityCode: ''
                  })
                } else {
                  wx.showToast({ title: '短信验证码发送失败，请稍后重试！', icon: 'none' });
                }
              },
              fail: function () {
                wx.hideLoading();
                wx.showToast({
                  title: '网络链接失败，请稍后重试！',
                  icon: 'none'
                });
              }
            }) //ajax end
          } else {
            wx.showToast({
              title: result.data.result.data.errorInfo,
              icon: 'none'
            });
            _that.setData({
              src: 'data:image/jpeg;base64,' + result.data.result.data.fileUrl,
            })
          }
        },
        fail: function () {
          wx.hideLoading();
          wx.showToast({
            title: '网络链接失败，请稍后重试！',
            icon: 'none'
          });
        }
      }) //ajax end
    }
  },
  input_str: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
   input_str2: function (e) {
    this.setData({
      id: e.detail.value
    })
  },
  input_str3: function (e) {
    this.setData({
      securityCode: e.detail.value
    })
  },
  input_str4: function (e) {
    this.setData({
      code: e.detail.value
    })
  },
  sub_form:function(){
    var _that = this;
    _that.setData({
      show:true
    })
    if (this.data.code == '') {
      wx.showToast({title: '请输入短信验证码！',icon: 'none'});
    } else {
      wx.showLoading({title: '查询中...',icon:'none'});
      wx.request({
        header: {
          'Content-Type': getApp().globalData.contentType,
        },
        method: 'post',
        dataType: 'json',
        url: getApp().globalData.url + 'requestDelegate/handle',
        data: {
          'param': JSON.stringify({
            data: JSON.stringify({
              rndid: _that.data.rndid,
              mphone: _that.data.mphone,
              code: _that.data.code
            })
          }),
          'headers': JSON.stringify({ "apiCode": "100W1113" }),
          'url': getApp().globalData.sousuo_url + '/anshun/postJson'
        },
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.data.messageError){
            wx.showToast({ title: '短信验证码输入错误!', icon: 'none' });
            return;
          }
          if (data.data.head.code == 200 && data.data.result.data.academicCertificate) {
            _that.setData({
              show:false,
              obj: data.data.result.data.academicCertificate,
              obj_img: 'data:image/jpeg;base64,' + data.data.result.data.photoUrl,
              code:''
            })
          } else {
            _that.setData({
              show: true,
            })
            wx.showToast({ title: '没有查询到相应的数据！', icon: 'none' });
          }
        },
        fail: function () {
          wx.hideLoading();
          wx.showToast({
            title: '网络链接失败，请稍后重试！',
            icon: 'none'
          });
        }
      }) //ajax end
    }
  },
  settime:function(){
    var _that = this;
    var currentTime = _that.data.currentTime;
    _that.setData({
      currentTime: currentTime,
    })
    var interval = setInterval(function () {
      _that.setData({
        currentTime: (currentTime - 1)
      })
      currentTime--;
      if (currentTime <= 0) {
        clearInterval(interval);
        _that.setData({
          code_show: true,
          currentTime:60
        })
      }else{
        _that.setData({
          code_show: false,
        })
      }
    }, 1000)
  },
  formSubmit: function (e) {
    var _that = this;
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    // ，传递ajax 道市监行处字[2016]118号
    if (this.data.name == '') {
      wx.showToast({
        title: '请输入姓名！',
        icon: 'none'
      });
    }else if(this.data.id == ''){
      wx.showToast({
        title: '请输入证书编号！',
        icon: 'none'
      });
    }else {
      _that.setData({
        hidden:false,
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      mphone: wx.getStorageSync("phone"),
      name: wx.getStorageSync("user_name")
    })
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
     var that = this;
     that.change_code();
  },
  change_code:function(){
var that =this;
    wx.showLoading({
      title: '加载中',
    });
    wx.request({
      header: {
        'Content-Type': getApp().globalData.contentType,
      },
      method: 'post',
      dataType: 'json',
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: {
        'param': JSON.stringify({
          // data:'1'
        }),
        'headers': JSON.stringify({ "apiCode": "100W1109" }),
        'url': getApp().globalData.sousuo_url + '/anshun/postJson'
      },
      success: function (data) {
        wx.hideLoading();
        console.log(data);
        if (data.data.head.code == 200 && data.data.result.data) {
          that.setData({
            src: 'data:image/jpeg;base64,' + data.data.result.data.fileUrl,
            rdmid: data.data.result.data.rdmid
          })
        }
      },
      fail: function () {
        wx.hideLoading();
        wx.showToast({
          title: '网络链接失败，请稍后重试！',
          icon: 'none'
        });
      }
    }) //ajax end
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})