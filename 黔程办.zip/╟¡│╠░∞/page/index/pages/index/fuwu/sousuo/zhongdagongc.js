// pages/public/no_open.js
// var WxParse = require('../../../../wxParse/wxParse.js');
var page = 1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    title: '德国的风格大概v不错从规划法规刚好错过',
    obj1: '<view class="p">安防监控事发现场v 收到了罚款坚实的</view>',
    time: '2018-07-07',
    number:'3264465461',
    come_add:'546',
    keyword:'--',
    nodes: [{
      name: 'div',
      attrs: {
        class: 'div_class',
        style: 'line-height: 60px; color: red;'
      },
      children: [{
        type: 'text',
        text: 'Hello&nbsp;World!'
      }]
    }],
    Html: '',
    show:true,
    show_r:true,
    show_l:false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (num1) {
    if(num1 == undefined){
      num1 = 0;
    }
    wx.showLoading({
      title: '加载中',
    })
    var that = this;
    that.setData({
      show: true
    });
    wx.request({
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      // url: 'http://202.98.195.208:83/IntegratedQuery/majorProjectQuery',
      method: 'post',
      dataType: 'json',
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: { 'param': JSON.stringify({}), 'url': getApp().globalData.sousuo_url + '/majorProjectQuery' },
      success: function (data) {
        console.log(data);
        if (data.data.code == 200) {
          wx.hideLoading();
          var str = data.data.data.list[num1].content;
          var str2 = str.replace(/src="./gi, ' style="max-width:100%;width:100%;height:auto;display:line-block;margin:20rpx 0;padding:20rpx 0;"  src="http://www.gzdpc.gov.cn/ztzl/zdgczdxm');
          var str3 = str2.replace(/\href="./gi, 'href="http://www.gzdpc.gov.cn/ztzl/zdgczdxm');
          var str4 = str3.replace(/\&nbsp;/gi, ' ');
          that.setData({
            title: data.data.data.list[num1].metaDataTitle,
            come_add: data.data.data.list[num1].newsSource == null ? '--' : data.data.data.list[num1].newsSource,
            Html: str4,
            number: data.data.data.list[num1].newGuide,
            time: data.data.data.list[num1].pubDate,
            keyword: data.data.data.list[num1].keyword == null ? '--' : data.data.data.list[num1].keyword,
            show: false
          })
        } else {
          wx.hideLoading();
          wx.showToast({
            title: '没有数据！',
            icon: 'none'
          });
          setTimeout(function () {
            wx.navigateBack();  //返回上一个页面
          }, 3000)
        }
      }
    }) //ajax end
  },
  changePage:function(){
    var that = this;
    page +=1;
    that.onShow(page);
    that.setData({
      show_l: true
    });
  },
  changePage2: function () {
    var that = this;
    page -= 1;
    that.onShow(page);
    if(page == 0){
      that.setData({
        show_l: false
      });
    }else{
      that.setData({
        show_l: true
      });
    }
    that.setData({
      show_r: true
    });
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})