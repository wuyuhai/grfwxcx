// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */ 
  data: {
   msg:"社保参保登记",
   show: true,
   listData: [],
   listData2:[],
   name: '',
   idCard:'',
   user_name:'',
   showmode: {
     show: false,
     phone: '',
   }
  },
  input_str: function (e) { this.setData({ idCard: e.detail.value }) },
  input_str2: function (e) { this.setData({ name: e.detail.value }) },
  formSubmit: function (e) {
    var that = this;
      // 验证码输入正确时的操作
      console.log('form发生了submit事件，携带数据为：', e.detail.value);
      var obj_s2 = JSON.stringify(e.detail.value);
      if (that.data.idCard ==''){
        wx.showToast({
          title: '请输入社保卡身份证号！',
          icon: 'none'
        });
      } else if (that.data.name == ''){
        wx.showToast({
          title: '请输入姓名！',
          icon: 'none'
        });
      }
      else{
        wx.showLoading({
          title: '加载中',
        });
        var obj_s2 = JSON.stringify({
          name: that.data.name,
          idCard: that.data.idCard,
          currPage: 1,
          pageSize: 40
        });
        wx.request({
          header: {
            'Content-Type': getApp().globalData.contentType
          },
        //吴顺斌   522321197402220457
          url: getApp().globalData.url + 'requestDelegate/handle',
          data: { 'param': obj_s2, 'url': getApp().globalData.sousuo_url + '/qxnDjAc02' },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.code == 501) {
            wx.showToast({title: '没有查到数据，请检查输入或是否开通此业务！',icon: 'none'});
            that.setData({show: true,})
            return;
          }
          if (data.data.code == 200 && data.data.data.list !=null){
             that.setData({
                show: false,
               listData2: data.data.data.list,
              })
          }else{
            wx.showToast({ title: '没有查到数据，请检查输入或是否开通此业务！', icon: 'none' });
          }
        }
      })//ajax end
      }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  this.setData({
    idCard: wx.getStorageSync("idCardNumber"),
    user_name: wx.getStorageSync("user_name"),
    name: wx.getStorageSync("user_name"),
  })
  if (this.data.user_name == '' || this.data.user_name == null){
    this.setData({
      showmode: {
        show: true,
        phone: wx.getStorageSync("phone")
      }
    })
  }
  },
  cencel_login: function () {
    wx.switchTab({
      url: '/page/tabBar/index/index',
    })
  },
  to_login: function () {
    wx.navigateTo({
      url: '/page/home/pages/home/login/login_select',
    })
  },
  getPhoneNumber: function (e) { //点击获取手机号码按钮
    var that = this;
    wx.login({
      success: data => {
        console.log(data)
        console.log(e.detail.iv)
        console.log(e.detail.encryptedData)
        var ency = e.detail.encryptedData;
        var iv = e.detail.iv;
        if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
          // 用户取消了获取手机号
        } else { //同意授权
          wx.request({
            method: "POST",
            // url: 'https://face.fotoit.cn:84/UrbanService/user/decodeUserInfo',  //这个解密地址能用
            url: getApp().globalData.url + 'user/decodeUserInfo',
            data: {
              code: data.code,
              encryptedData: e.detail.encryptedData,
              iv: iv,
            },
            header: {
              'content-type': getApp().globalData.contentType,
            },
            success: (res) => {
              console.log(res);
              if (res.data.code == 200) { //code好像只有线上的可以，发布之后如果获取手机号成功会返回200，，跳转选择登陆
                if (res.data.data.phoneNumber) {
                  getApp().savewxinfo(res.data.data.phoneNumber);
                  var phone = res.data.data.phoneNumber.toString();
                  wx.setStorageSync("phone", phone);
                  that.setData({
                    showmode: {
                      show: false,
                      phone: phone,
                    }
                  })
                  wx.navigateTo({
                    url: '/page/home/pages/home/login/login_select',
                  })
                  // wx.showToast({
                  //   title: "解密成功" + phone,
                  //   icon: 'none'
                  // });
                } else {
                  wx.showToast({
                    title: "解密失败",
                    icon: 'none'
                  });
                  that.setData({
                    showmode: {
                      show: false,
                      phone: '',
                    }
                  })
                }
              }
            },
            fail: function (res) {
              console.log("解密失败~~~~~~~~~~~~~");
              console.log(res);
              wx.showToast({
                title: '获取手机号失败，请检查网络！',
                icon: 'none'
              });
            }
          });
        }
      }
    })

  },
})