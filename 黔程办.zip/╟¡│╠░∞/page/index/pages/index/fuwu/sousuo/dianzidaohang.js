// pages/index/fuwu/shebcx.js
var page = 1;
var is_next = true;
var change = false;
Page({
  data: {
    data: [],
    data1: [],
    show: true,
    name:''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  input_str: function (e) { 
    this.setData({ name: e.detail.value,data1:[] }) 
    is_next = true;
    if (e.detail.vavle!=''){//如果输入字段不为空
      change = true;//已经改变了，
    }else{
      change = false;
    }
    },
  onLoad: function (options) {
    page = 1;
    is_next = true;
  },
  formSubmit: function (e) {
    this.onShow(1);
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (num1) {
    if (num1 == undefined) {
      num1 = 1;
    }
    var _this = this;
    wx.showLoading({
      title: '加载中',
    });
    if (is_next){
      var obj_s2 = JSON.stringify({
        name: _this.data.name,
        currPage: num1,
        pageSize: 20
      });
      wx.request({
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        url: getApp().globalData.url + 'requestDelegate/handle',
        data: {
          'param': JSON.stringify({
            name: _this.data.name,
            currPage: num1,
            pageSize: 20
          }),
          'url': getApp().globalData.sousuo_url + '/elecGuideQuery'
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          var obj = data.data.data.list;
          if (num1 == 1 && obj == null){//如果是第一页没有数据就显示无数据，，第二页以后的显示之前的数据
            _this.setData({
              show: false
            })
            return;
          }
          if (obj == null) {
            // _this.setData({
            //   show: false
            // })
            wx.showToast({
              title: '没有更多数据了！',
              icon: 'none'
            });
            return;
          }else{
            _this.setData({
              show: true
            })
            if (change){//判断如果是搜索的时候，，直接替换数据，，否则添加到data显示
              var arr = _this.data.data1;
              for (var i = 0; i < obj.length; i++) {
                arr.push(obj[i]);
              }
              _this.setData({ data: arr });
            }else{
            var array = _this.data.data;
            for (var i = 0; i < obj.length; i++) {
              array.push(obj[i]);
            }
            _this.setData({ data: array});
            }
            if (obj.length < 20) {
              is_next = false;
              return;
            }
          }
        }
      }) //ajax end
    }else{
      wx.showToast({
        title: '没有更多数据了！',
        icon: 'none'
      });
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (is_next) {
      page += 1;
      this.onShow(page);
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})