// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name:'',
    idCard: '',
    cjNum:'',
    sDate: '2009-05-31',
    eDate: '2019-05-31',
    sDate_i: '2009-05-31',
    eDate_i: '2019-05-31',
  },
  input_str: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  input_str2: function (e) {
    this.setData({
      idCard: e.detail.value
    })
  },
  input_str3: function (e) {
    this.setData({
      cjNum: e.detail.value
    })
  },
  bindDateChange:function(e){
    this.setData({
      sDate: e.detail.value,
      sDate_i:e.detail.value,
    })
  },
  bindDateChange2: function (e) {
    this.setData({
      eDate: e.detail.value,
      eDate_i: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
      console.log('form发生了submit事件，携带数据为：', e.detail.value);
      // ， 谭义黔   52212119771112007X   52212119771112007X44
    if (_that.data.name == '') {
        wx.showToast({
          title: '请输入姓名！',
          icon: 'none'
        });
    } else if (_that.data.idCard == ''){
      wx.showToast({
        title: '请输入身份证号！',
        icon: 'none'
      });
    } else if (_that.data.cjNum == '') {
      wx.showToast({
        title: '请输入残疾人证号！',
        icon: 'none'
      });
    } else {
      wx.showLoading({
        title: '查询中',
      });
      wx.request({
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        // 谭义黔   52212119771112007X   52212119771112007X44
        url: getApp().globalData.url + 'requestDelegate/handle',
        data: { 'param': JSON.stringify({
         	name:_that.data.name,
          idCard: _that.data.idCard,
          cjNum: _that.data.cjNum,
          sDate: _that.data.sDate,
          eDate: _that.data.eDate,
        }), 'url': getApp().globalData.sousuo_url + '/cj/canjiCheck' },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.code == 501) {
            wx.showToast({ title: '没有查到数据，请检查输入或是否开通此业务！', icon: 'none' });
            that.setData({ show: true, })
            return;
          }
          if (data.data.code == 200&&data.data.data.state){
            wx.showToast({
              title: data.data.data.state,
              icon: 'none'
            });
          }else{
            wx.showToast({
              title:'没有查询到相应的数据，请检查输入！',
              icon: 'none'
            });
          }
        }
      })
      }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})