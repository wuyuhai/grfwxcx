// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    equlogcode: '',
    useorgname:'',
    regionName: '',
    show:true,
    obj:{}
  },
  input_str2: function (e) {
    this.setData({
      useorgname: e.detail.value
    })
  },
  input_str: function (e) {
    this.setData({
      equlogcode: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
    if (this.data.useorgname == '') {
      wx.showToast({
        title: '请输入使用单位名称！',
        icon: 'none'
      });
    } else if (this.data.equlogcode == ''){
      wx.showToast({
        title: '请输入设备注册代码！',
        icon: 'none'
      });
    } else {
      wx.showLoading({title: '查询中',});
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: { 'param': JSON.stringify({
            useorgname: this.data.useorgname,
            equlogcode: this.data.equlogcode
        }),
        'url': getApp().globalData.sousuo_url + '/queryDevice' },//实际调用接口
        // 余庆县好优多购物广场  30205203292009110001
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.code == 500){
            wx.showToast({
              title: '网络链接失败，请稍后重试！',
              icon: 'none'
            });
            return;
          }
          if (data.data.code == 200&&data.data.data.data.length>0){
            _that.setData({
              show:false,
              obj: data.data.data.data[0]
            })
          }else{
            wx.showToast({
              title: '没有查询到数据！',
              icon: 'none'
            });
          }
        },
        fail:function(){
          wx.hideLoading();
          wx.showToast({
            title: '网络链接失败，请稍后重试！',
            icon: 'none'
          });
        }
      }) //ajax end
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})