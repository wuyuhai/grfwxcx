// pages/index/fuwu/shebcx.js
var page = 1;
var is_next = true;
var change = false;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:{},
    show:true,
    arr:[],
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //创建节点选择器    
    var query = wx.createSelectorQuery();    //选择id    
    var that = this;    
    query.select('#fiexd').boundingClientRect(function (rect) {      
      console.log(rect.height)      
      that.setData({height: rect.height + 'px'})
      }).exec();
    page = 1;
    is_next = true;
    this.setData({
      data:{
        smc: options.str1,
        size:10
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (num1) {
    if (num1 == undefined) {
      num1 = 1;
    }
    var _this = this;
    wx.showLoading({
      title: '加载中',
    });
   var obj_s2 = {
      smc: _this.data.data.smc,
      page: num1,
      size: 10
    };
    wx.request({
      header: {
        'Content-Type': getApp().globalData.contentType,
      },
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: {
        'param': JSON.stringify(obj_s2),
        'url': getApp().globalData.sousuo_url + '/dibao/vieNews'
      },
    // wx.request({
    //   header: {
    //     'Content-Type': getApp().globalData.contentType
    //   },
    //   url: 'https://zwzx.anshun.gov.cn:84/zhengwuji/postForJsonRoute',
    //   data: { 'data': JSON.stringify(obj_s2), 'url': getApp().globalData.sousuo_url + '/dibao/vieNews' },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        wx.hideLoading();
        var obj = data.data.data.list;
        if (num1 == 1 && obj == null) {//如果是第一页没有数据就显示无数据，，第二页以后的显示之前的数据
          _this.setData({
            show: false,
          })
          return;
        }
        if (obj == null) {
          wx.showToast({
            title: '没有更多数据了！',
            icon: 'none'
          });
          return;
        } else {
          var array = _this.data.arr;
          for (var i = 0; i < obj.length; i++) {
            array.push(obj[i]);
          }
          _this.setData({ arr: array });
        }
        if (obj.length < 10) {
          is_next = false;
          return;
        }
      }
    }) //ajax end
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (is_next) {
      page += 1;
      this.onShow(page);
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})