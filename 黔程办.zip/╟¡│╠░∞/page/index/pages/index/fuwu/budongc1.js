// pages/index/fuwu/shebcx.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    msg: "不动产证书信息核验",
    code: 'oppo',
    user_code: 'oppo',//测试时验证码可以和初始验证码一样，上线后必须修改
    show: true,
    array: ['单独所有', '共同共有', '按份共有', '其他共有'],
    index: 0,
    listData:[],
    str1: '',
    str2: '',
    str3: '',
    str4: '',
    str5: '',
  },
  bindPickerChange: function (e) {
    this.setData({
      index: e.detail.value
    })
  },
  input_str: function (e) { this.setData({ str1: e.detail.value }) },
  input_str2: function (e) { this.setData({ str2: e.detail.value }) },
  input_str3: function (e) { this.setData({ str3: e.detail.value }) },
  input_str4: function (e) { this.setData({ str4: e.detail.value }) },
  input_str5: function (e) {this.setData({str5: e.detail.value})},
  changeCode: function () {
    var chang_code = '';
    var codeLength = 4;
    var random = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
      'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'); //随机数
    for (var i = 0; i < codeLength; i++) {
      var charIndex = Math.floor(Math.random() * 36); //取得随机数的索引
      chang_code += random[charIndex];
    }
    this.setData({
      code: chang_code
    })
  },
  user_code: function (e) {//用户修改验证码
    this.setData({
      user_code: e.detail.value
    })
  },
  formSubmit: function (e) {
    var _that = this;
    if (this.data.user_code.toUpperCase() == this.data.code.toUpperCase()) {
      // 验证码输入正确时的操作
      console.log('form发生了submit事件，携带数据为：', e.detail.value);
        // 表单全部填写
        // {bdcqzsh: "黔（2017）安顺市不动产权第6000380号", qlr: "李静", gyqk: "单独所有", zl: "西秀区市东路康乐花园4单元7层右6-1号", bdcdyh: "520402006030GB00002F00030001", mj:"162.95"}
      
      if (this.data.str1 == '' || this.data.str2 == '' || this.data.str3 == '' || this.data.str4 == '' || this.data.str5 == '') {
        wx.showToast({
          title: '请输入完整信息，所有项必填！',
          icon: 'none'
        });
      } else {
        var obj_s2 = JSON.stringify(e.detail.value);
          wx.request({
            // url: 'http://202.98.195.208:83/IntegratedQuery/realPropertyCertificate',
            url: getApp().globalData.url + 'requestDelegate/handle',
            header: {
              'Content-Type': getApp().globalData.contentType
            },
            // data: e.detail.value,
            data: { 'param': obj_s2, 'url': 'http://202.98.195.208:83/IntegratedQuery/realPropertyCertificate' },
            method: 'post',
            dataType: 'json',
            success: function (data) {
              console.log(data);
              if(data.data.data.code == 0){
                if (data.data.data.entity.result == 'success') {
                  var list = data.data.data.entity;
                  delete list.zmqlhsx;
                  delete list.ywr;
                  delete list.bdcdjzmh;
                  delete list.result;
                  delete list.createTime;
                  delete list.updateTime;
                  var array = [];
                  for (var key in list) {
                    if (key == 'id') { key = '主键'; list['主键'] = list['id']; }
                    if (key == 'qlr') { key = '权利人'; list['权利人'] = list['qlr']; }
                    if (key == 'bdcdyh') { key = '不动产单元号'; list['不动产单元号'] = list['bdcdyh']; }
                    if (key == 'bdcqzsh') { key = '不动产权利证书'; list['不动产权利证书'] = list['bdcqzsh']; }
                    if (key == 'zl') { key = '坐落位置'; list['坐落位置'] = list['zl']; }
                    if (key == 'mj') { key = '面积'; list['面积'] = list['mj']; }
                    if (key == 'gyqk') { key = '共有情况'; list['共有情况'] = list['gyqk']; }
                    if (key == 'openid') { key = '微信用户ID'; list['微信用户ID'] = list['openid']; }
                    if (key == 'regMortgage') { key = '是否存在抵押信息'; list['是否存在抵押信息'] = list['regMortgage'] == 1?'是':"否"; }
                    if (key == 'regCheck') { key = '是否存在查封信息'; list['是否存在查封信息'] = list['regCheck'] == 1 ? '是' : "否"; }
                    if (key == 'regDissent') { key = '是否存在异议信息'; list['是否存在异议信息'] = list['regDissent'] == 1 ? '是' : "否"; }
                    array.push({ 'text': key, 'type': list[key] });//把得到的数据对象拆分成对象加到数组里面
                  }
                  _that.setData({
                    show: false,
                    listData: array,
                  });
                }else{
                  var fail = data.data.data.entity.result;
                  // 输入信息有误
                  switch (fail) {
                    case 'fail_qlr':
                      wx.showToast({title: '权利人不正确！',icon: 'none'});
                      break;
                    case 'fail_bdcdyh':
                      wx.showToast({ title: '不动产单元号不正确！', icon: 'none' });
                      break;
                    case 'fail_bdcqzsh':
                      wx.showToast({ title: '不动产权证书号不正确！', icon: 'none' });
                      break;
                    case 'fail_zl':
                      wx.showToast({ title: '坐落位置不正确！', icon: 'none' });
                      break;
                    case 'fail_mj':
                      wx.showToast({ title: '面积不正确！', icon: 'none' });
                      break;
                    default:
                      wx.showToast({ title: '共有情况不正确！', icon: 'none' });
                  }
                  _that.setData({
                    show: true,
                  });
                }
              } else {
              wx.showToast({
                title: data.data.data.msg,
                icon: 'none'
              });
              }
            }
          })//ajax end
        }
      // }
    } else {
      wx.showToast({
        title: '验证码输入有误！',
        icon: 'none'
      });
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setStorageSync("subscription_id", options.id);
    wx.setStorageSync("is_subs", false);
    app.subscribe();
    setTimeout(function () {
      that.setData({
        is_subs: wx.getStorageSync('is_subs')
      })
    }, 1600)
  },
  //订阅
  subs: function (e) {
    var that = this;
    app.subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  close_subs: function (e) {
    var that = this;
    app.close_subs_fun();
    setTimeout(function () {
      that.get_sub();
    }, 1200)
  },
  get_sub: function () {
    var that = this;
    that.setData({
      is_subs: wx.getStorageSync('is_subs')
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})