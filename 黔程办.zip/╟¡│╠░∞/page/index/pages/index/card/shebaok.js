Page({
  data: {
    carmessage: {
      name: '',
      idcard: ""
    },
 userInfo:{},
    userMsg: {},
    hidden: true,
    nocancel: false,
  },
  cancel: function () {
    this.setData({
      hidden: true
    });
  },
  close_card: function () {
    this.setData({
      hidden: !this.data.hidden,
    })
  },
  confirm: function () {
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          wxId: userId,
          cardId: 2
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/unbind'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.statusCode == 200) {
          wx.showToast({
            title: '取消成功！',
            icon: 'none'
          });
          setTimeout(function () {
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          }, 1500)
        } else {
          wx.showToast({
            title: '取消失败！',
            icon: 'none'
          });
        }
      }
    })
    that.setData({
      hidden: true
    });
  },
  onLoad: function (options) {
    var that = this;
    that.setData({
      userAddr: options.userAddr,
      userPass: options.userPass
    })
  },
  onShow: function () {
    var that = this;
    var name = wx.getStorageSync('user_name');
    var idcard = wx.getStorageSync('idCardNumber');
    idcard = idcard.replace(/(\w)/g, function (a, b, c, d) { return (c > 4 && c < 10) ? '*' : a });
    var carmessage = {
      name: name,
      idcard: idcard
    }
    this.setData({
      carmessage: carmessage
    })
    that.get_userInfo();
  },
  get_userInfo:function(){
    var that = this;
    var name = wx.getStorageSync('user_name');
    var idCard = wx.getStorageSync('idCardNumber');
    wx.showLoading({title: '查询中',});
    if (that.data.userAddr == '520100'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        // 522427199311297013
        data: {
          'param': JSON.stringify({
            "appid": "cf6dc16744ab4613b871e3745c812ce1",
            "apiu": "GYSRSJSHBXGLXXXT/shbxglxt_grjbxxcxb",
            "paramMap": {
              "SFZHM": idCard
              //"SFZHM": '522427199311297013'
            },
            "apikey": "eb7669c72516fb9a558b6c26d49891d6"
          }),
          'headers': JSON.stringify({
            'apiCode': '100W1376',
            "netType": 1
          }),
          'url': getApp().globalData.sousuo_url + '/postJson'
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.code == 500) {
            wx.showToast({
              title: '请求异常，请稍后重试！',
              icon: 'none'
            });
            return;
          }
          if (data.data.head.code == 200) {
            if (data.data.result.data.items) {
              that.setData({
                userInfo: data.data.result.data.items,
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否开通此业务！',
                icon: 'none'
              });
            }
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否开通此业务！',
              icon: 'none'
            });
          }
        }
      })//ajax end
    }else if (that.data.userAddr == '522300') {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        // 522328196512240424
        data: {
          'param': JSON.stringify({
            'data': 'idCard=' + idCard,
          }),
          'headers': JSON.stringify({
            'apiCode': '100W1115'
          }),
          'url': getApp().globalData.sousuo_url + '/postJson'
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.code == 500) {
            wx.showToast({
              title: '请求异常，请稍后重试！',
              icon: 'none'
            });
            return;
          }
          if (data.data.head.code == 200) {
            if (data.data.result.data.length > 0) {
              that.setData({
                userInfo: data.data.result.data
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否开通此业务！',
                icon: 'none'
              });
            }
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否开通此业务！',
              icon: 'none'
            });
          }
        }
      })//ajax end
    }else{
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        timeOut:5000,
        data: {
          'param':JSON.stringify({
            idCard: idCard, sbPassword: that.data.userPass, addrNo: that.data.userAddr
        }), 'url': 'http://202.98.195.208:83/apiroute/sbFind' },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.statusCode == 200) {
            if (data.data.sbkxx) {
              var list = data.data.sbkxx.body.output.resultset.row;
              that.setData({
                userInfo: list,
                userMsg: data.data.sbxx.body.output.resultset
              })
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否开通此业务！',
                icon: 'none'
              });
            }
          }
        },
        fail:function(){
          wx.showToast({
            title: '请求超时，请稍后重试！',
            icon: 'none'
          });
        }
      })//ajax end
    }
  },
})