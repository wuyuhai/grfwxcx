// pages/index/card/gongjij.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    hidden: true,
    nocancel: false,
    menu: [
      { url: "/page/index/pages/index/fuwu/sousuo/jiashirenxinxi", name: "驾驶证信息", },
      { url: "/page/index/pages/index/fuwu/sousuo/jiashizhengqingfen", name: "驾驶证清分查询", },
      { url: "/page/index/pages/index/fuwu/sousuo/jiashirenjiaotong", name: "驾驶证交通事故查询", },
      { url: "/page/index/pages/index/fuwu/sousuo/jiashirenweifa", name: "驾驶证违法信息", }
    ],
    obj:{
      xm: wx.getStorageSync('user_name'),
      zjcx:'无',
      cclzrq:'xxxx-xx-xx',
      syyxqz: 'xxxx-xx-xx',
      sfzmhm: wx.getStorageSync('idCardNumber').substring(0, 6) + '********' + wx.getStorageSync('idCardNumber').substring(18,14)
    },
    show:false

  },
  close_card: function () {
    this.setData({
      hidden: !this.data.hidden,
    })
  },
  cancel: function () {
    this.setData({
      hidden: true
    });
  },
  confirm: function () {
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          wxId: userId,
          cardId: 3
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/unbind'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.statusCode == 200) {
          wx.showToast({
            title: '取消成功！',
            icon: 'none'
          });
          setTimeout(function () {
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          }, 1500)
        } else {
          wx.showToast({
            title: '取消失败！',
            icon: 'none'
          });
        }
      }
    })
    that.setData({
      hidden: true
    });
  },
  onLoad: function (options) {
    var _that = this;
    wx.showLoading({title: '查询中',});
    wx.request({
      header: {
        'Content-Type': getApp().globalData.contentType,
      },
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: {
        'param': JSON.stringify({
          sfzmhm: wx.getStorageSync('idCardNumber')
        }), 'url': getApp().globalData.sousuo_url + '/driverQuery'
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        wx.hideLoading();
        console.log(data)
        if (data.data.code == 200 && data.data.data.result == '1') {
          var obj = data.data.data.data[0].BasicInformation;
          obj.cclzrq = obj.cclzrq.substr(0, 10);
          obj.syyxqz = obj.syyxqz.substr(0, 10);
          obj.sfzmhm = obj.sfzmhm.substring(0, 6) + '********'+obj.sfzmhm.substring(18, 14);
          _that.setData({
            obj: obj,
            show:true
          })
        }else{
          wx.showToast({
            title: '没有查询到您的驾驶证信息!！',
            icon: 'none'
          });
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})