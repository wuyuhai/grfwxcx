// pages/index/card/gongjij.js
Page({
  data: {
    carmessage:{
      name:'',
      idcard:""
    },
    cancurrients:[],
    userAddr: '522600',
    userInfo:{},
    hidden: true,
    nocancel: false,
  },
  cancel: function () {
    this.setData({
      hidden: true
    });
  },
  confirm: function () {
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          wxId: userId,
          cardId:1
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/unbind'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.statusCode == 200) {
          wx.showToast({
            title: '取消成功！',
            icon: 'none'
          });
          setTimeout(function () {
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          }, 1500)
        } else {
          wx.showToast({
            title: '取消失败！',
            icon: 'none'
          });
        }
      }
    })
    that.setData({
      hidden: true
    });
  },
  onLoad: function (options){
    var that = this;
    that.setData({
      userAddr:options.userAddr
    })
  },
  close_card:function(){
this.setData({
  hidden:!this.data.hidden,
})
  },
  onShow: function () {
    var name = wx.getStorageSync('user_name');
    var idcard = wx.getStorageSync('idCardNumber');
    idcard = idcard.replace(/(\w)/g, function (a, b, c, d) { return (c > 4 && c < 14) ? '*' : a });
    var carmessage = {
      name: name,
      idcard: idcard
    }
    this.setData({
      carmessage:carmessage
    })
    this.getcarmessage();
  },
  getcarmessage:function(){
    var that = this;
    console.log(that.data.userAddr);
    var name = wx.getStorageSync('user_name');
    var idCard = wx.getStorageSync('idCardNumber');
    wx.showLoading({
      title: '查询中',
    });
    if (that.data.userAddr == '520100') {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            data: {
              "appid": "f57a9d7e81c84839873fed3541c41a8a",
              "apiu": "GYSGJJZXGYSZFGJJGLXXXT/GYSGJJZXGYSZFGJJGLXXXTZGJBXX",
              "paramMap": {
                "trantime": "20170111101010",
                "spidno": idCard
              },
              "apikey": "eb7669c72516fb9a558b6c26d49891d6"
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({ 'apiCode': '100W1374', 'netType': '1' })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.body) {
            that.setData({
              userInfo: data.data.result.body.detail,
            })
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
          }
        }
      }) //ajax end
    }else if(that.data.userAddr == '520200'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "head": {
                "appid": "95",
                "transcode": "200020101",
                "trantime": "20110710150312",
                "iseqno": "201107101503120011"
              },
              "body": {
                "head": {
                  // "zjhm": '520202198007035110'
                  "zjhm": idCard
                },
                "list": ""
              }
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({
            "apiCode": "177W1396",
            "netType": "1"
          })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.body.list.acc_info) {
            that.setData({
              userInfo: data.data.result.body.list.acc_info[0]
            })
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
          }
        }
      }) //ajax end
    }else if (that.data.userAddr == '520300') {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "certinum": idCard
              // "certinum": "522101195901182015",
            }
          }), 
          'headers': JSON.stringify({ 'apiCode': '100W1345', 'netType': '1'}),
          'url': getApp().globalData.sousuo_url + '/postJson'
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.data) {
            that.setData({
              userInfo: data.data.result.data
            })
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
          }
        }
      }) //ajax end
    } else if (that.data.userAddr == '522300'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "ffbm": "01",
              "zxbm": "01",
              "jgbm": "01",
              "ywfl": "01",
              "ywlb": "99",
              "khbh": "",
              "zhbh": "",
              "blqd": "zxb",
              "userid": 1,
              "pageIndex": 1,
              "pageSize": 100,
              "value1": idCard,
              // "value1": "522321199309211299",
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({ 'apiCode': '100W1221', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52230" }) })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.data.length > 0) {
            that.setData({
              userInfo: data.data.result.data
            })
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
            that.setData({
              show: true,
            })
          }
        }
      }) //ajax end
    } else if (that.data.userAddr == '522600'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "ffbm": "01",
              "zxbm": "01",
              "jgbm": "01",
              "ywfl": "01",
              "ywlb": "99",
              "khbh": "",
              "zhbh": "",
              "blqd": "zxb",
              "userid": 1,
              "pageIndex": 1,
              "pageSize": 1000,
              "value1": idCard,
              // "value1": "522634196702050019",
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({ 'apiCode': '100W1362', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52260" }) })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.data.length > 0) {
            that.setData({
              userInfo: data.data.result.data
            })
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
            that.setData({
              show: true,
            })
          }
        }
      }) //ajax end
    }else if (that.data.userAddr == '522700'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "ffbm": "01",
              "ffbm": "01",
              "zxbm": "01",
              "jgbm": "01",
              "ywfl": "01",
              "ywlb": "99",
              "khbh": "",
              "zhbh": "",
              "blqd": "zxb",
              "userid": 1,
              "pageIndex": 1,
              "pageSize": 100,
              "value1": idCard,
              // "value1": "522728198704236332",
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({ 'apiCode': '100W1325', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52270" }) })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.data.length > 0) {
            that.setData({
              userInfo: data.data.result.data
            })
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
            that.setData({
              show: true,
            })
          }
        }
      }) //ajax end
    } else if (that.data.userAddr == '520400'){
      // 陈茂森   522426197610202031
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            authName: name,
            authCardNo: idCard
            // authCardNo: '522426197610202031'
          }), 'url': getApp().globalData.sousuo_url + '/anshunPersonalGjj'
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.data.name) {
            that.setData({
              userInfo: data.data.data
            })
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
          }
        }
      }) //ajax end
    } else if (that.data.userAddr == '520600'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "ffbm": "01",
              "zxbm": "01", "jgbm": "01", "ywfl": "01", "ywlb": "99", "khbh": "", "zhbh": "", "blqd": "zxb", "userid": 1, "pageIndex": 1, "pageSize": 10,
              "value1": idCard,
              // "value1": "522226198403234018",
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({ 'apiCode': '100W1211', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52220" }) })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.head.code == 200 && data.data.result.data.length > 0) {
            that.setData({
              userInfo: data.data.result.data[0]
            })
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
          }
        }
      }) //ajax end
    } else if (that.data.userAddr == '520555') {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            data: {
              extParam: {
              }
            }
          }),
          'headers': JSON.stringify({
            'apiCode': '100W1365',
            'netType': '1'
          }),
          'url': getApp().globalData.sousuo_url + '/postJson'
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data)
          if (data.data.result.code == 200) {
            var body = data.data.result.data;
            wx.request({
              url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
              header: {
                'Content-Type': getApp().globalData.contentType
              },
              data: {
                'param': JSON.stringify({
                  'data': {
                    "extParam": {
                      "dwzh": "",
                      "page": 1,
                      "currentPage": 1,
                      "grzh": "",
                      "xingming": "",
                      "zjhm": idCard,
                      // "zjhm": "522527200006260055",
                      "grzhzt": ""
                    },
                    "qqly": 20
                  }
                }),
                'headers': JSON.stringify({
                  "apiCode": "100W1144",
                  "netType": "1", "ispToken": body
                }),
                'url': getApp().globalData.sousuo_url + '/postJson'
              },//实际调用接口
              method: 'post',
              dataType: 'json',
              success: function (data) {
                wx.hideLoading();
                console.log(data);
                if (!data.data.result.success) {
                  wx.showToast({
                    title: 'token失效！',
                    icon: 'none'
                  });
                  return;
                }
                if (data.data.code == 500) {
                  wx.showToast({
                    title: '请求异常，请稍后重试！',
                    icon: 'none'
                  });
                  return;
                }
                if (data.data.head.code == 200 && data.data.result.list.length > 0) {
                  that.setData({
                    userInfo: data.data.result.list[0]
                  })
                  var dwzh = that.data.obj.dwzh, grzh = that.data.obj.grzh;
                  wx.request({
                    url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
                    header: {
                      'Content-Type': getApp().globalData.contentType
                    },
                    data: {
                      'param': JSON.stringify({
                        'data': {
                          "extParam": {
                            "dwzh": "",
                            "grzh": grzh,
                            "page": 1,
                            "currentPage": 1
                          },
                          "qqly": 20
                        }
                      }),
                      'headers': JSON.stringify({
                        "apiCode": "100W1145",
                        "netType": 1, "ispToken": body
                      }),
                      'url': getApp().globalData.sousuo_url + '/postJson'
                    },//实际调用接口
                    method: 'post',
                    dataType: 'json',
                    success: function (data) {
                      console.log(data);
                      if (data.data.result.success) {
                        that.setData({
                          obj2: JSON.parse(data.data.result.body).list[0]
                        })
                      }
                    }
                  }) //ajax end
                } else {
                  wx.showToast({
                    title: '没有查到数据，请检查输入或是否有办理业务！',
                    icon: 'none'
                  });
                  that.setData({
                    show: true,
                  })
                }
              }
            }) //ajax end
          } else {
            wx.showToast({
              title: '获取token失败！',
              icon: 'none'
            });
          }
        }
      })
    } else if (that.data.userAddr == '520300'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              // "certinum": idCard
              "certinum": "522101195901182015",
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({
            "apiCode": "100W1345",
						"netType": "1"
            })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          // if (data.data.head.code == 200 && data.data.result.data.length > 0) {
          //   that.setData({
          //     userInfo: data.data.result.data[0]
          //   })
          // } else {
          //   wx.showToast({
          //     title: '没有查到数据，请检查输入或是否有办理业务！',
          //     icon: 'none'
          //   });
          // }
        }
      }) //ajax end
    }else{
      wx.hideLoading();
      wx.showToast({
        title: '请求异常，请稍后重试！',
        icon: 'none'
      });
    }
    // 
  },
})