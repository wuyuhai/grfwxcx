// pages/index/card/gongjij.js
Page({
  data: {
    idcard:'',
    carmessage:{
      name:'',
      idcard:""
    },
    userAddr:0,
    show:false,
    array: ['贵阳市', '六盘水市', '遵义市', '安顺市', '毕节市', '铜仁市', '黔西南布依族苗族自治州', '黔东南苗族侗族自治州', '黔南布依族苗族自治州','贵安新区'],
    array2: ['520100', '520200', '520300', '520400', '520500', '520600', '522300', '522600', '522700','520555'],

    index: 0, 
  },
  bindPickerChange: function (e) {
    console.log(e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  add_crad:function(){
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          wxId: userId,
          cardId: 1,
          userData: 'userAddr=' + that.data.userAddr,
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/bind'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.ok) {
          wx.showToast({
            title: '添加成功！',
            icon: 'none'
          });
          setTimeout(function(){
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          },1200)
        }else{
          wx.showToast({
            title: '添加失败！',
            icon: 'none'
          });
        }
      }
    })
  },
  formSubmit: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    var that = this;
    var userAddr = e.detail.value.regionId;
    var idCard = e.detail.value.idcard;
    that.setData({
      userAddr: userAddr
    })
    wx.showLoading({
      title: '查询中',
    });
    if (userAddr == '520100') {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            data: {
              "appid": "f57a9d7e81c84839873fed3541c41a8a",
              "apiu": "GYSGJJZXGYSZFGJJGLXXXT/GYSGJJZXGYSZFGJJGLXXXTZGJBXX",
              "paramMap": {
                "trantime": "20170111101010",
                "spidno": idCard
              },
              "apikey": "eb7669c72516fb9a558b6c26d49891d6"
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({ 'apiCode': '100W1374', 'netType': '1' })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.body) {
            that.add_crad();
          } else {
            wx.showToast({
              title: '没有查到数据，请检查是否有办理业务！',
              icon: 'none'
            });
          }
        }
      }) //ajax end
    }else if(userAddr=='520200'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "head": {
                "appid": "95",
                "transcode": "200020101",
                "trantime": "20110710150312",
                "iseqno": "201107101503120011"
              },
              "body": {
                "head": {
                  // "zjhm": '520202198007035110'
                  "zjhm": idCard
                },
                "list": ""
              }
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({
            "apiCode": "177W1396",
            "netType": "1"
          })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.body.list.acc_info) {
            that.add_crad();
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
          }
        }
      }) //ajax end
    }else if (userAddr == '520300') {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "certinum": idCard
              // "certinum": "522101195901182015",
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({
            "apiCode": "100W1345",
            "netType": "1"
          })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.data) {
            that.add_crad();
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
          }
        }
      }) //ajax end
    }else if (userAddr == '520400') {
      // 陈茂森   522426197610202031
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            authName: name,
            authCardNo: idCard
            // authCardNo: '522426197610202031'
          }), 'url': getApp().globalData.sousuo_url + '/anshunPersonalGjj'
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.data.name) {
            that.add_crad();
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
          }
        }
      }) //ajax end
    }else if(userAddr=='520555'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            data: {
              extParam: {
              }
            }
          }),
          'headers': JSON.stringify({
            'apiCode': '100W1365',
            'netType': '1'
          }),
          'url': getApp().globalData.sousuo_url + '/postJson'
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data)
          if (data.data.result.code == 200) {
            var body = data.data.result.data;
            wx.request({
              url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
              header: {
                'Content-Type': getApp().globalData.contentType
              },
              data: {
                'param': JSON.stringify({
                  'data': {
                    "extParam": {
                      "dwzh": "",
                      "page": 1,
                      "currentPage": 1,
                      "grzh": "",
                      "xingming": "",
                      "zjhm": idCard,
                      // "zjhm": "522527200006260055",
                      "grzhzt": ""
                    },
                    "qqly": 20
                  }
                }),
                'headers': JSON.stringify({
                  "apiCode": "100W1144",
                  "netType": "1", "ispToken": body
                }),
                'url': getApp().globalData.sousuo_url + '/postJson'
              },//实际调用接口
              method: 'post',
              dataType: 'json',
              success: function (data) {
                wx.hideLoading();
                console.log(data);
                if (!data.data.result.success) {
                  wx.showToast({
                    title: 'token失效！',
                    icon: 'none'
                  });
                  return;
                }
                if (data.data.code == 500) {
                  wx.showToast({
                    title: '请求异常，请稍后重试！',
                    icon: 'none'
                  });
                  return;
                }
                if (data.data.head.code == 200 && data.data.result.list.length > 0) {
                  that.add_crad();
                } else {
                  wx.showToast({
                    title: '没有查到数据，请检查输入或是否有办理业务！',
                    icon: 'none'
                  });
                }
              }
            }) //ajax end
          } else {
            wx.showToast({
              title: '获取token失败！',
              icon: 'none'
            });
          }
        }
      })
    } else if (userAddr == '520600') {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "ffbm": "01",
              "zxbm": "01", "jgbm": "01", "ywfl": "01", "ywlb": "99", "khbh": "", "zhbh": "", "blqd": "zxb", "userid": 1, "pageIndex": 1, "pageSize": 10,
              "value1": idCard,
              // "value1": "522226198403234018",
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({ 'apiCode': '100W1211', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52220" }) })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.head.code == 200 && data.data.result.data.length > 0) {
            that.add_crad();
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
          }
        }
      }) //ajax end
    }else if(userAddr == '522300'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "ffbm": "01",
              "zxbm": "01",
              "jgbm": "01",
              "ywfl": "01",
              "ywlb": "99",
              "khbh": "",
              "zhbh": "",
              "blqd": "zxb",
              "userid": 1,
              "pageIndex": 1,
              "pageSize": 100,
              "value1": idCard,
              // "value1": "522321199309211299",
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({ 'apiCode': '100W1221', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52230" }) })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.data.length > 0) {
            that.add_crad();
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
            that.setData({
              show: true,
            })
          }
        }
      }) //ajax end
    } else if (userAddr == '522600'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "ffbm": "01",
              "zxbm": "01",
              "jgbm": "01",
              "ywfl": "01",
              "ywlb": "99",
              "khbh": "",
              "zhbh": "",
              "blqd": "zxb",
              "userid": 1,
              "pageIndex": 1,
              "pageSize": 1000,
              "value1": idCard,
              // "value1": "522634196702050019",
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({ 'apiCode': '100W1362', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52260" }) })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.data.length > 0) {
            that.add_crad();
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
            that.setData({
              show: true,
            })
          }
        }
      }) //ajax end
    }else if(userAddr == '522700'){
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            'data': {
              "ffbm": "01",
              "ffbm": "01",
              "zxbm": "01",
              "jgbm": "01",
              "ywfl": "01",
              "ywlb": "99",
              "khbh": "",
              "zhbh": "",
              "blqd": "zxb",
              "userid": 1,
              "pageIndex": 1,
              "pageSize": 100,
              "value1": idCard,
              // "value1": "522728198704236332",
            }
          }), 'url': getApp().globalData.sousuo_url + '/postJson',
          'headers': JSON.stringify({ 'apiCode': '100W1325', 'netType': '1', "usr": JSON.stringify({ "zjbzxbm": "C52270" }) })
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.data.length > 0) {
            that.add_crad();
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
            that.setData({
              show: true,
            })
          }
        }
      }) //ajax end
    } else if (userAddrr == '520555') {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          'param': JSON.stringify({
            data: {
              extParam: {
                'zjhm': idCard,
                // 'zjhm':'520181200006023353'
              }
            }
          }),
          'headers': JSON.stringify({
            'apiCode': '100W1144'
          }),
          'url': getApp().globalData.sousuo_url + '/postJson'
        },//实际调用接口
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.code == 500) {
            wx.showToast({
              title: '请求异常，请稍后重试！',
              icon: 'none'
            });
            return;
          }
          if (data.data.head.code == 200 && data.data.result.list.length > 0) {
            that.setData({
              userInfo: data.data.result.list[0]
            })
            var dwzh = that.data.obj.dwzh, grzh = that.data.obj.grzh;
            wx.request({
              url: getApp().globalData.url + 'requestDelegate/handle',//查询公用后台接口
              header: {
                'Content-Type': getApp().globalData.contentType
              },
              data: {
                'param': JSON.stringify({
                  data: {
                    extParam: {
                      'dwzh': dwzh,
                      'grzh': grzh,
                      'page': 0,
                      'currentPage': 0,
                      'qqly': 22
                    }
                  }
                }),
                'headers': JSON.stringify({
                  'apiCode': '100W1145'
                }),
                'url': getApp().globalData.sousuo_url + '/postJson'
              },//实际调用接口
              method: 'post',
              dataType: 'json',
              success: function (data) {
                console.log(data);
                if (data.data.head.code == 200 && data.data.result.list.length > 0) {
                  that.setData({
                    obj2: data.data.result.list[0]
                  })
                }
              }
            }) //ajax end
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否有办理业务！',
              icon: 'none'
            });
          }
        }
      }) //ajax end
    } else {
      wx.hideLoading();
      wx.showToast({
        title: '没有您选择的地区！',
        icon: 'none'
      });
    }
    // 
  },
  guanlian:function(){
this.setData({
  show:!this.data.show,
})
  },
  onLoad: function (options){
    var that = this;
    // console.log(options.userAdd);
  },
  onShow: function () {
    var name = wx.getStorageSync('user_name');
    var idcard = wx.getStorageSync('idCardNumber');
    idcard = idcard.replace(/(\w)/g, function (a, b, c, d) { return (c > 4 && c < 14) ? '*' : a });
    var carmessage = {
      name: name,
      idcard: idcard
    }
    this.setData({
      carmessage:carmessage,
      idcard: wx.getStorageSync('idCardNumber')
    })
  },
})