// pages/index/card/card_more.js
Page({
  data: {
    carmessage:{
      name: '',
      idcard: ''
    },
    card_arr:[]
  },
  onLoad: function (options) {
    var name = wx.getStorageSync('user_name');
    var idcard = wx.getStorageSync('idCardNumber');
    idcard = idcard.substring(0, 6) + "********" + idcard.substring(18, 14);
    var carmessage = {
      name: name,
      idcard: idcard
    }
    this.setData({
      carmessage: carmessage
    })
  },
  onShow: function () {
    var that = this;
    that.getAllCard();
  },
  getAllCard:function(){
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          wxId: userId
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/findAll'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.statusCode==200){
          var data = data.data.obj;
          for (var i = 0; i < data.length; i++) {
            data[i].remark = JSON.parse(data[i].remark);
          }
          that.setData({
            card_arr: data,
          })
        }else{
          wx.showToast({
            title: '请求出错，请稍后重试！',
            icon: 'none'
          })
        }
      }
    })
  },
})