// pages/index/card/gongjij.js
Page({

  data: {
    array: ['贵阳市', '六盘水市', '遵义市', '安顺市', '毕节市', '铜仁市','黔西南布依族苗族自治州', '黔东南苗族侗族自治州', '黔南布依族苗族自治州'],
    array2: ['520100', '520200', '520300', '520400', '520500', '520600', '522300', '522600', '522700'],

    index:0, 
  },

  onLoad: function (options) {

  },

  bindPickerChange: function (e) {
    console.log(e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },

  formSubmit: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    if (e.detail.value.personalNum == ""){
      wx.showToast({
        title: '请输入证卡密码',
        icon:'none'
      })
      return
    }
    var data = {
      userType: wx.getStorageSync('uType'),
      cardId:2,
      cardNum: wx.getStorageSync('idCardNumber'),
      password: e.detail.value.password ,
      regionId: e.detail.value.regionId,
      userId: wx.getStorageSync('id'),
    }
    wx.request({
      url: getApp().globalData.url + 'cards/addSSCard', 
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: data,
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if(data.data.code==200){
          wx.showToast({
            title: '社保卡关联成功',
            icon:'none',
          })
          wx.navigateBack({
            delta:1
          })
        } else if (data.data.code == 400){
          wx.showToast({
            title: data.data.msg,
            icon: 'none',
          })
        }else{
          wx.showToast({
            title: '系统繁忙',
            icon: 'none',
          })
        }
      }
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})