// pages/index/card/gongjij.js
Page({
  data: {
    carmessage: {
      name: '',
      idcard: ""
    },
    show:false,
    userAddr: 0,
    show: false,
    array: ['省级', '贵阳市', '六盘水市', '遵义市', '安顺市', '毕节市', '铜仁市', '黔西南布依族苗族自治州', '黔东南苗族侗族自治州', '黔南布依族苗族自治州'],
    array2: ['529900','520100', '520200', '520300', '520400', '520500', '520600', '522300', '522600', '522700'],
    index: 0, 
  },
  bindPickerChange: function (e) {
    console.log(e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  guanlian: function () {
    this.setData({
      show: !this.data.show,
    })
  },
  onShow: function () {
    var name = wx.getStorageSync('user_name');
    var idcard = wx.getStorageSync('idCardNumber');
    idcard = idcard.replace(/(\w)/g, function (a, b, c, d) { return (c > 4 && c < 14) ? '*' : a });
    var carmessage = {
      name: name,
      idcard: idcard
    }
    this.setData({
      carmessage: carmessage
    })
  },
  formSubmit: function (e) {
console.log(e);
    if (e.detail.value.idcard==""){
      wx.showToast({
        title: '请输入密码！',
        icon: 'none'
      });
      return;
    }
    var that =this;
    that.setData({
      userAddr: e.detail.value.regionId,
      userPass: e.detail.value.idcard,
    })
    wx.showLoading({title: '查询中',});
    var idcard=wx.getStorageSync('idCardNumber');
    if (e.detail.value.regionId == '520100') {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        // 522427199311297013
        data: {
          'param': JSON.stringify({
            "appid": "cf6dc16744ab4613b871e3745c812ce1",
            "apiu": "GYSRSJSHBXGLXXXT/shbxglxt_grjbxxcxb",
            "paramMap": {
              "SFZHM": idcard
              //"SFZHM": '522427199311297013'
            },
            "apikey": "eb7669c72516fb9a558b6c26d49891d6"
          }),
          'headers': JSON.stringify({
            'apiCode': '100W1376',
            "netType": 1
          }),
          'url': getApp().globalData.sousuo_url + '/postJson'
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.code == 500) {
            wx.showToast({
              title: '请求异常，请稍后重试！',
              icon: 'none'
            });
            return;
          }
          if (data.data.head.code == 200) {
            if (data.data.result.data.items) {
              that.add_crad();
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否开通此业务！',
                icon: 'none'
              });
            }
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否开通此业务！',
              icon: 'none'
            });
          }
        }
      })//ajax end
    } else if (e.detail.value.regionId == '522300') {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        // 522328196512240424
        data: {
          'param': JSON.stringify({
            'data': 'idCard=' +idcard,
          }),
          'headers': JSON.stringify({
            'apiCode': '100W1115'
          }),
          'url': getApp().globalData.sousuo_url + '/postJson'
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.hideLoading();
          console.log(data);
          if (data.data.result.code == 500) {
            wx.showToast({
              title: '请求异常，请稍后重试！',
              icon: 'none'
            });
            return;
          }
          if (data.data.head.code == 200) {
            if (data.data.result.data.length > 0) {
              that.add_crad();
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否开通此业务！',
                icon: 'none'
              });
            }
          } else {
            wx.showToast({
              title: '没有查到数据，请检查输入或是否开通此业务！',
              icon: 'none'
            });
          }
        }
      })//ajax end
    } else {
      wx.request({
        url: getApp().globalData.url + 'requestDelegate/handle',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: { 'param': JSON.stringify({ idCard: idcard, sbPassword: e.detail.value.idcard, addrNo: e.detail.value.regionId }), 'url': 'http://202.98.195.208:83/apiroute/sbFind' },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data);
          wx.hideLoading();
          if (data.statusCode == 200) {
            if (data.data.sbkxx) {
              that.add_crad();
            } else {
              wx.showToast({
                title: '没有查到数据，请检查输入或是否开通此业务！',
                icon: 'none'
              });
            }
          }
        }
      })//ajax end
    }
  },
  add_crad: function () {
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          wxId: userId,
          cardId: 2,
          userData: 'userAddr=' + that.data.userAddr + '&userPass='+that.data.userPass,
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/bind'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.ok) {
          wx.showToast({
            title: '添加成功！',
            icon: 'none'
          });
          setTimeout(function () {
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          }, 1200)
        } else {
          wx.showToast({
            title: '添加失败！',
            icon: 'none'
          });
        }
      }
    })
  },
})