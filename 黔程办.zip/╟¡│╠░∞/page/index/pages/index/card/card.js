// pages/index/banshi_sx.js
Page({
  data: {
    carmessage: {
      name: '',
      idcard: ""
    },
    obj: {},
    hidden: true,
    nocancel: false,
    id:0,
  },
  cancel: function () {
    this.setData({
      hidden: true
    });
  },
  confirm: function () {
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          wxId: userId,
          cardId: that.data.id
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/unbind'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.statusCode == 200) {
          wx.showToast({
            title: '取消成功！',
            icon: 'none'
          });
          that.getmycards();
        } else {
          wx.showToast({
            title: '取消失败！',
            icon: 'none'
          });
        }
      }
    })
    that.setData({
      hidden: true
    });
  },
  close_card: function (e) {
    console.log(e.currentTarget.dataset.id);
    this.setData({
      hidden: !this.data.hidden,
      id: e.currentTarget.dataset.id
    })
  },
  onLoad: function (options) {
    var _that = this;
    var name = wx.getStorageSync('user_name');
    var idcard = wx.getStorageSync('idCardNumber');
    idcard = idcard.substring(0, 6) + "********"+idcard.substring(18, 14);
    var carmessage = {
      name: name,
      idcard: idcard
    }
    this.setData({
      carmessage: carmessage,
    })
  },
  onShow: function () {
    var that = this;
    that.getmycards();
  },
  getmycards: function () {
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          wxId: userId
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/findByWxId'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.obj) {
          var data = data.data.obj;
          for (var i = 0; i < data.length; i++) {
            data[i].remark = JSON.parse(data[i].remark);
            // data[i].userData = JSON.parse(data[i].userData);
          }
          that.setData({
            card_arr: data,
          })
        }
      }
    })
  },
})
