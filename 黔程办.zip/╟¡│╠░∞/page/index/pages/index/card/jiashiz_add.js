// pages/index/card/gongjij.js
Page({
  data: {
    carmessage: {
      name: '',
      idcard: ""
    },
    show:false,
    userAddr: 0,
    show: false,
  },
  guanlian: function () {
    this.setData({
      show: !this.data.show,
    })
  },
  onShow: function () {
    var name = wx.getStorageSync('user_name');
    var idcard = wx.getStorageSync('idCardNumber');
    idcard = idcard.replace(/(\w)/g, function (a, b, c, d) { return (c > 4 && c < 14) ? '*' : a });
    var carmessage = {
      name: name,
      idcard: idcard
    }
    this.setData({
      carmessage: carmessage,
      idcard: wx.getStorageSync('idCardNumber')
    })
  },
  formSubmit: function (e) {
    var that = this;
    wx.showLoading({
      title: '查询中',
    });
    wx.request({
      header: {
        'Content-Type': getApp().globalData.contentType,
      },
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: {
        'param': JSON.stringify({
          sfzmhm: wx.getStorageSync('idCardNumber')
        }), 'url': getApp().globalData.sousuo_url + '/driverQuery'
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        wx.hideLoading();
        console.log(data);
        if (data.data.code == 200 && data.data.data.result == '1') {
          that.add_crad();
        }else{
          wx.showToast({
            title: '没有查询到您的驾驶证信息，无法关联！',
            icon: 'none'
          });
        }
      }
    })
  },
  add_crad: function () {
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          wxId: userId,
          cardId: 3,
          userData: 'userAddr=520100',
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/bind'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.ok) {
          wx.showToast({
            title: '添加成功！',
            icon: 'none'
          });
          setTimeout(function () {
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          }, 1200)
        } else {
          wx.showToast({
            title: '添加失败！',
            icon: 'none'
          });
        }
      }
    })
  },
})