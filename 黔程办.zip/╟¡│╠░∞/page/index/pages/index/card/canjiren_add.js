// pages/index/card/gongjij.js
Page({
  data: {
    carmessage: {
      name: '',
      idcard: ""
    },
    show:false,
    userAddr: 0,
    show: false,
    name: '',

  },
  guanlian: function () {
    this.setData({
      show: !this.data.show,
    })
  },
  input_str: function (e) { this.setData({ name: e.detail.value }) },
  onShow: function () {
    var name = wx.getStorageSync('user_name');
    var idcard = wx.getStorageSync('idCardNumber');
    idcard = idcard.replace(/(\w)/g, function (a, b, c, d) { return (c > 4 && c < 14) ? '*' : a });
    var carmessage = {
      name: name,
      idcard: idcard
    }
    this.setData({
      carmessage: carmessage,
      idcard: wx.getStorageSync('idCardNumber'),
      name: wx.getStorageSync('user_name'),
    })
  },
  formSubmit: function (e) {
    var that = this;
    if (that.data.name==''){
      wx.showToast({
        title: '请输入关联人姓名！',
        icon: 'none'
      });
      return;
    }
    wx.showLoading({
      title: '查询中',
    });
    // name: '谭义黔',
    // 	idCard:'52212119771112007X'
    wx.request({
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: { 'param': JSON.stringify({
        "name":that.data.name,
        "idCard": wx.getStorageSync('idCardNumber'),
        // "name": '谭义黔',
        // "idCard": '52212119771112007X'
      }), 'url': getApp().globalData.sousuo_url + '/cj/queryBuIdcardAndName' },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        wx.hideLoading();
        console.log(data);
        if (data.data.code == 501) {
          wx.showToast({ title: '没有查到数据，请检查输入或是否开通此业务！', icon: 'none' });
          that.setData({ show: true, })
          return;
        }
        if (data.data.code == 200 && data.data.data != null) {
          that.add_crad();
        } else {
          wx.showToast({ title: '没有查到数据，请检查输入或是否开通此业务！', icon: 'none' });
        }
      }
    })//ajax end
  },
  add_crad: function () {
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          wxId: userId,
          cardId: 4,
          userData: 'name='+that.data.name,
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/bind'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.ok) {
          wx.showToast({
            title: '添加成功！',
            icon: 'none'
          });
          setTimeout(function () {
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          }, 1200)
        } else {
          wx.showToast({
            title: '添加失败！',
            icon: 'none'
          });
        }
      }
    })
  },
})