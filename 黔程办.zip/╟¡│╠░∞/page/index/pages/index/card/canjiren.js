// pages/index/card/gongjij.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    hidden: true,
    nocancel: false,
    obj:{
      name: wx.getStorageSync('user_name'),
      disabledNumber:'----------',
      stime: '****-**-**',
      etime:'****-**-**',
      idcard: wx.getStorageSync('idCardNumber').substring(0, 6) + '********' + wx.getStorageSync('idCardNumber').substring(18, 14),
      state:99,
      disabledType:99,
    },
    show:false
  },
  close_card: function () {
    this.setData({
      hidden: !this.data.hidden,
    })
  },
  cancel: function () {
    this.setData({
      hidden: true
    });
  },
  confirm: function () {
    var that = this;
    var userId = wx.getStorageSync("wxId");
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          wxId: userId,
          cardId: 4
        }), 'url': 'http://202.98.195.208:82/unified_management/xcxCard/unbind'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.statusCode == 200) {
          wx.showToast({
            title: '取消成功！',
            icon: 'none'
          });
          setTimeout(function () {
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          }, 1500)
        } else {
          wx.showToast({
            title: '取消失败！',
            icon: 'none'
          });
        }
      }
    })
    that.setData({
      hidden: true
    });
  },
  onLoad: function (options) {
    var that = this;
    wx.showLoading({title: '查询中',});
    wx.request({
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: {
        'param': JSON.stringify({
          "name":options.name,
          "idCard": wx.getStorageSync('idCardNumber'),
          // "name": '谭义黔',
          // "idCard": '52212119771112007X'
        }), 'url': getApp().globalData.sousuo_url + '/cj/queryBuIdcardAndName'
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        wx.hideLoading();
        console.log(data);
        if (data.data.code == 501) {
          wx.showToast({ title: '没有查到数据，请检查输入或是否开通此业务！', icon: 'none' });
          that.setData({ show: true, })
          return;
        }
        if (data.data.code == 200 && data.data.data != null) {
          data.data.data.stime = data.data.data.stime.substring(0, 10);
          data.data.data.etime = data.data.data.etime.substring(0, 10);
          data.data.data.idcard = data.data.data.idcard.substring(0, 6) + '********' + data.data.data.idcard.substring(18, 14);
          that.setData({
            obj: data.data.data
          })
        } else {
          wx.showToast({ title: '没有查到数据，请检查输入或是否开通此业务！', icon: 'none' });
        }
      }
    })//ajax end
  },
})