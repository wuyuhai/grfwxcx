 // pages/index/fuwu/shebcx.js
 Page({

   /**
    * 页面的初始数据 
    */
   data: {
     keyType: '1', //1代表用户账号。2代表社会信用代码
     wxId: '',
     str1: '', 
     str2: '',
     phone: '',
     login_name: ''
   },
   input_str: function(e) {
     var that = this;
     this.setData({
       str1: e.detail.value
     })
     var dw_str = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/; //身份证
     var dw_str2 = /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/; //手机号
     if (dw_str.test(that.data.str1)) {
       //匹配到是社会信用代码
       that.setData({
         keyType: '3'
       })
     } else if (dw_str2.test(that.data.str1)) {
       that.setData({
         keyType: '2'
       })
     } else {
       that.setData({
         keyType: '1'
       })
     }
   },
   input_str2: function(e) {
     this.setData({
       str2: e.detail.value
     })
   },
   formSubmit: function(e) {
     var that = this;
     // 验证码输入正确时的操作
     if (that.data.str1 == '') {
       wx.showToast({
         title: '请输入用户名或手机号或身份证！',
         icon: 'none'
       });
     } else if (that.data.str2 == '') {
       wx.showToast({
         title: '请输入密码！',
         icon: 'none'
       });
     } else {
       wx.showLoading({
         title: '登录中',
       })
       console.log('form发生了submit事件，携带数据为：', e.detail.value);
       wx.request({
         // url: 'http://202.98.195.208:83/IntegratedQuery/realPropertyCertificate',
         // account: oyc
         // password: 123456
         url: getApp().globalData.url + '/user/getUserInfo',
         header: {
           'Content-Type': getApp().globalData.contentType
         },
         data: e.detail.value,
         method: 'post',
         dataType: 'json',
         success: function(data) {
           console.log(data);
           if (data.data.code == 200) {
             wx.hideLoading();
             wx.setStorageSync("token", data.data.data.token);
             wx.setStorageSync("wxId", data.data.data.wx_id);
             wx.setStorageSync("login_name", data.data.data.LOGIN_NAME);
             wx.setStorageSync("user_name", data.data.data.USER_NAME);
             wx.setStorageSync("user_mobile", data.data.data.MOBILE);
             wx.setStorageSync("id", data.data.data.id);
             wx.setStorageSync("user_id", data.data.data.USER_ID);
             wx.setStorageSync("uType", 0);
            
             if (data.data.data.CARD_TYPE == '111') {
               wx.setStorageSync("idCardNumber", data.data.data.CARD_NO);
              //  if (!wx.getStorageSync('hadyzname')) {            
               if (!data.data.data.user_real_auth){
                 wx.setStorageSync('hadyzname', false)
                 wx.showModal({
                   title: '提示',
                   content: '当前用户未实名，请跳转到刷脸识别进行实名验证',
                   cancelText: "推迟",
                   confirmText: '去实名',
                   success: function (res) {
                     if (res.confirm) {
                       wx.navigateTo({
                         url: '/page/home/pages/home/login/face?oop=true',
                       })
                       return
                     } else if (res.cancel) {
                       wx.switchTab({
                         url: '/page/tabBar/index/index',
                       })
                     }
                   }
                 })
                 return
                 var data = {
                   "username": data.data.data.USER_NAME,
                   "cardNum": data.data.data.CARD_NO,
                 }
                 data = {
                   'param': JSON.stringify(data),
                   'url': 'http://172.16.22.187:83/IntegratedQuery/realUserCheck',
                 }
                 wx.request({
                   url: getApp().globalData.url + 'requestDelegate/handle',
                   header: {
                     'Content-Type': getApp().globalData.contentType
                   },
                   data: data,
                   method: 'post',
                   dataType: 'json',
                   success: function (data) {
                     console.log(data)
                     if (data.data.code == 200) {
                       if (data.data.msg == "实名校检通过") {
                         wx.setStorageSync('hadyzname', true)
                         wx.switchTab({
                           url: '/page/tabBar/index/index',
                         })
                       }
                     } else if (data.data.code == 400) {
                       //未实名     
                       wx.setStorageSync('hadyzname', false)
                       wx.showModal({
                         title: '提示',
                         content: '当前用户未实名，请跳转到刷脸识别进行实名验证',
                         cancelText: "推迟",
                         confirmText: '去实名',
                         success: function (res) {
                           if (res.confirm) {
                             wx.navigateTo({
                               url: '/page/home/pages/home/login/face?oop=true',
                             })
                             return
                           } else if (res.cancel) {
                             wx.switchTab({
                               url: '/page/tabBar/index/index',
                             })
                           }
                         }
                       })
                     } else {
                       wx.switchTab({
                         url: '/page/tabBar/index/index',
                       })
                     }
                   }
                 })
               }else{
                 wx.setStorageSync('hadyzname', true)
                 wx.switchTab({
                   url: '/page/tabBar/index/index',
                 })
               }          
             }else{
               wx.switchTab({
                 url: '/page/tabBar/index/index',
               })
             }
           } else {
             wx.showToast({
               title: data.data.msg,
               icon: 'none'
             });
           }
         },
         fail: function() {
           wx.showToast({
             title: '登录失败，请检查网络连接！',
             icon: 'none'
           });
         }
       }) //ajax end
     }
   },

   onLoad: function(options) {
     this.setData({
       wxId: wx.getStorageSync("wxId"),
     })
   },
   onShow: function() {
     this.setData({
       wxId: wx.getStorageSync("wxId"),
       phone: wx.getStorageSync("phone"),
       str1: wx.getStorageSync("login_name") ? wx.getStorageSync("login_name") : "",
     });
   },
 })