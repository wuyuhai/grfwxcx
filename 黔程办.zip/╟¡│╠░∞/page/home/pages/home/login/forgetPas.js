// pages/index/fuwu/shebcx.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    unionKey:'',
    Utype:'user',
    show:true,
    time:60,
    loginName:'',
    newPassword:'',
    password2:'',
  },
  input_str: function (e) {
    this.setData({
      unionKey: e.detail.value
    })
  },
  input_str2: function (e) {
    this.setData({
      loginName: e.detail.value
    })
  },
  input_str3: function (e) {
    this.setData({
      newPassword: e.detail.value
    })
  },
  input_str4: function (e) {
    this.setData({
      password2: e.detail.value
    })
  },
  changeCode: function () {
    var _that = this;
    var subFunc = function(){
      wx.showLoading({
        title: '验证码发送中',
      })
      wx.request({
        url: getApp().globalData.url + 'user/forgetPassword',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: { unionKey: _that.data.unionKey, userType: _that.data.Utype },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data);
          wx.hideLoading();
          if (data.data.code == 200) {
            wx.showToast({
              title: '验证码已发送至' + data.data.data.mobile,
              icon: 'none'
            });
            _that.setData({
              show: false,
              loginName: data.data.data.loginName,
            });
            var func1 = setInterval(function () {//定时器
              if (_that.data.time != 0) {
                setTimeout(function () {
                  _that.setData({
                    time: _that.data.time - 1,
                  })
                }, 1000)
              } else {
                _that.setData({
                  time: 60,
                  show: true,
                })
                clearInterval(func1);
              }
            }, 1000)
          } else {
            wx.showToast({
              title: data.data.msg,
              icon: 'none'
            });
          }
        }
      }) //ajax end
    }
    // var dw_str = /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/;
    var dw_str = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;
    var dw_str2 = /^[A-Za-z0-9]+$/;
    if (_that.data.unionKey == '') {
      wx.showToast({
        title: '请输入证件证号！',
        icon: 'none'
      });
    } else {
      if (_that.data.Utype == 'user'){
        if (dw_str.test(_that.data.unionKey)) {
          subFunc();
        }else{
          wx.showToast({
            title: '请输入正确的身份证号！',
            icon: 'none'
          });
        }
      }else{
        console.log('社会人')
        if (dw_str2.test(_that.data.unionKey)) {
          console.log('社会人验证成功')
          subFunc();
        } else {
          wx.showToast({
            title: '请输入正确的社会信用代码！',
            icon: 'none'
          });
        }
      }
    }
  },
  formSubmit: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    var that = this;
    // var dw_str = /^(13[0-9]|14[579]|15[0-3,5-9]|16[6]|17[0135678]|18[0-9]|19[89])\d{8}$/;
    var dw_str = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;    
    if (dw_str.test(that.data.unionKey)){
      // if(that.data.loginName == ''){
      //   wx.showToast({ title: '请输入修改密码的用户名！', icon: 'none' });
      // }else{
if(that.data.newPassword.length<6){
  wx.showToast({ title: '新密码不能少于六位数！', icon: 'none' });
}else{
  if (that.data.newPassword != that.data.password2){
    wx.showToast({ title: '两次密码输入不一致！', icon: 'none' });
  }else{
  //最后表单验证成功的，ajax
  wx.showLoading({
    title: '加载中',
  })
  wx.request({
    url: getApp().globalData.url + 'user/resetPassword',
    header: {
      'Content-Type': getApp().globalData.contentType
    },
    data: e.detail.value,
    method: 'post',
    dataType: 'json',
    success: function (data) {
      wx.hideLoading();
      console.log(data);
      if (data.data.code == 200) {
        wx.showToast({
          title: data.data.msg,
          icon: 'none'
        });
        setTimeout(function(){
          wx.navigateTo({
            url: 'login_select',
          })
        },1500)
      } else {
        wx.showToast({
          title: data.data.msg,
          icon: 'none'
        });
      }
    }
  }) //ajax end
}
      }
    }else{
      wx.showToast({title: '身份证号格式有误！',icon: 'none'});
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
this.setData({
  Utype:options.Utype,
})
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      phone: wx.getStorageSync("phone"),
    })
  },
})