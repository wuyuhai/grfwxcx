// pages/index/fuwu/shebcx.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    keyType:'1',//1代表用户账号。2代表社会信用代码
    wxId:'',
    str1: '',
    str2: '',
  },
  input_str: function (e) { 
    var that = this;
    this.setData({ str1: e.detail.value }) 
    var dw_str = /^[A-Za-z0-9]+$/;
    if (dw_str.test(that.data.str1)) {
      //匹配到是社会信用代码
      that.setData({
        keyType: '2'
      })
    } else {
      that.setData({
        keyType: '1'
      })
    }
  },
  input_str2: function (e) { this.setData({ str2: e.detail.value }) },
  formSubmit: function (e) {
    var that = this;
      // 验证码输入正确时的操作
      if (that.data.str1 == '') {
        wx.showToast({
          title: '请输入用户名或社会信用代码！',
          icon: 'none'
        });
      } else if (that.data.str2 == '') {
        wx.showToast({
          title: '请输入密码！',
          icon: 'none'
        });
      }
      else {
        wx.showLoading({title: '登陆中',})
        console.log('form发生了submit事件，携带数据为：', e.detail.value);
        wx.request({
          // url: 'http://202.98.195.208:83/IntegratedQuery/realPropertyCertificate',
          // account: fotoit_1
          // password: fotoit123//520131415165151515//123456
          url: getApp().globalData.url + 'user/getCorpInfo',
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: e.detail.value,
          // data: { 'param': obj_s2, 'url': 'http://202.98.195.208:83/apiroute/sbFind' },
          method: 'post',
          dataType: 'json',
          success: function (data) {
            console.log(data);
            if(data.data.code == 200){
              wx.hideLoading();
              wx.setStorageSync("token", data.data.data.token);
              wx.setStorageSync("wxId", data.data.data.wx_id);
              wx.setStorageSync("user_name", data.data.data.CORPORATE_NAME);
              wx.setStorageSync("login_name", data.data.data.LOGIN_NAME);
              wx.setStorageSync("id", data.data.data.id);
              wx.setStorageSync("user_id", data.data.data.USER_ID);
              wx.setStorageSync("uType", 1);
            wx.switchTab({
              url: '/page/tabBar/home/index',
            })
            }else{
              wx.showToast({ title: data.data.msg, icon: 'none' });
            }
          }
        })//ajax end
      }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      wxId: getApp().globalData.wxId,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
this.setData({
  wxId: getApp().globalData.wxId,
})
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})