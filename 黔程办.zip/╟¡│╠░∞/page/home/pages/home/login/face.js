// pages/home/login/login.js
var zhenze = require('../../../../../utils/zhenze.js').check;
Page({

  /**
   * 页面的初始数据 
   */
  data: {
    name:'',
    idCardNumber: '',
    phone:'',
    oop:false,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // wx.navigateTo({
    //   url: '../../../tabBar/home/index',
    // })
    console.log(options)
    this.setData({
      oop: options.oop
    })  
    console.log(this.data.oop)
  },
  input_str1: function (e) { this.setData({ name: e.detail.value }) 
    wx.setStorageSync("login_name", e.detail.value);
  },
  input_str2: function (e) { this.setData({ idCardNumber: e.detail.value }) 
    wx.setStorageSync("idCardNumber", e.detail.value);
    },
  face_beg:function(){
    var that = this;
    console.log(this.data.name);
    if (that.data.name == '' || that.data.idCardNumber==''){
      wx.showToast({ title: '请填写完整的用户信息！', icon: 'none' });
    }else{//填写完整刷脸
    wx.startFacialRecognitionVerify({
      name: that.data.name,
      idCardNumber: that.data.idCardNumber,
      success(res) {
        var verifyResult = res.verifyResult;
        // 刷脸成功之后登陆到黔程办
        wx.showLoading({
          title: '登陆中',
        })
        wx.request({
          url: getApp().globalData.url + 'user/getUserInfo',
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            key: that.data.idCardNumber,
            keyType:'3',
            wxId: getApp().globalData.wxId,
            mobile: wx.getStorageSync("phone"),
            username: that.data.name,
          }, //传微信id  unionId
          method: 'post',
          dataType: 'json',
          success: function (data) {
            // 登录成功
            console.log(data)
            if (data.data.code == 200) {
              wx.hideLoading();
              wx.setStorageSync("token", data.data.data.token);
              wx.setStorageSync("wxId", data.data.data.wx_id);
              wx.setStorageSync("user_name", that.data.name);
              wx.setStorageSync("id", data.data.data.id);
              wx.setStorageSync("idCardNumber", that.data.idCardNumber);
              wx.setStorageSync("login_name", that.data.name);
              wx.setStorageSync("email", data.data.data.MEAIL);
              wx.setStorageSync("user_id", data.data.data.USER_ID);
              wx.setStorageSync("user_mobile", data.data.data.MOBILE);
              wx.setStorageSync("uType", 0);
              var usid = data.data.data.USER_ID;
              wx.request({
                url: getApp().globalData.url + 'user/userRealAuthPassed',
                header: {
                  'Content-Type': getApp().globalData.contentType
                },
                data: {
                  cardNo: that.data.idCardNumber
                }, //传微信id  unionId
                method: 'post',
                dataType: 'json',
                success: function (data) {
                  // 实名成功
                  console.log(data)
                  if (data.data.code == 200) {
                    wx.setStorageSync('hadyzname', true);
                    wx.request({
                      url: getApp().globalData.url + 'user/uploadFaceVerifyResult',
                      header: {
                        'Content-Type': getApp().globalData.contentType
                      },
                      data: {
                        userId: usid,
                        verifyResult: verifyResult,
                      }, //传微信id  unionId
                      method: 'post',
                      dataType: 'json',
                      success: function (data) {
                        console.log(usid)
                        console.log(data)
                        wx.switchTab({
                          url: '/page/tabBar/index/index',
                        })
                      }
                    })   
                  } else {
                    wx.showToast({ title: data.data.msg, icon: 'none' });
                  }
                }
              }) //ajax end
            } else {
              
              wx.showToast({ title: data.data.msg, icon: 'none' });
            }
          }
        }) //ajax end
      },
      fail(res) {
        wx.showToast({ title: '刷脸链接失败，请检查网络或更换登录方式！', icon: 'none' });
        const verifyResult = res.verifyResult;
        console.log(verifyResult);
        console.log(res);
        var data_a = {
          name: that.data.name,
          idCardNumber: that.data.idCardNumber, 
        }
        data_a = JSON.stringify(data_a);
        var errorMsg = JSON.stringify(res);
        var urls = "wx.startFacialRecognitionVerify";
        var types = 2
        zhenze.resultjsonFun(data_a, errorMsg, urls, types,'https://gzzw.gzegn.gov.cn:84/auth/log') 
      },
      complete(res) {
        console.log(res);
      }
    })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      name: wx.getStorageSync('login_name'),
      idCardNumber: wx.getStorageSync('idCardNumber'),
      phone: wx.getStorageSync("phone"),
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})