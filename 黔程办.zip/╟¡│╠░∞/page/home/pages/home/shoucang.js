// page/home/pages/home/shoucang.js
var commomjs = require("../../../../utils/common.js")  



Page({

  /**
   * 页面的初始数据
   */
  data: {
    show_delete: false,
    shoucang_list: [], 
    // 触摸开始时间
    touchStartTime: 0,
    // 触摸结束时间
    touchEndTime: 0,
    // 最后一次单击事件点击发生时间
    lastTapTime: 0,
    // 单击事件点击后要触发的函数
    lastTapTimeoutFunc: null,
    wxId:'123456',
    shoucId:'12',
    index:'0',//数组序列
  },
  /// 按钮触摸开始触发的事件
  touchStart: function (e) {
    this.touchStartTime = e.timeStamp;
  },
  /// 按钮触摸结束触发的事件
  touchEnd: function (e) {
    this.touchEndTime = e.timeStamp;
  },
  bindtap:function(e){//单击事件
    var itemId = e.currentTarget.id,
      canDo = e.currentTarget.dataset.cando,
      deptname = e.currentTarget.dataset.dept_name,
      shouc_id = e.currentTarget.dataset.shoucid,
      item_name = e.currentTarget.dataset.item_name;
    var that = this
    // 控制点击事件在350ms内触发，加这层判断是为了防止长按时会触发点击事件
    if (that.touchEndTime - that.touchStartTime < 350) {
      // 当前点击的时间
      var currentTime = e.timeStamp
      var lastTapTime = that.lastTapTime
      // 更新最后一次点击时间
      that.lastTapTime = currentTime

      // 如果两次点击时间在300毫秒内，则认为是双击事件
      if (currentTime - lastTapTime < 300) {
        console.log("double tap")
        // 成功触发双击事件时，取消单击事件的执行
        clearTimeout(that.lastTapTimeoutFunc);
      } else {
        that.lastTapTimeoutFunc = setTimeout(function () {//单击
        wx.navigateTo({
          url: '/page/index/pages/index/banshi/shixiang_xq?itemId=' + itemId + '&canDo=' + canDo + '&deptname=' + deptname + '&sxzxname=' + item_name + '&isShouc=true&shouc_id=' + shouc_id,
        })
        }, 300);
      }
    }
  },
  longTap: function (e) {
    this.setData({
      shoucId: e.currentTarget.dataset.shoucid,
    })
    var that = this;
    wx.showModal({
      title: '取消收藏',
      content: '确定取消收藏吗？',
      success: function (res) {
        if (res.confirm) {
        wx.request({
          url: getApp().globalData.url + 'userFavorItem/del',
          header: {
            'Content-Type': getApp().globalData.contentType
          },
          data: {
            delList: that.data.shoucId,
          },
          method: 'post',
          dataType: 'json',
          success: function (data) {
            if (data.data.code == 200) {
              wx.showToast({ title: '取消收藏成功！', icon: 'none' });
              that.onShow();
            }
          }
          }) //ajax end
          } else if (res.cancel) {

        }
      }
    })//
  },
  /**
   * 生命周期函数--监听页面加载
   */
  delete_sc: function(e) {


  },
  onLoad: function (options) {
    var that = this;
    //获取收藏数据
   var user_id= wx.getStorageSync('user_id')
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this;
    that.setData({
      wxId: getApp().globalData.wxId,
    })
// 获取收藏列表
    console.log(wx.getStorageSync('wxId'))
    wx.request({
      url: getApp().globalData.url + 'userFavorItem/getList',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        wxId: wx.getStorageSync('wxId'),
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.code == 200) {
          if (data.data.data.length>=0){
            for (var i in data.data.data) {
              data.data.data[i].create_time = commomjs.timestampToTime(data.data.data[i].create_time);
            }
            that.setData({
              shoucang_list: data.data.data,
            })
          }else{
            wx.showToast({ title: '你还没有任何收藏哦', icon: 'none' });
          }             
        }
      }
    }) //ajax end
  }, 
})