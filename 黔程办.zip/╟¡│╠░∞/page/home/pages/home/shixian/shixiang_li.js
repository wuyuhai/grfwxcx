// page/home/pages/home/shixian/shixiang_xq.js
Page({
  data: {
    sxnumber:'',
    name:'',
    username:'',
    time:'',
    cotant:'',
    permid:''
  },

  onLoad: function (option) {
    //console.log(option)
    this.setData({
      sxnumber: option.sxnumber,
      name: option.name,
      permid: option.permid,
      time: option.time,
      cotant: option.cotant,
      username: wx.getStorageSync("user_name"),
    })
    wx.setNavigationBarTitle({ //设置标题
      title: option.name,
    })
  },
})