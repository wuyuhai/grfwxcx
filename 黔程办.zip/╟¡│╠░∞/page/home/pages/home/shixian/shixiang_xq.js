// page/home/pages/home/shixian/shixiang_xq.js
Page({
  data: {
    title:"",
    item_bz:[]
  },

  onLoad: function (options) { 
    console.log(options)
    if (options.id){
      var that = this;
      wx.request({
        url: getApp().globalData.url + 'item/getGuide_new',
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: {
          itemId: options.id
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          //console.log(data)
          if (data.data.code == 200) {
            if (data.data.data) {
              if (data.data.data.NODELIST.length > 0){
                that.setData({ //把选中值放入判断值
                  title: data.data.data.SXZXNAME,
                  item_bz: data.data.data.NODELIST
                });
              }else{
                that.setData({ //把选中值放入判断值
                  title: data.data.data.SXZXNAME,
                });
                wx.showToast({
                  title: '本事项不需提交办理材料,2.5s自动返回查询页',
                  icon:'none'
                })
                setTimeout(function(){
                  wx.navigateBack({
                    delta: 1
                  })
                },2500)              
              }
            } else {
              that.setData({ //把选中值放入判断值
                title: "暂无事项步骤",
                item_bz: "",
              });
              wx.showToast({
                title: '该任务暂没有设置事项步骤',
                icon: 'none'
              })
            }
          } else {
            wx.showToast({
              title: '网络请求失败',
              icon: 'none'
            })
          }
        },
      })
    }
  },
})