// page/home/pages/home/shixian/my_shixian.js 
Page({

  /** 
   * 页面的初始数据
   */
  data: {
    dcl_list:[],
  },

  onLoad:function(){
    var urlarr = ['online/queryProcessing', 'online/querySuspend', 'online/queryRefuse', 'online/queryAdditional','online/queryFinish'];
    for (var i in urlarr){
      this.requestkind(urlarr[i]);
    }
  },

  requestkind: function (urlstr) {
    var that = this;
    wx.request({
      url: getApp().globalData.url + urlstr,
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        token: wx.getStorageSync('token'),
        applicantId: wx.getStorageSync('user_id')
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if (data.data.code == 200) {
          if (data.data.data.length>0) {
            var dcl_list = that.data.dcl_list;
            for (var j in data.data.data){
              dcl_list.push(data.data.data[j])
            }
            that.setData({ //把选中值放入判断值
              dcl_list: dcl_list
            });
          }
        } else {
          that.setData({ //把选中值放入判断值
            alldata: []
          });
          if (data.data.msg == "登录已超时，请重新登录"){
            wx.showToast({
              title: '登录超时，请重新登录',
              icon: 'none'
            });
            wx.removeStorageSync('token');
            wx.navigateTo({
              url: '../login/selcet_login_type',
            })
            return
          }else{
            wx.showToast({
              title: '政务系统繁忙',
              icon: 'none'
            });
          }         
        }
      },
      fail: function () {
        wx.showToast({
          title: '请检查网络连接',
          icon: 'none'
        });
      }
    })
  },
})