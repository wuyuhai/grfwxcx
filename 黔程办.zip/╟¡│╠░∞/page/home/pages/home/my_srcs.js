Page({
  data: { 
    selcettrue:{},
    bianjitrue: {}, 
    mysrcs:[],
    kind:0,
    shangchuanid:"",
    returnimg:[],
    list:[]
  },
  onLoad: function (options) { 
    console.log(options)
    var shangchuanid = "",kind = 0,list = [];
    if (options.kind){
      kind = options.kind;
      shangchuanid = options.id;
      list = JSON.parse(options.list);
    }
    var mysrcs = []
    if (wx.getStorageSync("mysrcs")){
      mysrcs = wx.getStorageSync("mysrcs");
    }
    
    var bianjitrue = {}
    if (mysrcs.length>1){
      for (var i in mysrcs) {
        bianjitrue[mysrcs[i].srcname] = false;
      }
    }
    this.setData({
      mysrcs: mysrcs,
      bianjitrue: bianjitrue,
      kind: kind,
      list: list,
      shangchuanid: shangchuanid
    })
  },

  selectimg:function(e){
    console.log(e)
    //上传多张的时候
    // var selcettrue = this.data.selcettrue;
    // var returnimg = this.data.returnimg;

    //只上传一张的时候
    var selcettrue = {};
    var returnimg = [];


    if (!selcettrue[e.currentTarget.dataset.parid + "-" + e.currentTarget.dataset.id] || selcettrue[e.currentTarget.dataset.parid + "-" + e.currentTarget.dataset.id] == undefined){
      selcettrue[e.currentTarget.dataset.parid + "-" + e.currentTarget.dataset.id] = true;  
     }else{
      selcettrue[e.currentTarget.dataset.parid + "-" + e.currentTarget.dataset.id] = !selcettrue[e.currentTarget.dataset.parid + "-" + e.currentTarget.dataset.id];
     }
    if (selcettrue[e.currentTarget.dataset.parid + "-" + e.currentTarget.dataset.id] == true){
      if (returnimg.length>0){
        // var hadimg = false;
        // for (var i = 0; i < returnimg.length; i++) {
        //   if (returnimg[i].src == e.currentTarget.dataset.img){
        //     hadimg = true;
        //   }         
        // }
        // if (hadimg == false) {
        //   returnimg.push({
        //     src: e.currentTarget.dataset.img
        //   })
        // }
        wx.showToast({
          title: "每次只能选择一张图片",
          icon: 'none'
        });
        selcettrue[e.currentTarget.dataset.parid + "-" + e.currentTarget.dataset.id] = false;
      }else{
        returnimg.push({
          src: e.currentTarget.dataset.img
        })
      }
      this.setData({
        selcettrue: selcettrue,
        returnimg: returnimg
      })
    }else{
      if (returnimg.length > 0) {
        var hadimg = false;
        for (var i = 0; i < returnimg.length; i++) {
          if (returnimg[i].src == e.currentTarget.dataset.img) {
            hadimg = true;
          }
          if (hadimg == true) {
            returnimg.splice(i, 1)
          }
          this.setData({
            selcettrue: selcettrue,
            returnimg: returnimg
          })     
          return; 
        }        
      }
    }   
  },

  bianjishow:function(e){
    console.log(e.currentTarget.dataset.id);
    var bianjitrue = this.data.bianjitrue;
    bianjitrue[e.currentTarget.dataset.id] = !bianjitrue[e.currentTarget.dataset.id];
    this.setData({
      bianjitrue: bianjitrue
    })
  },

  //删除单个发材料
  removedange:function(e){
    console.log(e.currentTarget.dataset.id, e.currentTarget.dataset.num);
    var mysrcs = this.data.mysrcs;
    for (var i = 0;i < mysrcs.length;i++){
      if (mysrcs[i].srcname == e.currentTarget.dataset.id){
        console.log(22)
        for (var j = 0; j < mysrcs[i].srcimg.length;j++){
          if (j == e.currentTarget.dataset.num){
            console.log(j)
            console.log(33)
            mysrcs[i].srcimg.splice(mysrcs[i].srcimg[j],1);
            if (mysrcs[i].srcimg.length==0){
              mysrcs.splice(mysrcs[i],1);
              wx.setStorageSync("mysrcs", mysrcs)  
              this.setData({
                mysrcs: mysrcs
              })
              return;
            }else{
              this.setData({
                mysrcs: mysrcs
              })
            }
            return;
          }
        }
      }
    }    
  },

  //对应的材料类名下添加资料
  tianaddimg:function(e){
    var that = this;
    var mysrcs = this.data.mysrcs;
    var srcsame = false;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        for (var i = 0; i < mysrcs.length; i++) {
          if (mysrcs[i].srcname == e.currentTarget.dataset.id) {
            console.log(22)
            for (var j = 0; j < mysrcs[i].srcimg.length; j++) {
              var str = mysrcs[i].srcimg[j].src;
              str = str.substring(str.length - 36);
              if (str == tempFilePaths[0].substring(tempFilePaths[0].length - 36)) {
                srcsame = true;
              }
            }
            if (srcsame == false){
              mysrcs[i].srcimg.push({
                "src": res.tempFilePaths[0],
              })
            }else{
              wx.showToast({
                title: "改资料已经上传过",
                icon: 'none'
              });
            }   
            wx.setStorageSync("mysrcs", mysrcs)        
            that.setData({
              mysrcs: mysrcs
            })
            return;
          }
        }
      }
    }) 
  },
  returnimgsure:function(e){
    var that = this;
    var pages = getCurrentPages();
    
    var currPage = pages[pages.length - 1];   //当前页面
    var prevPage = pages[pages.length - 2];  //上一个页面
    var list = this.data.list, id = this.data.shangchuanid; 
    
    var returnimg = that.data.returnimg
    console.log(returnimg)
    for(var i = 0; i < list.length;i++){
      if (list[i].ID == id) {
        list[i].img = [];
        for (var j = 0; j < returnimg.length;j++){
          var src = returnimg[j].src; 
          list[i].img.push(src)
        }
      }      
    }
    console.log(list)
    prevPage.setData({
      file_list: list,
    })
    wx.navigateBack({
      delta: 1
    })
  },

  //图片预览功能
  imgpreload:function(e){
    wx.previewImage({
      current: e.currentTarget.dataset.src, // 当前显示图片的http链接
      urls: [e.currentTarget.dataset.src] // 需要预览的图片http链接列表
    })
  },

  allremovement:function(e){  
    var mysrcs = this.data.mysrcs;
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定要删除该项资源吗？',
      success: function (res) {
        if (res.confirm) {
          for (var i = 0; i < mysrcs.length; i++) {
            if (mysrcs[i].srcname == e.currentTarget.dataset.name) {
              mysrcs.splice(i, 1);
              that.setData({
                mysrcs: mysrcs
              })
              wx.setStorageSync('mysrcs', mysrcs)
              return
            }
          }
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
    
  }
})