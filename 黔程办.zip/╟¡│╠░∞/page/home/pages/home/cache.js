// page/home/pages/home/cache.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cache_map: [ //缓存键值码表  不在码表内的 显示未知
      {
        id: "login_type",
        name: "登录类型" //微信密码wxmm  人脸识别rlhs  30天无验证登录 wyz30
      },
      {
        id: "search_history",
        name: "搜索历史集合"
      },
      {
        id: "openid",
        name: "微信的openid"
      },
      {
        id: "session_key",
        name: "微信的session_key"
      },
      {
        id: "dy_scroll_n2_width",
        name: "首页侧滑第二个盒子的宽度"
      },
      {
        id: "dy_num",
        name: "默认订阅之后的个数"
      },
      {

        id: "dy_subscription",
        name: "订阅全部列表"
      },
      {

        id: "dy_subscription2",
        name: "订阅列表"
      },
      {
        id: "qu_list",
        name: "地区集合"
      },
      {
        id: "shi_list",
        name: "市集合"
      },
      {
        id: "all_list",
        name: "市区集合"
      },
      {
        id: "shi_index",
        name: "市索引"
      },
      {
        id: "qu_index",
        name: "区索引"
      },
      {
        id: "btn_list",
        name: "事项分类"
      },
      {
        id: "shen_dept",
        name: "省级部门"
      },
      {
        id: "token",
        name: "用户令牌"
      },
      {
        id: "user_id",
        name: "用户id"
      }, {
        id: "hot_item_list",
        name: "热门事项"
      },
      {
        id: "face_name",
        name: "刷脸用户名"
      },
      {
        id: "face_idCode",
        name: "刷脸身份证号"
      },
      {
        id: "wxId",
        name: "微信ID"
      },
      {
        id: "user_name",
        name: "用户名"
      },
      {
        id: "id",
        name: "用户网站id"
      },
      {
        id: "idCardNumber",
        name: "登录身份证"
      },
      {
        id: "login_name",
        name: "登录名"
      },
      {
        id: "phone",
        name: "用户电话"
      },
      {
        id: "uType",
        name: "法人或自然人"
      },
      {
        id: "email",
        name: "email"
      }
    ],
    cache_list: [], //缓存集合
    currentSize: 0, //缓存当前大小
    limitSize: 0, //缓存剩余空间

  },

  get_key: function() { //获取全部键
    var that = this;
    wx.getStorageInfo({
      success: function(res) {
        var list = [];
        var keys = res.keys;
        var map = that.data.cache_map;
        for (var i = 0; i < keys.length; i++) {
          var flag = true;
          for (var j = 0; j < map.length; j++) {
            if (keys[i] == map[j].id) {
              list.push(map[j])
              flag = false;
              break;
            }
          }
          if (flag) {
            var obj = {}
            obj.id = keys[i];
            obj.name = '未知';
            list.push(obj)
          }
        }

        that.setData({
          currentSize: res.currentSize,
          limitSize: res.limitSize,
          cache_list: list
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.get_key()
  },

  delete_cache: function(e) {
    var that = this;
    wx.showModal({
      title: '删除',
      content: '确定删除该缓存吗',
      success: function(res) {
        if (res.confirm) {
          wx.removeStorageSync(e.currentTarget.id);
          that.get_key()
        } else if (res.cancel) {

        }
      }
    })

  },
  delete_all_cache: function() {
    var that = this;
    wx.showModal({
      title: '清除缓存',
      content: '确定清除全部缓存吗',
      success: function(res) {
        if (res.confirm) {
          var wxid = wx.getStorageSync("wxId"),
            token = wx.getStorageSync("token"),
            user_name = wx.getStorageSync("user_name"),
            idCardNumber = wx.getStorageSync("idCardNumber"),
            id = wx.getStorageSync("id"),
            login_name = wx.getStorageSync("login_name"),
            uType = wx.getStorageSync("uType"),
            user_id = wx.getStorageSync("user_id"),
            phone = wx.getStorageSync("phone"),
            qu_list = wx.getStorageSync("qu_list"),
            shi_list = wx.getStorageSync("shi_list"),
            qu_index = wx.getStorageSync("qu_index"),
            shi_index = wx.getStorageSync("shi_index"),
          dy_subscription2 = wx.getStorageSync("dy_subscription2");
            // hadyzname = wx.getStorageSync('hadyzname')
          wx.clearStorageSync();
          that.get_key();
          wx.setStorageSync("wxId", wxid);
          wx.setStorageSync("token", token);
          wx.setStorageSync("user_name", user_name);
          wx.setStorageSync("id", id);
          wx.setStorageSync("idCardNumber", idCardNumber);
          wx.setStorageSync("login_name", login_name);
          wx.setStorageSync("user_id", user_id);
          wx.setStorageSync("uType", uType);
          wx.setStorageSync("phone", phone);
          wx.setStorageSync("qu_list", qu_list);
          wx.setStorageSync("shi_list", shi_list);
          wx.setStorageSync("qu_index", qu_index);
          wx.setStorageSync("shi_index", shi_index);
          wx.setStorageSync("dy_subscription2", dy_subscription2);
          // wx.setStorageSync("hadyzname", hadyzname);
        } else if (res.cancel) {
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})