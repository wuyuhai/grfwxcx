// pages/opactive/opimap/opimap.js
var QQMapWX = require('../../../../../utils/qqmap-wx-jssdk.js');
var qqmapsdk;
Page({
  data: {
    latitude: "",
    longitude: "",
    markers: [{
      iconPath: "/img/dingwei.png",
      id: 0,
      latitude: 30.295069,
      longitude: 120.00009,
      width: 35,
      height: 35
    }],
    opiuldianjibol: false,
    sureaddress:"",
    shuangxianbol:true,
    shenfen:{},
  },
  onLoad: function (options) {
    qqmapsdk = new QQMapWX({
      key: 'VHHBZ-WO2RD-SDH4P-HIYYS-O6CL3-3ABY7'
    });
    this.getaddres();
  },

  //获取当前的位置
  getaddres: function (e) {
    console.log(1)
    var that = this;
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        console.log(res)
        console.log(1)
        var latitude = res.latitude;
        var longitude = res.longitude;
        that.setData({
          latitude: latitude,
          longitude: longitude,
          markers: [{
            iconPath: "/img/dingwei.png",
            id: 0,
            latitude: latitude,
            longitude: longitude,
            width: 35,
            height: 35
          }],
        });
        that.opikinds(latitude, longitude,that)
      }
    })
    this.mapCtx = wx.createMapContext('map');
  },

  //获取中心点附近的opi
  opikinds: function (latitude,longitude,that){
    qqmapsdk.reverseGeocoder({
      location: {
        latitude: latitude,
        longitude: longitude,
      },
      get_poi: 1,
      success: function (addressRes) {
        console.log(addressRes.result.address_component)
        var opili = [];
        var address = {
          address: addressRes.result.formatted_addresses.recommend,
          location: {
            lat:addressRes.result.location.lat,
            lng: addressRes.result.location.lng
          }
        }
        opili.push(address);
        var opis = addressRes.result.pois;
        console.log(opis)
        for (var i in opis) {
          var tem = {
            title: opis[i].title,
            address: opis[i].address,
            location: {
              lat: opis[i].location.lat,
              lng: opis[i].location.lng
            },
            ad_info: opis[i].ad_info
          }
          opili.push(tem);
        }
        // console.log(opili)
        that.setData({
          opili: opili,
          sureaddress: addressRes.result.formatted_addresses.recommend,
          shenfen: addressRes.result.address_component,
        })
      }
    })
  },

  getCenterLocation: function (e) {
    if (this.data.shuangxianbol == true){
      console.log(1)
      var that = this;
      this.mapCtx.getCenterLocation({
        success: function (res) {
          that.translateMarker(res.latitude, res.longitude)
          that.opikinds(res.latitude, res.longitude, that)
        }
      })
    }
  },

  //切换地图中心
  changeCentermap: function (e) {
    var that = this;
    console.log(e)
    var latitude = e.currentTarget.dataset.lat;
    var longitude = e.currentTarget.dataset.lng;
    that.setData({
      latitude: latitude,
      longitude: longitude,
      opiuldianjibol: true,
      shuangxianbol:false,
      shenfen: e.currentTarget.dataset.sf,
      sureaddress: e.currentTarget.dataset.address
    })
    this.translateMarker(latitude, longitude)
  },

  translateMarker: function (j, w) {
    var that = this;
    console.log(j, w)
    this.mapCtx.translateMarker({
      markerId: 0,
      // autoRotate: true,
      duration: 500,
      destination: {
        latitude: j,
        longitude: w,
      },
      animationEnd() {
        //移动结束
        that.setData({
          shuangxianbol: true,
        })
      }
    })
  },

  diandisj: function () {
    this.setData({
      opiuldianjibol: true
    })
  },

  dianjidt: function () {
    this.setData({
      opiuldianjibol: false
    })
  },

  //活动地址opi搜索
  opissshow: function () {
    wx.navigateTo({
      url: 'opishuru',
    })
  },

  //地址确认
  addressure:function(){
    var that = this;
    var pages = getCurrentPages();
    var currPage = pages[pages.length - 1];   //当前页面
    var prevPage = pages[pages.length - 2];  //上一个页面
    console.log(that.data.shenfen)
    prevPage.setData({
      address: that.data.sureaddress,
      shenfen: that.data.shenfen,
    })
    wx.navigateBack({
      delta: 1
    })
  }    
})