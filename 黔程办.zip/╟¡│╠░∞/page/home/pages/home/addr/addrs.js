// pages/home/addr/addrs.js
Page({
  data: { 
    items:[]
    // name:"",
    // phone
    // addrshq
    // addr
    // toatladdrss
    //moren
  },
  onLoad: function (options) { 
    
  },
  onShow:function(){
    this.getaddres();

    // this.setData({
    //   items: wx.getStorageSync('address_items') == "" ? [] : wx.getStorageSync('address_items'),
    // })
  },

  //请求已有的地址
  getaddres:function(){
    var that = this;
    wx.request({
      url: getApp().globalData.url + 'shippingAddr/getList',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: { uType: wx.getStorageSync('uType'), userId: wx.getStorageSync('user_id')},
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if(data.data.code == 200){
          if(data.data.data.length>0){
            var mosrenlength = 0;
            for (var i = 0; i < data.data.data.length;i++){
              if (data.data.data[i].defaultAddr == true){
                mosrenlength = mosrenlength + 1;
                wx.setStorageSync("mraddressid", data.data.data[i].id)
                if (mosrenlength>1){
                  data.data.data[i-1].defaultAddr = false;
                }
              }
            }
            that.setData({
              items: data.data.data
            })
          }
        }else{
          wx.showToast({
            title: '政务系统繁忙',
            icon:'none'
          })
        }
      }
    }) 
  },

  removeaddres:function(e){
    var that = this;
    console.log(e)
    wx.showModal({
      title: '提示',
      content: '确定要删除该地址吗',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          wx.request({
            url: getApp().globalData.url + 'shippingAddr/delList',
            header: {
              'Content-Type': getApp().globalData.contentType
            },
            data: { delList: e.currentTarget.dataset.id},
            method: 'post',
            dataType: 'json',
            success: function (data) {
              console.log(data)
              if (data.data.code == 200) {
                wx.showToast({
                  title: '删除成功',
                  icon: 'none'
                })
                that.getaddres();
              } else {
                wx.showToast({
                  title: '政务系统繁忙',
                  icon: 'none'
                })
              }
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },

  //跳到编辑
  editchange:function(e){
    console.log(e.currentTarget.dataset.id)

    var items = this.data.items,item={};
    if (e.currentTarget.dataset.id){
      for(var i = 0;i<items.length;i++){
        if (items[i].id == e.currentTarget.dataset.id){
          item={
            id:items[i].id,
            name: items[i].consignee,
            phone: items[i].mobile,
            province: items[i].province,
            district: items[i].district,
            street: items[i].street,
            defaultAddr: items[i].defaultAddr,
            district: items[i].district,
            city: items[i].city
          }
          wx.navigateTo({
            url: 'add_addr?item=' + JSON.stringify(item),
          })
        }
      }
    }
  },

  morenaddrschecked:function(e){
    console.log(e.detail.value[0])
    if (e.detail.value.length>0){
      this.changeaddress(e.detail.value[0])
    }
  },

  //修改用户信息
  changeaddress:function(id){
    var that = this;
    wx.request({
      url: getApp().globalData.url + 'shippingAddr/modify',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: { id: id, defaultAddr: true},
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        that.getaddres();
      }
    })
  }
})