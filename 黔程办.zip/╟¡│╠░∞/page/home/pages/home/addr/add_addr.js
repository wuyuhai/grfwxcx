var QQMapWX = require('../../../../../utils/qqmap-wx-jssdk.js');
var qqmapsdk;
var tcity = require("../../../../../utils/citys.js");

var app = getApp()
Page({
  data: {
    provinces: [],
    province: "",
    citys: [],
    city: "",
    countys: [],
    county: '',
    value: [0, 0, 0],
    values: [0, 0, 0],
    condition: false,
    show:true,

    id:'',
    name:'',
    phone:'',
    address: "",
    detialaddres: "",

    shenfen:"",

    moren:{
      name:"设为默认",
      value:1,
      cheched:"",
    },
  }, 
  bindChange: function (e) {
    //console.log(e);
    var val = e.detail.value
    var t = this.data.values;
    var cityData = this.data.cityData;

    if (val[0] != t[0]) {
      console.log('province no ');
      const citys = [];
      const countys = [];

      for (let i = 0; i < cityData[val[0]].sub.length; i++) {
        citys.push(cityData[val[0]].sub[i].name)
      }
      for (let i = 0; i < cityData[val[0]].sub[0].sub.length; i++) {
        countys.push(cityData[val[0]].sub[0].sub[i].name)
      }

      this.setData({
        province: this.data.provinces[val[0]],
        city: cityData[val[0]].sub[0].name,
        citys: citys,
        county: cityData[val[0]].sub[0].sub[0].name,
        countys: countys,
        values: val,
        value: [val[0], 0, 0]
      })

      return;
    }
    if (val[1] != t[1]) {
      console.log('city no');
      const countys = [];

      for (let i = 0; i < cityData[val[0]].sub[val[1]].sub.length; i++) {
        countys.push(cityData[val[0]].sub[val[1]].sub[i].name)
      }

      this.setData({
        city: this.data.citys[val[1]],
        county: cityData[val[0]].sub[val[1]].sub[0].name,
        countys: countys,
        values: val,
        value: [val[0], val[1], 0]
      })
      return;
    }
    if (val[2] != t[2]) {
      console.log('county no');
      this.setData({
        county: this.data.countys[val[2]],
        values: val
      })
      return;
    }


  },
  open: function () {
    this.setData({
      condition: true,
      show: false
    })
  },
  close : function(){
    this.setData({
    condition: false,
    show: true
    })
  },
  back : function(){
    wx.navigateTo({
      url: 'addrs'
    })
  },
  formSubmit: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value);
    if (!e.detail.value.name){
      wx.showToast({
        title: '收货人姓名不能为空',
        icon:'none',
      })
      return;
    }
    if (!/^1([358][0-9]|4[579]|66|7[0135678]|9[89])[0-9]{8}$/.test(e.detail.value.phone) ) {
      wx.showToast({
        title: '收货人电话不正确！',
        icon: 'none',
      })
      return;
    }
    if (!e.detail.value.addrshq) {
      wx.showToast({
        title: '请选择收货省市街道',
        icon: 'none',
      })
      return;
    }
    if (!e.detail.value.toatladdrss) {
      wx.showToast({
        title: '请填写详细地址',
        icon: 'none',
      })
      return;
    }

    if (e.detail.value.toatladdrss && e.detail.value.addrshq && e.detail.value.phone && e.detail.value.name){
      var url = getApp().globalData.url;
      if(this.data.id){
        url = url + 'shippingAddr/modify';
      }else{
        url = url + 'shippingAddr/add';
      }
      
      var data = {
        consignee: e.detail.value.name,
        mobile: e.detail.value.phone,
        street: e.detail.value.addr + " " + e.detail.value.toatladdrss,
        userId: wx.getStorageSync('user_id'),
        defaultAddr: e.detail.value.moren.length>0?true:false,
        UType: wx.getStorageSync('uType'),
        province: this.data.shenfen.province,
        city: this.data.shenfen.city,
        district: this.data.shenfen.district,
      }
      if (this.data.id){
        data.id = this.data.id
      }
      wx.request({
        url: url,
        header: {
          'Content-Type': getApp().globalData.contentType
        },
        data: data,
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data)
          if(data.data.code == 200){
            wx.showToast({
              title: '添加成功',
              icon: 'none'
            })
            wx.redirectTo({
              url: 'addrs',
            })
          }else{
            wx.showToast({
              title: data.data.msg,
              icon: 'none'
            });
          }       
        }
      }) 
      var address_items = []
      if (wx.getStorageSync("address_items")!=""){
        address_items = wx.getStorageSync("address_items")
      }

      if (e.detail.value.moren.length!=0){
        for (var i in address_items){
          address_items[i].moren=[];
        }
      } 
    }
  },

  formReset: function () {
    console.log('form发生了reset事件')
  },
  onLoad: function (option) {
    console.log(option.item);
    var that = this;
    if (option.item){
      var item = JSON.parse(option.item);
      that.setData({
        id: item.id,
        name: item.name,
        phone: item.phone,       
        address: item.street.split(" ")[0],
        detialaddres: item.street.split(" ")[1],
        defaultAddr: item.defaultAddr,                
        shenfen:{
          province: item.phone.province,
          city: item.city,
          district: item.district,
        }
      })
    }
    tcity.init(that);

    var cityData = that.data.cityData;


    const provinces = [];
    const citys = [];
    const countys = [];

    for (let i = 0; i < cityData.length; i++) {
      provinces.push(cityData[i].name);
    }
    console.log('省份完成');
    for (let i = 0; i < cityData[0].sub.length; i++) {
      citys.push(cityData[0].sub[i].name)
    }
    console.log('city完成');
    for (let i = 0; i < cityData[0].sub[0].sub.length; i++) {
      countys.push(cityData[0].sub[0].sub[i].name)
    }

    that.setData({
      'provinces': provinces,
      'citys': citys,
      'countys': countys,
      'province': cityData[0].name,
      'city': cityData[0].sub[0].name,
      'county': cityData[0].sub[0].sub[0].name
    })
    qqmapsdk = new QQMapWX({
      key: 'VHHBZ-WO2RD-SDH4P-HIYYS-O6CL3-3ABY7'
    });
    console.log('初始化完成');
  },

  //打开地图
  mapchoose: function () {
    wx.navigateTo({
      url: 'opimap',
    })
  },
})
