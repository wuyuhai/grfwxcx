// pages/opactive/opishuru/opishuru.js

var QQMapWX = require('../../../../../utils/qqmap-wx-jssdk.js');
var qqmapsdk;

Page({
  data: {
    opikeyul:[],
    opikey:"",
  },

  onLoad: function (options) {
    qqmapsdk = new QQMapWX({
      key: 'VHHBZ-WO2RD-SDH4P-HIYYS-O6CL3-3ABY7'
    });
  },

  //opi输入
  opishuru: function (e) {
    console.log(e.detail.value)
    this.setData({
      opikey: e.detail.value
    })
  },
  //opi关键词搜索
  keysearchbtn: function () {
    var that = this;
    that.setData({
      opikeyul: [],
    })
    var opikey = this.data.opikey;
    if (opikey != "") {
      qqmapsdk.getSuggestion({
        keyword: opikey,
        success: function (res) {
          console.log(res);
          var opikeyul = [];
          for (var i in res.data) {
            var tem = {
              address: res.data[i].address,
              title: res.data[i].title,
              location: {
                lat: res.data[i].location.lat,
                lng: res.data[i].location.lng
              }
            }
            opikeyul.push(tem);
          }
          that.setData({
            opikeyul: opikeyul,
          })
        },
      });
    }
  },

  //点击关键字，地图跳到对应的地址
  spikeysure: function (e) {
    var that = this;
    var pages = getCurrentPages();
    var currPage = pages[pages.length - 1];   //当前页面
    var prevPage = pages[pages.length - 2];  //上一个页面
    var latitude = e.currentTarget.dataset.lat;
    var longitude = e.currentTarget.dataset.lng;
    prevPage.setData({
      latitude: latitude,
      longitude: longitude,
      markers: [{
        iconPath: "/img/dingwei.png",
        id: 0,
        latitude: latitude,
        longitude: longitude,
        width: 35,
        height: 35
      }],
    })
    prevPage.opikinds(latitude, longitude, prevPage)
    wx.navigateBack({
      delta: 1
    })
  },
})