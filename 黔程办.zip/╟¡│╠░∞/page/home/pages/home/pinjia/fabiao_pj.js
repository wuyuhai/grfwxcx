// pages/home/pinjia/fabiao_pj.js
var util = require("../../../../../utils/util.js");
var utilMd5 = require('../../../../../utils/md5.js');
// var password = utilMd5.hexMD5(password); 
//接口地址
var evaluateUrl = "http://oa.ansdy.com/ytbase/system/default.aspx";
// 公共参数
var yt_out_lay = 1;
var DB_Conn = "ApseDb";
//授权信息
var serviceCode = "2002";
var password = "ftqwer!@#";
//随机数
var random = "123";
var requestNo = formatDate(new Date(), "yyyyMMddHHmmss") + random;
var signInfo = utilMd5.hexMD5(password + serviceCode + requestNo); 
function formatDate(date, formatStr) {
  var str = formatStr;
  str = str.replace(/yyyy|YYYY/, date.getFullYear());
  str = str.replace(/MM/, (date.getMonth() + 1) > 9 ? (date.getMonth() + 1).toString() : '0' + (date.getMonth() + 1));
  str = str.replace(/dd|DD/, date.getDate() > 9 ? date.getDate().toString() : '0' + date.getDate());
  str = str.replace(/HH/, date.getHours() > 9 ? date.getHours().toString() : '0' + date.getHours());
  str = str.replace(/mm/, date.getMinutes() > 9 ? date.getMinutes().toString() : '0' + date.getMinutes());
  str = str.replace(/ss/, date.getSeconds() > 9 ? date.getSeconds().toString() : '0' + date.getSeconds());
  return str;
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    toView:'非常满意',
    bsnum: "",
    btn:"好评",
    items: [
      { name: '1efbc9f502564ce18ee51f80021cb12e', value: '态度温和' },
      { name: 'e5a4b27112484dd7a839aae45d1ee3d5', value: '态度热情' },
      { name: 'cb4e7fa96c554f0b9d5f2b182c908ebd', value: '有耐心' },
      { name: '1e86cde1ec634b2fba8a5edd19df8de2', value: '行为规范' },
    ],
    items2: [
      { name: 'e5a4b27112484dd7a839aae45d1ee3d5', value: '服务较热情' },
      { name: '5f815992928144fcaf8d98a74015c3b2', value: '行为较规范' },
      { name: 'fe8e34123cbc495985b9c46a465e8a18', value: '比较有耐心' },
    ],
    items3: [
      { name: 'cba660ae6e674e0f82b2c8d03f93dadc', value: '态度恶劣' },
      { name: '8ee7b156d79849d88bda7cb25fa6b9eb', value: '没有耐心' },
      { name: 'cc7a6c864c814bc28e1cd947c558f986', value: '行为不当' },
    ],
    b_items: [
      { name: '5b7f4d4cbb344ecfb37f1a9dbeb7cc43', value: '办事效率高' },
      { name: 'deafb805690547a68d612db8aa1f60a4', value: '能一次性告知' },
      { name: '44ccff4840474a1c9e822fdf4d4ca2e9', value: '业务熟悉' },
      { name: 'c4e667e730b74ae9b875073173551ac8', value: '办件时间快' },
    ],
    b_items2: [
      { name: '197c08d6a9674605b1b36011635baae8', value: '效率比较高' },
      { name: '6fa858d6a7184913924263b7ab6d33f8', value: '业务较熟悉' },
      { name: 'e8adf2a5c54247f09b908fa52a4fcd9e', value: '比较有耐心' },
      { name: '7287da88ba8246019332adc6f165f544', value: '办件比较快' },
    ],
    b_items3: [
      { name: 'b7930e60c3384edf82f9bc3082e527b4', value: '业务不熟悉' },
      { name: 'f315efb54afd4539973a44f83a9899b6', value: '不一次性告知' },
      { name: '8d440896c83040a18522dfbf91ba68f9', value: '办件慢' },
    ]
  },
  checkboxChange(e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value)
    this.setData({
      cids_arr: e.detail.value,
    })
  },
  changeView : function(e){
    this.setData({
      toView: e.currentTarget.id,
    })
  },
  changeBtn: function (e) {
    this.setData({
      btn: e.currentTarget.id,
    })
  },
  formSubmit: function (e) {
    var that =this;
    var date = new Date();
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    var data={
      userId: wx.getStorageSync("user_id"),
      token: wx.getStorageSync("token"),
      BSNUM: this.data.bsnum,
      remark: e.detail.value.pingjia,
      result: e.detail.value.label,
      createTime: util.formatTime(date)
    }
    var str_oo = '';
    for (var i = 0; i < that.data.cids_arr.length;i++){
      if (i != that.data.cids_arr.length-1){
        str_oo = str_oo + that.data.cids_arr[i] + ',';
      }else{
        str_oo = str_oo + that.data.cids_arr[i];
      }
    }
    console.log(str_oo);
    that.uploadEvaluateInfo({
      "sOrgName": that.data.dept_name,
      "cids": str_oo,
      "areaCode":that.data.dept_addr,
      "aTitle":"贵人服务评价",
      "aDataId":'',
      "aDate": formatDate(new Date(),"yyyyMMddHHmmss"),
      "aStatus":"办结",
      "appDf": that.btn == "好评" ? "10" : that.btn == "中评" ? "5":"0",
      "tCode":"1001",
      "areaName":"",
      "sOrgId": that.data.dept_id,
      "sUserId":"",
      "sXName":"",
      "appXName": wx.getStorageSync("user_name"),
      "appIdc": wx.getStorageSync("idCardNumber"),
      "appAdvise": e.detail.value.pingjia,
      "df1": that.btn == "好评" ? "10" : that.btn == "中评" ? "5" : "0", 
      "df2": that.btn == "好评" ? "10" : that.btn == "中评" ? "5" : "0",
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(util)
    if (options.bsnum){
      this.setData({
        bsnum: options.bsnum
      })
    }
    this.getadvice();
  },
  getadvice:function(){
    var that = this;
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify({
          "projectNo": that.data.bsnum
          // "projectNo": 'GSJ_W190327190558520100006408019432'
        }), 'url': 'http://gzzw.gzegn.gov.cn:83/IntegratedQuery/getBusinessInfo'
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.statusCode == 200) {
          that.setData({
            dept_name: data.data.data.DATA.basemap.ITEMORGANNAME,
            dept_id: data.data.data.DATA.basemap.ITEMORGANCODE,
            dept_addr: data.data.data.DATA.basemap.ITEMREGIONCODE,
          })
        }
      }
    })
  },
  //上传评价信息
  uploadEvaluateInfo: function (data, success, notOk, error){
    data.yt_out_lay = yt_out_lay;
    data.ClassName = "AppraiseSys.action.AppraiseAction.Submit";
    data.DB_Conn = DB_Conn;
    data.serviceCode = serviceCode;
    data.requestNo = requestNo;
    data.signInfo = signInfo;
    wx.request({
      url: getApp().globalData.url + 'requestDelegate/handle',
      header: { 'Content-Type': getApp().globalData.contentType },
      data: {
        'param': JSON.stringify(data), 'url': evaluateUrl
      },//实际调用接口
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.code=='0'){
          wx.showToast({
            title: '评价成功！',
            icon:'none'
          })
          setTimeout(function(){
            wx.navigateTo({
              url: '/page/home/pages/home/pinjia/my_pinjia',
            })
          },500)
        }else{
          wx.showToast({
            title: '评价失败！',
            icon: 'none'
          })
        }
      }
    })
  }
})