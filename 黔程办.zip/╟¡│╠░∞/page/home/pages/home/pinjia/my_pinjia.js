// pages/home/my_yuyue.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pingjia: [],
    manyi:['未评价','非常满意','满意','一般','不满意'],
    color: ['', 'fcmy', 'my', 'yb', 'bmy']
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onShow: function (options) {
    console.log(options)
    this.pingjiatial()
  },

  gopinjia:function(e){
    console.log(e)
    wx.navigateTo({
      url: 'fabiao_pj?bsnum=' + e.currentTarget.dataset.bsnum,
    })
  },

  pingjiatial:function(){
    var that = this;
    //获取预约数据
    wx.request({
      url: getApp().globalData.url + 'advice/getAdvices',
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        token: wx.getStorageSync('token'),
        userId: wx.getStorageSync('user_id')
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        var data = data.data;
        if (data.code == 200) {
          if (data.data.length > 0) {
            that.setData({//把选中值放入判断值
              pingjia: data.data
            });
          } else {
            wx.showToast({
              title: '你还没有已经办结的事项，当前只能对办结的事项进行评价',
              icon: 'none'
            });
          }
        } else {
          if (data.data.msg == "登录已超时，请重新登录") {
            wx.showToast({
              title: '登录超时，请重新登录',
              icon: 'none'
            });
            wx.removeStorageSync('token');
            wx.navigateTo({
              url: '../login/selcet_login_type',
            })
            return
          } else {
            wx.showToast({
              title: '政务系统繁忙',
              icon: 'none'
            });
          }
        }
      },
      fail: function () {
        wx.showToast({
          title: '请检查网络连接',
          icon: 'none'
        });
      }
    })  
  }
})