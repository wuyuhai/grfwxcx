Page({ 
  data: {
    date: getApp().getyyyyMMddhhmm(),
    btns: [{
        id: 'zbj',
        name: "在办件",
        img: "/img/home/zbj.png",
        toView: "zbj", 
        src:"online/queryProcessing"
      },
      {
        id: 'zcj',
        name: "暂存件",
        img: "/img/home/zcj.png",
        toView: "zcj",
        src: "online/querySuspend"
      },
      {
        id: 'thj',
        name: "退回件",
        img: "/img/home/thj.png",
        toView: "thj",
        src: "online/queryRefuse"
      },
      {
        id: 'bjj1',
        name: "补交件",
        img: "/img/home/bjj1.png",
        toView: "bjj1",
        src: "online/queryAdditional"
      },
      {
        id: 'bjj2',
        name: "办结件",
        img: "/img/home/bjj2.png",
        toView: "bjj2",
        src: "online/queryFinish"
      }
    ],

    toView: 'zbj',
    alldata:[],
  },
  onLoad: function(options) {

    //登录用户查询办件情况

    // wx.setStorageSync("token", "81436357-0017-4B99-9FA3-DC5F562A7F08")
    // wx.setStorageSync("user_id", "9818676")
    var that = this;
    //this.requestkind('online/queryProcessing', 'zbj');
    if (wx.getStorageSync('user_name') != "" && wx.getStorageSync("token") != "") {
      this.setData({
        name: wx.getStorageSync("user_name") ? wx.getStorageSync("user_name") : wx.getStorageSync("login_name"),
        idcard: wx.getStorageSync('idCardNumber'),
        telphone: wx.getStorageSync('phone'),
        // emails: wx.getStorageSync('user_mobile') ? wx.getStorageSync('user_mobile'):"",
      })
      this.requestkind('online/queryProcessing', 'zbj');
    } else {
      wx.showModal({
        title: '提示',
        content: '当前用户未登录，返回首页',
        success: function (res) {
          if (res.confirm) {
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          } else if (res.cancel) {
            wx.switchTab({
              url: '/page/tabBar/index/index',
            })
          }
        },
      })
    }
  },

  change_view: function(e) { //点击切换展示栏
    console.log(e.currentTarget.dataset.src, e.currentTarget.id)
    if (this.data.toView != e.currentTarget.id) {
      this.setData({
        toView: e.currentTarget.id
      })
      this.requestkind(e.currentTarget.dataset.src, e.currentTarget.id)
    }
  },

  requestkind:function(urlstr,dataname){
    var that = this;
    console.log(wx.getStorageSync('user_id'))
    wx.request({
      url: getApp().globalData.url + urlstr,
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      data: {
        token: wx.getStorageSync('token'),
        applicantId: wx.getStorageSync('user_id')
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if (data.data.code == 200) {
          if (data.data.data) {
            that.setData({ //把选中值放入判断值
              alldata: data.data.data
            });
          } else {
            that.setData({ //把选中值放入判断值
              alldata: []
            });
            wx.showToast({
              title: '没有在班里中的事件',
              icon: 'none'
            });
          }
        } else {
          that.setData({ //把选中值放入判断值
            alldata: []
          });
          if (data.data.msg == "登录已超时，请重新登录") {
            wx.showToast({
              title: '登录超时，请重新登录',
              icon: 'none'
            });
            wx.removeStorageSync('token');
            wx.navigateTo({
              url: '../login/selcet_login_type',
            })
            return
          } else {
            wx.showToast({
              title: '政务系统繁忙',
              icon: 'none'
            });
          } 
        }
      },
      fail: function () {
        wx.showToast({
          title: '请检查网络连接',
          icon: 'none'
        });
      }
    })
  },
})