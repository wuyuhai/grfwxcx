// pages/home/set.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    date: getApp().getyyyyMMdd(),
    login_type: "wyz30", //微信密码 wxmm  人脸识别rlhs  30天无验证登录 wyz30
    user_name:''
  },
  change_login: function(e) {
    if (e.currentTarget.id != this.data.login_type) { 
      wx.setStorageSync("login_type", e.currentTarget.id)
      this.setData({
        login_type: e.currentTarget.id
      })
    }
  },
  login_out:function(){
    // wx.clearStorageSync();
    wx.removeStorageSync('token');
    wx.removeStorageSync('user_name');
    wx.switchTab({
      url: '/page/tabBar/index/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      login_type: wx.getStorageSync("login_type"),
      user_name: wx.getStorageSync("user_name")
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    if (wx.getStorageSync("login_type") == null || wx.getStorageSync("login_type") == "") {
      wx.setStorageSync("login_type", this.data.login_type)
    } else {
      this.setData({
        login_type: wx.getStorageSync("login_type"),
        user_name: wx.getStorageSync("user_name")
      })
    }
  },
})