// pages/home/my_yuyue.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    date: getApp().getyyyyMMddhhmm(),
    yuyue: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;

    //获取预约数据
    wx.request({
      url: getApp().globalData.url + 'appointment/appointmentList',
      header: {
        'Content-Type': getApp().globalData.contentType 
      },
      data: {
        token: wx.getStorageSync('token'),
        applicantId: wx.getStorageSync('user_id')        
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data)
        if(data.data.code == 200){
          if(data.data.data){
            that.setData({//把选中值放入判断值
              yuyue: data.data.data
            });
          }else{
            wx.showToast({
              title: '你还有任何预约',
              icon: 'none'
            });
          }
        }else{
          wx.showToast({
            title: data.data.msg,
            icon: 'none'
          });
          if (data.data.msg == "登录已超时，请重新登录") {
            wx.showToast({
              title: '登录超时，请重新登录',
              icon: 'none'
            });
            wx.removeStorageSync('token');
            wx.navigateTo({
              url: '../login/selcet_login_type',
            })
            return
          } else {
            wx.showToast({
              title: '政务系统繁忙',
              icon: 'none'
            });
          } 
        }      
      },
      fail: function () {
        wx.showToast({
          title: '请检查网络连接',
          icon: 'none'
        });
      }
    })
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})