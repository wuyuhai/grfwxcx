import md5 from '/utils/md51.js';
//app.js
App({
  globalData: { //全局变量
    url: 'https://gzzw.gzegn.gov.cn:84/UrbanService/',
    // url: 'http://192.168.0.107:8080/',
    // url: 'http://192.168.0.138:8080/',
    contentType: "application/x-www-form-urlencoded;charset=utf-8", //返回json的contentType
    fuwu_url: 'http://202.98.195.208:83/apiroute/',
    sousuo_url:'http://gzzw.gzegn.gov.cn:83/IntegratedQuery',
    wxId: '123456',
    shix_list: [],
    uType: 0,
    uType: 0,
    uType: 0,
    showmode2:{}
  },
  onlaunch: function (option) {

    console.log(option)//小程序场景值

  },
  subscribe: function () {//订阅
    var that = this;
    wx.request({
      header: {'Content-Type': that.globalData.contentType},
      url: that.globalData.url + 'requestDelegate/handle',
      data: {
        'param': JSON.stringify({
          'wxId': that.globalData.wxId
        }),'url':'http://202.98.195.208:82/unified_management/xcxSubscribeSort/findAllWithSubscribe'
      },
      method: 'post',dataType: 'json',
      success: function (data) {
        wx.hideLoading();
        console.log(data);
        if (data.statusCode == 200 && data.data.ok) {
          var dy_obj = data.data.obj;
          var pf_obj = [];
          for (var x = 0; x < data.data.obj.length; x++) {
            for (var y = 0; y < data.data.obj[x].subscribes.length; y++) {
              pf_obj.push(data.data.obj[x].subscribes[y]);
              if (data.data.obj[x].subscribes[y].id == wx.getStorageSync('subscription_id')){
                wx.setStorageSync("is_subs", data.data.obj[x].subscribes[y].subscribed);
              }
            }
          }
          var dingyuges = 0;
          for (var d = 0; d < pf_obj.length; d++) { //计算前九个有几个是没订阅的
            if (pf_obj[d].subscribed == true) {
              dingyuges += 1;
            }
          }
          console.log(dingyuges);
          var item_length = dingyuges - 12; //除了第一个盒子的9个
          var width_num = Math.ceil(item_length / 3) < 0 ? 0 : Math.ceil(item_length / 3); //第二个盒子的列数
          var jiu_num = 0;
          var jiu_num2 = 0;
          var new_array = [];
          for (var i = 0; i < 9; i++) { //计算前九个有几个是没订阅的
            if (pf_obj[i].subscribed == false) {
              jiu_num += 1;
            }
          }
          for (var i = 0; i < pf_obj.length; i++) { //计算九个之后有几个是没订阅的
            if (pf_obj[i].subscribed == false) {
              jiu_num2 += 1;
            } else {
              new_array.push(pf_obj[i]);
            }
          }
          var sub = jiu_num2 - jiu_num;
          wx.setStorageSync("dy_subscription", pf_obj);
          wx.setStorageSync("dy_subscription2", new_array);
          wx.setStorageSync("dy_num", jiu_num + 9 + sub);
          wx.setStorageSync("dy_scroll_n2_width", width_num * 184 + 5 + 'rpx');
        }
      }
    }) //ajax end
    // 
  },
  subs_fun:function(){
    var id = wx.getStorageSync('subscription_id'),that=this;
    wx.request({
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: {
        'param': JSON.stringify({
          'wxId': that.globalData.wxId,
          'subscribed': '1',
          'subscribeId': id
        }),
        'url': 'http://202.98.195.208:82/unified_management' + '/xcxSubscribeSort/bindOrNot'
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.ok) {
          wx.showToast({
            title: '订阅成功！',
            icon: 'none'
          });
          wx.setStorageSync("is_subs", true);
        }else{
          wx.showToast({
            title: '订阅失败！',
            icon: 'none'
          });
        }
      }
    })
  },
  close_subs_fun:function(){
    var id = wx.getStorageSync('subscription_id'), that = this;
    wx.request({
      header: {
        'Content-Type': getApp().globalData.contentType
      },
      url: getApp().globalData.url + 'requestDelegate/handle',
      data: {
        'param': JSON.stringify({
          'wxId': that.globalData.wxId,
          'subscribed': '0',
          'subscribeId': id
        }),
        'url': 'http://202.98.195.208:82/unified_management' + '/xcxSubscribeSort/bindOrNot'
      },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log(data);
        if (data.data.ok) {
          wx.showToast({
            title: '取消订阅成功！',
            icon: 'none'
          });
          wx.setStorageSync("is_subs", false);
        } else {
          wx.showToast({
            title: '取消订阅失败！',
            icon: 'none'
          });
        }
      }
    })
  },
  get_zbj_data: function () { //获取在办件 用于判断登录是否过期
    var that = this;
    var user_id = wx.getStorageSync('user_id');
    if (user_id != '') {
      wx.request({
        url: this.globalData.url + 'online/queryProcessing',
        header: {
          'Content-Type': this.globalData.contentType
        },
        data: {
          token: wx.getStorageSync('token'),
          applicantId: user_id
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          if (data.data.code == 200) { //正常获取收藏

          } else { //登录过期，重新登录
            wx.showToast({
              title: '登录过期',
              icon: 'none'
            });
          }
        },
        fail: function () {
          wx.showToast({
            title: '请检查网络连接',
            icon: 'none'
          });
        }
      })
    }
  },
  savewxinfo:function(phone){
    var that = this;
    var object = wx.getStorageSync("userdata");
    object.mobile = phone;
    delete object.watermark;
    if (wx.getStorageSync("phone") != ''){
      //已经保存的有用户手机号，证明已经传过data，不用再保存用户信息
    }else{
    wx.request({
      url: that.globalData.url + 'user/saveWXInfo',
      header: {
        'Content-Type': that.globalData.contentType
      },
      data: object,
      method: 'post',
      dataType: 'json',
      success: function (data) {
        console.log('保存用户信息成功');
        console.log(data);
      },
      })
    }
  },
  get_hot_item: function () { //获取热门事项
    var that = this;
    if (wx.getStorageSync("hot_item_list").length == 0) {
      wx.request({
        url: that.globalData.url + 'item/getHotItems',
        header: {
          'Content-Type': that.globalData.contentType
        },
        data: {
          pageNum: 1,
          pageSize: 10,
          regionId: wx.getStorageSync("qu_list")[wx.getStorageSync("qu_index")].AREAID
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          wx.setStorageSync("hot_item_list", data.data.data);
        },
        fail: function () {
          wx.showToast({
            title: '请检查网络连接',
            icon: 'none'
          });
        }
      })
    }
  },
  get_user_info: function () {
    var that = this;
    const APP_ID = 'wx40161b6ba4238139'; //输入小程序appid
    const APP_SECRET = '68a70cc2414a4764f21b0950f52b15d9'; //输入小程序密钥
    var that = this;
    // 查看是否授权
    wx.getSetting({
      success: function (res) {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称
          wx.login({
            success: data => {
              wx.getUserInfo({
                withCredentials: true,
                success: function (res) {
                  wx.request({
                    // url: 'https://face.fotoit.cn:84/UrbanService/user/decodeUserInfo',  //这个解密地址能用
                    url: that.globalData.url + 'user/decodeUserInfo',
                    header: {
                      'Content-Type': that.globalData.contentType
                    },
                    data: {
                      code: data.code,
                      encryptedData: res.encryptedData,
                      iv: res.iv,
                    }, //传微信id  unionId
                    method: 'post',
                    dataType: 'json',
                    success: function (reslut) {
                      //console.log(reslut);
                      if (reslut.data.code == 200) {
                         wx.setStorageSync("access_token", reslut.data.data.token);
                        // wx.setStorageSync("wxId", reslut.data.data.unionId);
                        wx.setStorageSync("wxId", reslut.data.data.openId);
                        wx.setStorageSync("openid", reslut.data.data.openId);
                        that.globalData.wxId = reslut.data.data.openId;
                      } else {
                        wx.showToast({
                          title: reslut.data.msg,//开发工具测试返回的是这个，，上线了之后只要解密地址授权，应该是上面成功的提示
                          icon: 'none'
                        });
                      }
                    }
                  }) //ajax end
                }
              })
            }
          })
        }
      }
    })
  },
  get_sx_list: function () {
    var that = this;
    if (wx.getStorageSync("show_shen") == 'true') {
      console.log('是显示省份');
      wx.request({
        url: that.globalData.url + 'dept/getItems',
        header: {
          'Content-Type': that.globalData.contentType
        },
        data: {
          page: 1,
          size: 1000,
          deptId: wx.getStorageSync("shen_dept")[wx.getStorageSync("bm_index")].DEPTID,
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log('事项成功');
          console.log(data);
          if (data.data.code == 200) {
            var timer = setTimeout(function () {
              clearTimeout(timer)
              wx.setStorageSync("shix_list", data.data.data);
              that.globalData.shix_list = data.data.data;
            }, 200)
          } else {
            wx.showToast({
              title: data.data.msg,
              icon: 'none'
            });
          }
        }
      })
    } else {
      console.log('不是显示省份');
      wx.request({
        url: that.globalData.url + 'dept/getItems',
        header: {
          'Content-Type': that.globalData.contentType
        },
        data: {
          page: 1,
          size: 1000,
          deptId: wx.getStorageSync("bm_btn_list")[0].DEPTID,
        },
        method: 'post',
        dataType: 'json',
        success: function (data) {
          console.log(data);
          if (data.data.code == 200) {
            wx.setStorageSync("shix_list", data.data.data);
            that.globalData.shix_list = data.data.data;
          } else {
            wx.showToast({
              title: data.data.msg,
              icon: 'none'
            });
          }
        }
      })
    }
  },
  onLaunch: function () {
    this.get_user_info(); //获取用户openid 和sessionkey
  },
  getyyyyMMddhhmm: function () { //获取当前时间如 2018-6-26 11:47
    var da = new Date(); //获取当前时间戳
    var year = da.getFullYear().toString();
    var month = da.getMonth() + 1;
    var date = da.getDate();
    var hours = da.getHours();
    var shiji_str = year + "-" + month + "-" + date + " " + hours + ":" + da.getMinutes();
    return shiji_str;
  },
  getyyyyMMdd: function () { //获取当前时间如 2018.6.26
    var da = new Date(); //获取当前时间戳
    var year = da.getFullYear().toString();
    var month = da.getMonth() + 1;
    var date = da.getDate();
    var shiji_str = year + "." + month + "." + date;
    return shiji_str;
  },


  pickerSHI: function (e) { //选择市后修改数据
    var that = this;
    wx.setStorageSync("shi_index", e.detail.value);
    wx.setStorageSync("qu_index", 0);
    //设置市下面的区
    var shi_obj = wx.getStorageSync("shi_list")[e.detail.value]; //获取市
    var pid = shi_obj.AREAID; //拿到当前市的id
    var list = [];
    var all_list = wx.getStorageSync("all_list");
    console.log(all_list);
    if (pid=="520000"){
      list.push({
        AREAID:'520000',
        AREANAME:'省本级',
        LAYER:'1',
        PARENTID:'520000',
        create_time: 1530754813000,
        id:112,
        update_time: 1530754813000
      });
      for (var i = 0; i < all_list.length; i++) {
        if (pid == all_list[i].PARENTID && pid != all_list[i].AREAID) {
          list.push(all_list[i]);
        }
      }
    }else{
      for (var i = 0; i < all_list.length; i++) {
        if (pid == all_list[i].PARENTID || pid == all_list[i].AREAID) {
          list.push(all_list[i]);
        }
      }
    }
    //设置区集合

    wx.setStorageSync("qu_list", list);
    //如果市下面没有区了，则结束
    if (wx.getStorageSync("qu_list").length == 0) {
      list.push(shi_obj)
      wx.setStorageSync("qu_list", list);
      return;
    }
    //this.get_sx_list() //重新获取热门事项
  },
  pickerQU: function (e) { //选择区后修改数据

    if (wx.getStorageSync("qu_index") != e.detail.value) {
      var that = this;
      wx.setStorageSync("qu_index", e.detail.value);
      //this.get_sx_list() //重新获取热门事项
    }

  },
  pickerBM: function (e) { //选择部门后修改数据
    var that = this;
    if (wx.getStorageSync("bm_index") != e.detail.value) {
      wx.setStorageSync("bm_index", e.detail.value);
    }
    that.get_sx_list() //重新获取热门事项
  },
  pickerSX: function (e) { //选择sx后修改数据
    if (wx.getStorageSync("sx_index") != e.detail.value) {
      var that = this;
      wx.setStorageSync("sx_index", e.detail.value);
      // this.get_sx_list() //重新获取热门事项
    }
  },
  longTimeToString: function (l) { //long类型的时间转成 yyyy-MM-dd
    var date = new Date();
    date.setTime(l)
    return date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDay
  },
})